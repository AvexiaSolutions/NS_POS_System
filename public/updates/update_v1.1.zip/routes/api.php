<?php

use App\Http\Controllers\Api\AuthController;
use App\Http\Controllers\Api\PosApiController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
*/

// 🟢 Mobile App එක හරහා Login වීමට (මෙය කාටත් විවෘතයි)
Route::post('/login', [AuthController::class, 'login']);

// ====================================================================
// 🟢 අලුතින් එකතු කළ UPDATE API එක (Client POS සිස්ටම් වලට කතා කිරීමට)
// ====================================================================
Route::get('/check-update', function () {
    return response()->json([
        'success' => true,
        'version' => '1.1', // 🟢 අලුත් කෝඩ් එකක් දැම්මම මේක 1.2, 1.3 විදිහට වෙනස් කරන්න
        'release_date' => '2026-02-26',
        'download_url' => url('/updates/update_v1.1.zip'), // 🟢 අප්ඩේට් ෆයිල් එක (Zip එක) තියෙන තැන
        'release_notes' => 'Location Map එක සහ අලුත් Dashboard වෙනස්කම් එකතු කරන ලදී.'
    ]);
});

// 🔒 Login වූ පසු පමණක් ප්‍රවේශ විය හැකි Routes (Protected by Sanctum)
Route::middleware('auth:sanctum')->group(function () {
    
    // දැනට Login වී සිටින User ගේ විස්තර ලබාගැනීමට
    Route::get('/user', function (Request $request) {
        return $request->user();
    });

    // App එකෙන් ඉවත් වීමට (Logout)
    Route::post('/logout', [AuthController::class, 'logout']);

    // බඩු බාහිරාදිය ලැයිස්තුව ලබාගැනීමට (Product List)
    Route::get('/products', [PosApiController::class, 'getProducts']);

    // App එක හරහා සිදුකරන විකුණුම් Database එකේ Save කිරීමට
    Route::post('/sales/store', [PosApiController::class, 'storeSale']);
    
});
