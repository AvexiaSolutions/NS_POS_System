@extends('layouts.admin')

@section('title', 'Finance Management')
@section('header', 'Bank & Expenses')

@section('content')
<style>
    /* --- Dark Mode Enhancements --- */
    [data-bs-theme="dark"] .card { background-color: #1e1e2d; border-color: #323248; }
    
    /* Inputs & Selects */
    [data-bs-theme="dark"] .form-control, 
    [data-bs-theme="dark"] .form-select,
    [data-bs-theme="dark"] textarea { 
        background-color: #2a2a3c !important; 
        border: 1px solid #323248 !important; 
        color: #fff !important; 
    }
    [data-bs-theme="dark"] .form-control:focus, 
    [data-bs-theme="dark"] .form-select:focus { 
        border-color: #435ebe !important; 
        box-shadow: 0 0 0 0.25rem rgba(67, 94, 190, 0.25) !important; 
    }

    /* Modals */
    [data-bs-theme="dark"] .modal-content { background-color: #1e1e2d !important; border: 1px solid #323248 !important; }
    [data-bs-theme="dark"] .modal-header, [data-bs-theme="dark"] .modal-footer { border-color: #323248 !important; }
    [data-bs-theme="dark"] .btn-close { filter: invert(1) grayscale(100%) brightness(200%); }

    /* Tables */
    [data-bs-theme="dark"] .table { color: #e2e2e2; border-color: #323248; }
    [data-bs-theme="dark"] .table-hover tbody tr:hover { background-color: #2a2a3c; color: #fff; }
    
    /* FIX: Dark Mode for Table Header (පහළ තීරුව නිවැරදි කිරීම) */
    [data-bs-theme="dark"] .table-light th {
        background-color: #2a2a3c !important;
        color: #fff !important;
        border-color: #323248 !important;
    }

    /* FIX: Dark Mode for Total Balance Card (සුදු පාට කොටුව නිවැරදි කිරීම) */
    [data-bs-theme="dark"] .bg-light-primary {
        background-color: #1e1e2d !important;
        border: 1px solid #323248 !important;
    }
    
    /* Total Balance Text */
    .balance-text { color: #000 !important; } /* Light Mode: Black */
    [data-bs-theme="dark"] .balance-text { color: #fff !important; } /* Dark Mode: White */
    
    /* Muted Text Fix for Dark mode */
    [data-bs-theme="dark"] .text-muted { color: #a0a0a0 !important; }
</style>

@if(session('success'))
<div class="alert alert-success alert-dismissible fade show" role="alert">
    {{ session('success') }}
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
@endif

<div class="row mb-4">
    <div class="col-12 d-flex flex-wrap gap-2">
        <button class="btn btn-success fw-bold shadow-sm py-2 px-3" data-bs-toggle="modal" data-bs-target="#salesIncomeDepositModal">
            <i class="bi bi-box-arrow-in-down"></i> Deposit Sales Income
        </button>
        <button class="btn btn-info text-white fw-bold shadow-sm py-2 px-3" onclick="openDepositModal('Other Deposit')">
            <i class="bi bi-piggy-bank"></i> Other Deposit
        </button>
    </div>
</div>

<div class="row">
    <div class="col-md-4 mb-4">
        <div class="card shadow-sm h-100 bg-light-primary border-primary border-top border-4">
            <div class="card-body text-center py-4 d-flex flex-column justify-content-center align-items-center">
                <h6 class="text-muted mb-2 text-uppercase fw-bold">Total Bank Balance</h6>
                <h2 class="fw-bold balance-text mb-0">Rs. {{ number_format($banks->sum('current_balance'), 2) }}</h2>
                <i class="bi bi-bank fs-1 text-primary mt-3 opacity-50"></i>
            </div>
        </div>
    </div>
    
    <div class="col-md-8 mb-4">
        <div class="card h-100 shadow-sm">
            <div class="card-header d-flex justify-content-between align-items-center bg-transparent">
                <h5 class="mb-0 fw-bold"><i class="bi bi-safe"></i> Bank Accounts</h5>
                <button class="btn btn-primary btn-sm fw-bold" data-bs-toggle="modal" data-bs-target="#addBankModal">
                    <i class="bi bi-plus-lg"></i> Add Bank
                </button>
            </div>
            <div class="card-body" style="max-height: 250px; overflow-y: auto;">
                <div class="row g-3">
                    @foreach($banks as $bank)
                    <div class="col-md-6">
                        <div class="card border {{ $bank->is_primary ? 'border-warning' : 'border-secondary' }} mb-0 shadow-none h-100">
                            <div class="card-body p-3 d-flex flex-column">
                                <div class="d-flex justify-content-between align-items-start mb-2">
                                    <div>
                                        <h6 class="mb-0 fw-bold text-primary">{{ $bank->bank_name }}</h6>
                                        <small class="text-muted d-block font-monospace">{{ $bank->account_number }}</small>
                                        <small class="text-muted">{{ $bank->account_name ?? 'N/A' }}</small>
                                    </div>
                                    @if($bank->is_primary)
                                        <span class="badge bg-warning text-dark"><i class="bi bi-star-fill"></i> Primary</span>
                                    @endif
                                </div>
                                <h5 class="mb-3 text-success fw-bold flex-grow-1">Rs. {{ number_format($bank->current_balance, 2) }}</h5>
                                
                                <div class="text-end border-top pt-2">
                                    <button class="btn btn-sm btn-outline-secondary" onclick='editBank(@json($bank))'>
                                        <i class="bi bi-pencil-square"></i> Edit
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                    @endforeach
                </div>
            </div>
        </div>
    </div>
</div>

<div class="card shadow-sm mt-2">
    <div class="card-header d-flex justify-content-between align-items-center bg-danger py-3">
        <h5 class="mb-0 text-white fw-bold"><i class="bi bi-cash-stack me-2"></i> Expenses Log</h5>
        <button class="btn btn-light text-danger btn-sm fw-bold" data-bs-toggle="modal" data-bs-target="#addExpenseModal">
            <i class="bi bi-plus-lg"></i> Add New Expense
        </button>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive" style="max-height: 400px; overflow-y: auto;">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-light position-sticky top-0">
                    <tr>
                        <th>Date</th>
                        <th>Category</th>
                        <th>Description</th>
                        <th>Payment Method</th>
                        <th class="text-end">Amount</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($expenses as $expense)
                    <tr>
                        <td class="small">{{ \Carbon\Carbon::parse($expense->expense_date)->format('Y-m-d') }}</td>
                        <td><span class="badge bg-light-danger text-danger border border-danger">{{ $expense->category }}</span></td>
                        <td>{{ $expense->description ?? '-' }}</td>
                        <td>
                            @if($expense->bank_account_id)
                                <small class="text-muted fw-bold"><i class="bi bi-bank text-primary"></i> {{ $expense->bankAccount->bank_name ?? 'Bank' }}</small>
                            @else
                                <small class="text-muted fw-bold"><i class="bi bi-cash text-success"></i> Petty Cash</small>
                            @endif
                        </td>
                        <td class="text-end fw-bold text-danger fs-6">Rs. {{ number_format($expense->amount, 2) }}</td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="5" class="text-center py-5 text-muted"><i class="bi bi-journal-x fs-1 d-block mb-2 opacity-50"></i> No expenses recorded yet.</td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="modal fade" id="addBankModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <form action="{{ route('finance.bank.store') }}" method="POST" class="modal-content">
            @csrf
            <div class="modal-header bg-primary text-white py-3">
                <h5 class="modal-title text-white fw-bold"><i class="bi bi-safe"></i> Add Bank Account</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-4">
                <div class="mb-3">
                    <label class="form-label small fw-bold text-muted">Bank Name <span class="text-danger">*</span></label>
                    <input type="text" name="bank_name" class="form-control" required placeholder="e.g. BOC, Sampath">
                </div>
                <div class="mb-3">
                    <label class="form-label small fw-bold text-muted">Account Name</label>
                    <input type="text" name="account_name" class="form-control" placeholder="e.g. Current Account">
                </div>
                <div class="mb-3">
                    <label class="form-label small fw-bold text-muted">Account Number <span class="text-danger">*</span></label>
                    <input type="text" name="account_number" class="form-control font-monospace" required>
                </div>
                <div class="mb-3">
                    <label class="form-label small fw-bold text-muted">Opening Balance (Rs)</label>
                    <input type="number" step="0.01" name="current_balance" class="form-control text-end fw-bold text-success" value="0.00">
                </div>
                <div class="form-check form-switch mt-4 border-top pt-3">
                    <input class="form-check-input fs-5" type="checkbox" name="is_primary" value="1">
                    <label class="form-check-label fw-bold mt-1 ms-2">Set as Primary Account</label>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="submit" class="btn btn-primary fw-bold px-4">Save Account</button>
            </div>
        </form>
    </div>
</div>

<div class="modal fade" id="editBankModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <form id="editBankForm" method="POST" class="modal-content">
            @csrf
            @method('PUT') 
            <div class="modal-header bg-secondary text-white py-3">
                <h5 class="modal-title text-white fw-bold"><i class="bi bi-pencil-square"></i> Edit Bank Account</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-4">
                <div class="mb-3">
                    <label class="form-label small fw-bold text-muted">Bank Name <span class="text-danger">*</span></label>
                    <input type="text" name="bank_name" id="edit_bank_name" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label class="form-label small fw-bold text-muted">Account Name</label>
                    <input type="text" name="account_name" id="edit_account_name" class="form-control">
                </div>
                <div class="mb-3">
                    <label class="form-label small fw-bold text-muted">Account Number <span class="text-danger">*</span></label>
                    <input type="text" name="account_number" id="edit_account_number" class="form-control font-monospace" required>
                </div>
                <div class="form-check form-switch mt-4 border-top pt-3">
                    <input class="form-check-input fs-5" type="checkbox" name="is_primary" id="edit_is_primary" value="1">
                    <label class="form-check-label fw-bold mt-1 ms-2">Set as Primary Account</label>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="submit" class="btn btn-secondary fw-bold px-4">Update Details</button>
            </div>
        </form>
    </div>
</div>

<div class="modal fade" id="addExpenseModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <form action="{{ route('finance.expense.store') }}" method="POST" class="modal-content">
            @csrf
            <div class="modal-header bg-danger text-white py-3">
                <h5 class="modal-title text-white fw-bold"><i class="bi bi-cash-stack"></i> Record Expense</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-4">
                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label small fw-bold text-muted">Category</label>
                        <select name="category" class="form-select" required>
                            <option value="Electricity">Electricity</option>
                            <option value="Water">Water</option>
                            <option value="Rent">Rent</option>
                            <option value="Staff Salary">Staff Salary</option>
                            <option value="Repairs">Repairs</option>
                            <option value="Transport">Transport</option>
                            <option value="Other">Other</option>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label small fw-bold text-muted">Expense Date</label>
                        <input type="date" name="expense_date" class="form-control" value="{{ date('Y-m-d') }}" required>
                    </div>
                    <div class="col-12">
                        <label class="form-label small fw-bold text-muted">Amount (Rs) <span class="text-danger">*</span></label>
                        <input type="number" step="0.01" name="amount" class="form-control form-control-lg text-end fw-bold text-danger" required>
                    </div>
                    
                    <div class="col-12 border-top pt-2 mt-2">
                        <label class="form-label small fw-bold text-muted">Pay From (Bank Account) <span class="text-danger">*</span></label>
                        <select name="bank_account_id" class="form-select" required>
                            @foreach($banks as $bank)
                                <option value="{{ $bank->id }}" {{ $bank->is_primary ? 'selected' : '' }}>
                                    {{ $bank->bank_name }} - {{ $bank->account_number }} 
                                    {!! $bank->is_primary ? '(Primary)' : '' !!}
                                </option>
                            @endforeach
                        </select>
                        <small class="text-muted">The amount will be deducted from this bank balance.</small>
                    </div>

                    <div class="col-12 mt-2">
                        <label class="form-label small fw-bold text-muted">Description / Note</label>
                        <textarea name="description" class="form-control" rows="2" placeholder="Brief details about the expense..."></textarea>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="submit" class="btn btn-danger fw-bold px-4">Record Expense</button>
            </div>
        </form>
    </div>
</div>

<div class="modal fade" id="salesIncomeDepositModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <form action="{{ route('cashbook.to_bank') }}" method="POST" class="modal-content border-success">
            @csrf
            <div class="modal-header bg-success text-white py-3">
                <h5 class="modal-title text-white fw-bold"><i class="bi bi-box-arrow-in-down"></i> Deposit Sales Income</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-4">
                <div class="alert alert-warning small">
                    <i class="bi bi-info-circle-fill"></i> The amount you deposit here will be automatically deducted from your <b>Hand in Cash</b> balance and added to the selected Bank Account.
                </div>
                <div class="mb-3">
                    <label class="form-label small fw-bold text-muted">Select Bank Account <span class="text-danger">*</span></label>
                    <select name="bank_account_id" class="form-select form-select-lg" required>
                        <option value="">Choose Bank...</option>
                        @foreach($banks as $bank)
                            <option value="{{ $bank->id }}">{{ $bank->bank_name }} (Bal: {{ number_format($bank->current_balance, 2) }})</option>
                        @endforeach
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label small fw-bold text-muted">Deposit Amount (Rs) <span class="text-danger">*</span></label>
                    <input type="number" step="0.01" name="amount" class="form-control form-control-lg text-end fw-bold text-success" placeholder="Amount transferring from Cash Drawer" required>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="submit" class="btn btn-success fw-bold px-4">Transfer Cash to Bank</button>
            </div>
        </form>
    </div>
</div>

<div class="modal fade" id="depositModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <form action="{{ route('finance.deposit.store') ?? '#' }}" method="POST" class="modal-content border-info">
            @csrf
            <input type="hidden" name="deposit_type" id="depositTypeInput">
            
            <div class="modal-header bg-info text-dark py-3">
                <h5 class="modal-title fw-bold" id="depositModalTitle">Deposit Funds</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-4">
                <div class="row g-3">
                    <div class="col-12">
                        <label class="form-label small fw-bold text-muted">Select Bank Account <span class="text-danger">*</span></label>
                        <select name="bank_account_id" class="form-select form-select-lg" required>
                            <option value="">Choose Bank...</option>
                            @foreach($banks as $bank)
                                <option value="{{ $bank->id }}">{{ $bank->bank_name }} ({{ $bank->account_number }})</option>
                            @endforeach
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label small fw-bold text-muted">Deposit Amount (Rs) <span class="text-danger">*</span></label>
                        <input type="number" step="0.01" name="amount" class="form-control form-control-lg text-end fw-bold text-info" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label small fw-bold text-muted">Date <span class="text-danger">*</span></label>
                        <input type="date" name="deposit_date" class="form-control form-control-lg" value="{{ date('Y-m-d') }}" required>
                    </div>
                    <div class="col-12">
                        <label class="form-label small fw-bold text-muted">Note / Reference</label>
                        <input type="text" name="note" id="depositNoteInput" class="form-control" placeholder="E.g. Owner investment...">
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="submit" class="btn btn-info text-dark fw-bold px-4">Confirm Deposit</button>
            </div>
        </form>
    </div>
</div>

@endsection

@section('scripts')
<script>
    // Edit Bank Function
    function editBank(bank) {
        document.getElementById('edit_bank_name').value = bank.bank_name;
        document.getElementById('edit_account_name').value = bank.account_name || '';
        document.getElementById('edit_account_number').value = bank.account_number;
        document.getElementById('edit_is_primary').checked = (bank.is_primary == 1);
        
        document.getElementById('editBankForm').action = `{{ url('finance/bank') }}/${bank.id}`;
        
        new bootstrap.Modal(document.getElementById('editBankModal')).show();
    }

    // Open Deposit Modal Function
    function openDepositModal(type) {
        document.getElementById('depositTypeInput').value = type;
        
        let title = document.getElementById('depositModalTitle');
        let note = document.getElementById('depositNoteInput');
        
        title.innerHTML = '<i class="bi bi-piggy-bank"></i> Other Deposit';
        note.value = "Owner Investment / Other";
        
        new bootstrap.Modal(document.getElementById('depositModal')).show();
    }
</script>
@endsection
