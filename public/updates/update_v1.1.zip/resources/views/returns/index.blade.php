@extends('layouts.admin')

@section('title', 'Returns & Warranty')
@section('header', 'Returns & Warranty Management')

@section('content')
<style>
    /* --- Dark Mode Support --- */
    [data-bs-theme="dark"] .card { background-color: #1e1e2d; border-color: #323248; }
    [data-bs-theme="dark"] .form-control, [data-bs-theme="dark"] .form-select { background-color: #2a2a3c !important; border-color: #323248 !important; color: #fff !important; }
    [data-bs-theme="dark"] .form-control:focus, [data-bs-theme="dark"] .form-select:focus { background-color: #2a2a3c !important; color: #fff !important; border-color: #435ebe !important; box-shadow: 0 0 0 0.25rem rgba(67, 94, 190, 0.25) !important; }
    [data-bs-theme="dark"] .table { color: #e2e2e2; border-color: #323248; }
    [data-bs-theme="dark"] .table-hover tbody tr:hover { color: #fff; background-color: #2a2a3c; }
    [data-bs-theme="dark"] .text-muted { color: #a0a0a0 !important; }
    [data-bs-theme="dark"] .modal-content { background-color: #1e1e2d !important; border: 1px solid #323248 !important; }
    
    /* --- FIX: Dark Mode for Table Header & Badges --- */
    [data-bs-theme="dark"] .table-light th {
        background-color: #2a2a3c !important;
        color: #fff !important;
        border-color: #323248 !important;
    }
    [data-bs-theme="dark"] .bg-light-secondary.text-dark {
        background-color: #2a2a3c !important;
        color: #fff !important;
    }

    /* --- FIX: Dark Mode for Warranty Details Box --- */
    [data-bs-theme="dark"] #warrantyDetailsArea {
        background-color: #2a2a3c !important;
        border-color: #4a4a6a !important;
    }
    [data-bs-theme="dark"] #warrantyDetailsArea span.text-muted {
        color: #a0a0a0 !important;
    }
    [data-bs-theme="dark"] #warrantyDetailsArea span.fw-bold {
        color: #fff !important;
    }

    .search-container { max-width: 600px; margin: 0 auto; }
    .action-btn-group .btn { min-width: 90px; }
</style>

<div class="card shadow-sm mb-4">
    <div class="card-body">
        <h5 class="card-title text-center mb-4"><i class="bi bi-upc-scan"></i> Scan or Search Invoice</h5>
        <div class="row">
            <div class="col-12 search-container">
                <div class="input-group input-group-lg shadow-sm">
                    <input type="text" id="invoiceInput" class="form-control border-primary" placeholder="e.g. INV-EQGOEQAU" autofocus autocomplete="off">
                    <button class="btn btn-primary px-4 fw-bold" type="button" onclick="searchBill()">
                        <i class="bi bi-search me-2"></i> Find
                    </button>
                </div>
            </div>
        </div>

        <div id="resultArea" class="d-none mt-5 border-top pt-4">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h5 class="mb-0 text-primary fw-bold"><i class="bi bi-receipt"></i> Invoice: <span id="dispInv"></span></h5>
                <span class="badge bg-light-secondary text-dark fs-6" id="dispDate"></span>
            </div>

            <div class="table-responsive">
                <table class="table table-hover align-middle border">
                    <thead class="table-light">
                        <tr>
                            <th>Product Details</th>
                            <th class="text-center">Sold Qty</th>
                            <th class="text-center">Already Returned</th>
                            <th class="text-center">Available to Action</th>
                            <th class="text-end">Price</th>
                            <th class="text-center">Actions</th>
                        </tr>
                    </thead>
                    <tbody id="itemsTable">
                        </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="actionModal" tabindex="-1" data-bs-backdrop="static">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header" id="modalHeader">
                <h5 class="modal-title fw-bold text-white" id="actionModalTitle">Action</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-4">
                <h5 id="modalProductName" class="fw-bold mb-3 text-center"></h5>
                
                <input type="hidden" id="actionType">
                <input type="hidden" id="actionItemIndex">
                
                <div class="mb-3 text-center">
                    <label class="form-label text-muted small fw-bold">Quantity</label>
                    <input type="number" id="actionQty" class="form-control form-control-lg text-center mx-auto" style="max-width: 150px; font-weight:bold;" min="0.01" step="0.01">
                    <small class="text-muted d-block mt-1">Max allowed: <span id="maxQtyDisp" class="fw-bold">0</span></small>
                </div>

                <div id="warrantyDetailsArea" class="d-none bg-light p-3 rounded mb-3 border">
                    <div class="d-flex justify-content-between mb-1"><span class="text-muted small">Purchased:</span> <span id="wPurchaseDate" class="fw-bold small"></span></div>
                    <div class="d-flex justify-content-between mb-1"><span class="text-muted small">Warranty:</span> <span id="wPeriod" class="fw-bold small"></span></div>
                    <div class="d-flex justify-content-between"><span class="text-muted small">End Date:</span> <span id="wEndDate" class="fw-bold small"></span></div>
                    <div class="text-center mt-2 border-top pt-2" id="wStatusText"></div>
                </div>

                <div class="mb-3">
                    <label class="form-label text-muted small fw-bold">Reason / Note</label>
                    <textarea class="form-control" id="actionReason" rows="2" placeholder="Explain the reason..."></textarea>
                </div>

                <div class="card bg-light-danger border-danger mb-3" id="refundArea">
                    <div class="card-body text-center py-2">
                        <span class="text-danger small fw-bold d-block">Estimated Refund</span>
                        <h4 class="mb-0 text-danger fw-bold">Rs. <span id="actionRefundAmount">0.00</span></h4>
                    </div>
                </div>

                <button class="btn btn-lg w-100 fw-bold text-white shadow-sm" id="confirmActionBtn" onclick="submitAction()">Confirm Action</button>
            </div>
        </div>
    </div>
</div>

<div class="card shadow-sm mt-4">
    <div class="card-header bg-dark text-white d-flex justify-content-between align-items-center">
        <h5 class="mb-0 text-white"><i class="bi bi-clock-history"></i> Return & Warranty History</h5>
    </div>
    <div class="card-body">
        <form action="{{ route('returns.index') }}" method="GET" class="row g-3 mb-4 align-items-end">
            <div class="col-md-4">
                <label class="form-label small text-muted">Start Date</label>
                <input type="date" name="start_date" class="form-control" value="{{ request('start_date', date('Y-m-01')) }}">
            </div>
            <div class="col-md-4">
                <label class="form-label small text-muted">End Date</label>
                <input type="date" name="end_date" class="form-control" value="{{ request('end_date', date('Y-m-d')) }}">
            </div>
            <div class="col-md-4">
                <button type="submit" class="btn btn-secondary w-100"><i class="bi bi-filter"></i> Filter History</button>
            </div>
        </form>

        <div class="table-responsive">
            <table class="table table-striped align-middle">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Invoice</th>
                        <th>Product</th>
                        <th>Type</th>
                        <th class="text-center">Qty</th>
                        <th class="text-end">Refund (Rs)</th>
                        <th>Reason</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($history ?? [] as $log)
                    <tr>
                        <td class="small">{{ \Carbon\Carbon::parse($log->created_at)->format('Y-m-d h:i A') }}</td>
                        <td class="fw-bold">{{ $log->invoice_no }}</td>
                        <td>{{ $log->product_name }}</td>
                        <td>
                            @if($log->type == 'return') <span class="badge bg-primary">Return</span>
                            @elseif($log->type == 'damage') <span class="badge bg-danger">Damage</span>
                            @elseif($log->type == 'warranty') <span class="badge bg-info text-dark">Warranty</span>
                            @endif
                        </td>
                        <td class="text-center fw-bold">{{ $log->qty }}</td>
                        <td class="text-end fw-bold text-danger">{{ number_format($log->refund_amount, 2) }}</td>
                        <td class="small text-muted">{{ $log->reason ?? '-' }}</td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="7" class="text-center py-4 text-muted">No records found for the selected period.</td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
</div>

@endsection

@section('scripts')
<script>
    let currentSaleId = null;
    let currentItems = [];
    let currentSaleData = null; 

    // Enter Key Search Logic (Updated for Barcode Scanner)
    document.addEventListener("DOMContentLoaded", function() {
        const inputField = document.getElementById("invoiceInput");
        if (inputField) {
            // Keep focus on the input field for easy scanning
            inputField.focus();

            inputField.addEventListener("keydown", function(event) {
                if (event.key === "Enter") {
                    event.preventDefault(); 
                    
                    // Barcode scanners type very fast. 
                    // To prevent multiple triggers, check if input is not empty
                    if (this.value.trim() !== '') {
                        searchBill();
                    }
                }
            });
        }

        // Auto calculate refund on modal qty change
        document.getElementById('actionQty').addEventListener('input', calculateModalRefund);
    });

    function searchBill() {
        let inv = document.getElementById('invoiceInput').value.trim();
        if(!inv) return alert("Please enter invoice code");

        let btn = document.querySelector('button[onclick="searchBill()"]');
        let originalText = btn.innerHTML;
        btn.innerHTML = '<span class="spinner-border spinner-border-sm"></span> Searching...';
        btn.disabled = true;

        fetch("{{ route('returns.search') }}", {
            method: "POST",
            headers: { "Content-Type": "application/json", "X-CSRF-TOKEN": "{{ csrf_token() }}" },
            body: JSON.stringify({ invoice_no: inv })
        })
        .then(res => res.json())
        .then(data => {
            btn.innerHTML = originalText;
            btn.disabled = false;

            if(data.status === 'error') {
                alert(data.message);
                document.getElementById('resultArea').classList.add('d-none');
                
                // Clear input and focus back for the next scan
                let inputField = document.getElementById('invoiceInput');
                inputField.value = '';
                inputField.focus();
            } else {
                renderItems(data);
            }
        })
        .catch(err => {
            btn.innerHTML = originalText;
            btn.disabled = false;
            console.error(err);
            alert("System Error. Check Console.");
        });
    }

    function renderItems(data) {
        currentSaleId = data.sale.id;
        currentSaleData = data.sale; 
        
        document.getElementById('dispInv').innerText = data.sale.invoice_no;
        document.getElementById('dispDate').innerText = data.sale_date;
        document.getElementById('resultArea').classList.remove('d-none');
        
        let html = '';
        currentItems = data.items;

        data.items.forEach((item, index) => {
            let disabled = (item.available_qty <= 0) ? 'disabled' : '';
            let rowClass = (item.available_qty <= 0) ? 'table-active opacity-50' : '';

            // Dynamic Action Buttons
            let buttonsHtml = `
                <div class="btn-group action-btn-group shadow-sm">
                    <button class="btn btn-sm btn-primary" ${disabled} onclick="openActionModal(${index}, 'return')">Return</button>
                    <button class="btn btn-sm btn-danger" ${disabled} onclick="openActionModal(${index}, 'damage')">Damage</button>
            `;
            
            // Only show Warranty Button if product has warranty
            if(item.has_warranty == 1) {
                buttonsHtml += `<button class="btn btn-sm btn-info text-dark fw-bold" ${disabled} onclick="openActionModal(${index}, 'warranty')"><i class="bi bi-shield-check"></i> Claim</button>`;
            }
            buttonsHtml += `</div>`;

            html += `
            <tr class="${rowClass}">
                <td>
                    <div class="fw-bold text-primary">${item.product_name}</div>
                    <small class="text-muted">Barcode: ${item.barcode ?? 'N/A'}</small>
                </td>
                <td class="text-center">${parseFloat(item.qty)} ${item.unit}</td>
                <td class="text-center text-danger fw-bold">${parseFloat(item.returned_qty)}</td>
                <td class="text-center text-success fw-bold fs-5">${parseFloat(item.available_qty)}</td>
                <td class="text-end fw-bold">Rs. ${parseFloat(item.price).toFixed(2)}</td>
                <td class="text-center">${buttonsHtml}</td>
            </tr>`;
        });

        document.getElementById('itemsTable').innerHTML = html;
        
        // Select input field text after successful search so next scan replaces it
        document.getElementById('invoiceInput').select();
    }

    // Modal Logic
    function openActionModal(index, type) {
        let item = currentItems[index];
        let maxQty = parseFloat(item.available_qty);
        
        // Reset Modal Data
        document.getElementById('actionItemIndex').value = index;
        document.getElementById('actionType').value = type;
        document.getElementById('modalProductName').innerText = item.product_name;
        document.getElementById('actionQty').value = maxQty; // Default to max
        document.getElementById('actionQty').max = maxQty;
        document.getElementById('maxQtyDisp').innerText = maxQty + ' ' + item.unit;
        document.getElementById('actionReason').value = '';
        
        // UI Adjustments based on Type
        let header = document.getElementById('modalHeader');
        let title = document.getElementById('actionModalTitle');
        let btn = document.getElementById('confirmActionBtn');
        let refundArea = document.getElementById('refundArea');
        let warrantyArea = document.getElementById('warrantyDetailsArea');

        warrantyArea.classList.add('d-none');
        header.classList.remove('bg-primary', 'bg-danger', 'bg-info');
        btn.classList.remove('btn-primary', 'btn-danger', 'btn-info');
        btn.disabled = false;

        if (type === 'return') {
            header.classList.add('bg-primary');
            title.innerHTML = '<i class="bi bi-arrow-return-left"></i> Process Return (Add to Stock)';
            btn.classList.add('btn-primary');
            refundArea.style.display = 'block';
        } 
        else if (type === 'damage') {
            header.classList.add('bg-danger');
            title.innerHTML = '<i class="bi bi-trash"></i> Mark as Damaged (No Stock)';
            btn.classList.add('btn-danger');
            refundArea.style.display = 'block';
        } 
        else if (type === 'warranty') {
            header.classList.add('bg-info');
            title.innerHTML = '<i class="bi bi-shield-check"></i> Warranty Claim';
            btn.classList.add('btn-info');
            refundArea.style.display = 'none'; // No refund for warranty by default
            
            // Populate Warranty Data
            warrantyArea.classList.remove('d-none');
            let saleDateObj = new Date(currentSaleData.created_at);
            document.getElementById('wPurchaseDate').innerText = saleDateObj.toLocaleDateString('en-GB');
            document.getElementById('wPeriod').innerText = item.warranty_months + " Months";
            
            let endDateObj = new Date(saleDateObj);
            endDateObj.setMonth(endDateObj.getMonth() + parseInt(item.warranty_months));
            document.getElementById('wEndDate').innerText = endDateObj.toLocaleDateString('en-GB');

            let now = new Date();
            let statusEl = document.getElementById('wStatusText');
            if(now <= endDateObj) {
                statusEl.innerHTML = '<span class="text-success"><i class="bi bi-check-circle-fill"></i> WARRANTY ACTIVE</span>';
            } else {
                statusEl.innerHTML = '<span class="text-danger"><i class="bi bi-x-circle-fill"></i> WARRANTY EXPIRED</span>';
                btn.disabled = true; // Disable button if expired
            }
        }

        calculateModalRefund();
        
        let modalElement = document.getElementById('actionModal');
        let bsModal = new bootstrap.Modal(modalElement);
        bsModal.show();
        
        // Auto-focus reason field when modal opens
        modalElement.addEventListener('shown.bs.modal', function () {
            document.getElementById('actionReason').focus();
        }, { once: true });
    }

    function calculateModalRefund() {
        let index = document.getElementById('actionItemIndex').value;
        let item = currentItems[index];
        let qty = parseFloat(document.getElementById('actionQty').value) || 0;
        let type = document.getElementById('actionType').value;

        if(qty > item.available_qty) {
            document.getElementById('actionQty').value = item.available_qty;
            qty = item.available_qty;
        }

        let refund = 0;
        if(type !== 'warranty') { // Assuming warranty is repair/replace, not refund
            refund = qty * item.price;
        }
        
        document.getElementById('actionRefundAmount').innerText = refund.toFixed(2);
    }

    function submitAction() {
        let index = document.getElementById('actionItemIndex').value;
        let item = currentItems[index];
        let type = document.getElementById('actionType').value;
        let qty = parseFloat(document.getElementById('actionQty').value);
        let reason = document.getElementById('actionReason').value;

        if(!qty || qty <= 0) return alert("Please enter a valid quantity.");
        if(qty > item.available_qty) return alert("Quantity exceeds available limit.");
        if(!reason) return alert("Please provide a reason.");

        let payload = [{
            product_id: item.product_id,
            qty: qty,
            type: type
        }];

        let btn = document.getElementById('confirmActionBtn');
        btn.disabled = true;
        btn.innerHTML = 'Processing...';

        fetch("{{ route('returns.process') }}", {
            method: "POST",
            headers: { "Content-Type": "application/json", "X-CSRF-TOKEN": "{{ csrf_token() }}" },
            body: JSON.stringify({
                sale_id: currentSaleId,
                invoice_no: currentSaleData.invoice_no,
                items: payload,
                reason: reason
            })
        })
        .then(res => res.json())
        .then(data => {
            if(data.status === 'success') {
                alert("Action completed successfully!");
                location.reload();
            } else {
                alert("Error: " + data.message);
                btn.disabled = false;
                btn.innerHTML = 'Confirm Action';
            }
        });
    }
</script>
@endsection
