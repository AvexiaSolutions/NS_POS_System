@extends('layouts.admin')

@section('title', 'Branch Settings')
@section('header', 'Manage Branches')

@section('content')

<style>
    /* --- Dark Mode UI Fixes --- */
    [data-bs-theme="dark"] .card { background-color: #1e1e2d; border-color: #323248; }
    [data-bs-theme="dark"] .form-control { background-color: #2a2a3c !important; border: 1px solid #323248 !important; color: #fff !important; }
    [data-bs-theme="dark"] .form-control:focus { border-color: #435ebe !important; box-shadow: 0 0 0 0.25rem rgba(67, 94, 190, 0.25) !important; }
    [data-bs-theme="dark"] .table { color: #e2e2e2; border-color: #323248; }
    [data-bs-theme="dark"] .table-hover tbody tr:hover { background-color: #2a2a3c; color: #fff; }
    /* මේකෙන් තමයි අර සුදු පාට තීරුව හරියන්නේ */
    [data-bs-theme="dark"] .table-light th { background-color: #2a2a3c !important; color: #fff !important; border-color: #323248 !important; }
    
    /* Modal Dark Mode */
    [data-bs-theme="dark"] .modal-content { background-color: #1e1e2d !important; border: 1px solid #323248 !important; }
    [data-bs-theme="dark"] .modal-header, [data-bs-theme="dark"] .modal-footer { border-color: #323248 !important; }
    [data-bs-theme="dark"] .btn-close { filter: invert(1) grayscale(100%) brightness(200%); }
</style>

<div class="row">
    <div class="col-md-4 mb-4">
        <div class="card shadow-sm h-100">
            <div class="card-header bg-primary text-white py-3">
                <h5 class="mb-0 text-white fw-bold"><i class="bi bi-shop"></i> Add New Branch</h5>
            </div>
            <div class="card-body mt-2">
                @if ($errors->any())
                    <div class="alert alert-danger pb-0">
                        <ul>
                            @foreach ($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                        </ul>
                    </div>
                @endif

                <form action="{{ route('branches.store') }}" method="POST">
                    @csrf
                    <div class="mb-3">
                        <label class="form-label fw-bold small text-muted">Branch Name <span class="text-danger">*</span></label>
                        <input type="text" name="name" class="form-control" placeholder="Ex: Electronic Shop" value="{{ old('name') }}" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold small text-muted">Barcode Prefix <span class="text-danger">*</span></label>
                        <input type="text" name="prefix" class="form-control text-uppercase" placeholder="Ex: M, A, MAIN" maxlength="5" value="{{ old('prefix') }}" required>
                        <small class="text-muted" style="font-size: 0.75rem;">Used for auto-generating barcodes (Max 5 chars).</small>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold small text-muted">Address</label>
                        <input type="text" name="address" class="form-control" placeholder="Location" value="{{ old('address') }}">
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold small text-muted">Phone Number</label>
                        <input type="text" name="phone" class="form-control" placeholder="07x-xxxxxxx" value="{{ old('phone') }}">
                    </div>
                    <button type="submit" class="btn btn-primary w-100 fw-bold">Create Branch</button>
                </form>
            </div>
        </div>
    </div>

    <div class="col-md-8 mb-4">
        <div class="card shadow-sm h-100">
            <div class="card-header bg-transparent py-3">
                <h5 class="mb-0 fw-bold"><i class="bi bi-list-ul"></i> Branch List</h5>
            </div>
            <div class="card-body">
                @if(session('success'))
                    <div class="alert alert-success alert-dismissible fade show">
                        {{ session('success') }}
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                @endif

                <div class="table-responsive">
                    <table class="table table-hover align-middle">
                        <thead>
                            <tr>
                                <th>Prefix</th>
                                <th>Name</th>
                                <th>Address / Phone</th>
                                <th class="text-end">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse($branches as $branch)
                            <tr>
                                <td>
                                    <span class="badge bg-info text-dark border border-info fw-bold fs-6">
                                        {{ $branch->prefix ?? 'N/A' }}
                                    </span>
                                </td>
                                <td>
                                    <span class="fw-bold text-primary">{{ $branch->name }}</span>
                                </td>
                                <td>
                                    <small class="d-block"><i class="bi bi-geo-alt"></i> {{ $branch->address ?? '-' }}</small>
                                    <small class="text-muted"><i class="bi bi-telephone"></i> {{ $branch->phone ?? '-' }}</small>
                                </td>
                                <td class="text-end">
                                    <div class="d-flex justify-content-end gap-2">
                                        <button class="btn btn-sm btn-outline-warning" onclick='editBranch(@json($branch))'>
                                            <i class="bi bi-pencil-square"></i> Edit
                                        </button>
                                        
                                        <form action="{{ route('branches.destroy', $branch->id) }}" method="POST" onsubmit="return confirm('Are you sure you want to delete this branch? All users associated with it might be affected.')">
                                            @csrf @method('DELETE')
                                            <button class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i> Delete</button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                            @empty
                            <tr>
                                <td colspan="4" class="text-center py-4 text-muted">No branches found. Please add a branch.</td>
                            </tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="editBranchModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <form id="editBranchForm" method="POST" class="modal-content">
            @csrf
            @method('PUT')
            <div class="modal-header bg-warning py-3">
                <h5 class="modal-title fw-bold text-dark"><i class="bi bi-pencil-square"></i> Edit Branch</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-4">
                <div class="mb-3">
                    <label class="form-label fw-bold small text-muted">Branch Name <span class="text-danger">*</span></label>
                    <input type="text" name="name" id="edit_name" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label class="form-label fw-bold small text-muted">Barcode Prefix <span class="text-danger">*</span></label>
                    <input type="text" name="prefix" id="edit_prefix" class="form-control text-uppercase" maxlength="5" required>
                </div>
                <div class="mb-3">
                    <label class="form-label fw-bold small text-muted">Address</label>
                    <input type="text" name="address" id="edit_address" class="form-control">
                </div>
                <div class="mb-3">
                    <label class="form-label fw-bold small text-muted">Phone Number</label>
                    <input type="text" name="phone" id="edit_phone" class="form-control">
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="submit" class="btn btn-warning fw-bold text-dark">Update Details</button>
            </div>
        </form>
    </div>
</div>

@endsection

@section('scripts')
<script>
    function editBranch(branch) {
        document.getElementById('edit_name').value = branch.name;
        document.getElementById('edit_prefix').value = branch.prefix;
        document.getElementById('edit_address').value = branch.address || '';
        document.getElementById('edit_phone').value = branch.phone || '';
        
        // 🚨 වෙනස් කළ කොටස: 404 Error එක හදන්න Route එක dynamic විදිහට හැදුවා
        let url = "{{ route('branches.update', ':id') }}";
        url = url.replace(':id', branch.id);
        document.getElementById('editBranchForm').action = url;
        
        new bootstrap.Modal(document.getElementById('editBranchModal')).show();
    }
</script>
@endsection
