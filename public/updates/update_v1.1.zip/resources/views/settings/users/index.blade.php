@extends('layouts.admin')

@section('title', 'User Management')
@section('header', 'Manage System Users')

@section('content')

<div class="row">
    <div class="col-md-4">
        <div class="card shadow-sm">
            <div class="card-header bg-primary text-white">
                <h5 class="mb-0 text-white">Add New User</h5>
            </div>
            <div class="card-body mt-3">
                <form action="{{ route('users.store') }}" method="POST">
                    @csrf
                    
                    <div class="mb-3">
                        <label class="form-label font-bold">Full Name</label>
                        <input type="text" name="name" class="form-control" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label font-bold">Email Address</label>
                        <input type="email" name="email" class="form-control" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label font-bold">Password</label>
                        <input type="password" name="password" class="form-control" placeholder="Min 6 characters" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label font-bold">Role</label>
                        <select name="role" class="form-select" required>
                            <option value="cashier">Cashier</option>
                            <option value="admin">Admin</option>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label class="form-label font-bold">Assign Branch</label>
                        <select name="branch_id" class="form-select">
                            <option value="">-- No Branch (Admin Only) --</option>
                            @foreach($branches as $branch)
                                <option value="{{ $branch->id }}">{{ $branch->name }}</option>
                            @endforeach
                        </select>
                    </div>

                    <button type="submit" class="btn btn-primary w-100 shadow-sm">Create User</button>
                </form>
            </div>
        </div>
    </div>

    <div class="col-md-8">
        <div class="card shadow-sm">
            <div class="card-body">
                @if(session('success'))
                    <div class="alert alert-light-success color-success alert-dismissible fade show" role="alert">
                        <i class="bi bi-check-circle"></i> {{ session('success') }}
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                @endif
                
                @if(session('error'))
                    <div class="alert alert-light-danger color-danger alert-dismissible fade show" role="alert">
                        <i class="bi bi-exclamation-triangle"></i> {{ session('error') }}
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                @endif

                <div class="table-responsive">
                    <table class="table table-hover align-middle">
                        <thead class="thead-light">
                            <tr>
                                <th>ID (Short)</th> 
                                <th>Name / Email</th>
                                <th>Role</th>
                                <th>Branch</th>
                                <th class="text-center">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($users as $user)
                            <tr>
                                <td>
                                    <span class="badge bg-light-secondary text-dark font-monospace" title="{{ $user->id }}">
                                        {{ substr($user->id, 0, 8) }}
                                    </span>
                                </td>
                                <td>
                                    <div class="fw-bold">{{ $user->name }}</div>
                                    <small class="text-muted"><i class="bi bi-envelope"></i> {{ $user->email }}</small>
                                </td>
                                <td>
                                    @if(strtolower($user->role) == 'admin')
                                        <span class="badge bg-danger">Admin</span>
                                    @else
                                        <span class="badge bg-success">Cashier</span>
                                    @endif
                                </td>
                                <td>
                                    @php 
                                        $currentBranch = $branches->firstWhere('id', $user->branch_id); 
                                    @endphp
                                    
                                    @if($currentBranch)
                                        <span class="badge bg-info text-dark">{{ $currentBranch->name }}</span>
                                    @else
                                        <span class="text-muted small">N/A</span>
                                    @endif
                                </td>
                                <td class="text-center">
                                    <button class="btn btn-sm btn-outline-info shadow-sm me-1" onclick="openEditModal('{{ $user->id }}', '{{ addslashes($user->name) }}', '{{ addslashes($user->email) }}', '{{ $user->role }}', '{{ $user->branch_id }}')">
                                        <i class="bi bi-pencil"></i>
                                    </button>

                                    @if($user->id !== auth()->id()) 
                                        <form action="{{ route('users.destroy', $user->id) }}" method="POST" class="d-inline" onsubmit="return confirm('Are you sure you want to delete this user?')">
                                            @csrf @method('DELETE')
                                            <button class="btn btn-sm btn-outline-danger shadow-sm">
                                                <i class="bi bi-trash"></i>
                                            </button>
                                        </form>
                                    @else
                                        <span class="badge bg-light-warning text-dark border border-warning ms-1">Current User</span>
                                    @endif
                                </td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="editUserModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-info">
                <h5 class="modal-title text-dark fw-bold"><i class="bi bi-pencil-square"></i> Edit User Details</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form id="editForm" method="POST">
                @csrf
                @method('PUT')
                <div class="modal-body p-4">
                    <div class="mb-3">
                        <label class="form-label fw-bold">Full Name</label>
                        <input type="text" name="name" id="edit_name" class="form-control" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-bold">Email Address</label>
                        <input type="email" name="email" id="edit_email" class="form-control" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-bold">Password</label>
                        <input type="password" name="password" id="edit_password" class="form-control" placeholder="Leave blank to keep current password">
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-bold">Role</label>
                        <select name="role" id="edit_role" class="form-select" required>
                            <option value="cashier">Cashier</option>
                            <option value="admin">Admin</option>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-bold">Assign Branch</label>
                        <select name="branch_id" id="edit_branch_id" class="form-select">
                            <option value="">-- No Branch (Admin Only) --</option>
                            @foreach($branches as $branch)
                                <option value="{{ $branch->id }}">{{ $branch->name }}</option>
                            @endforeach
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-info fw-bold text-dark ms-1">Update User</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    function openEditModal(id, name, email, role, branch_id) {
        document.getElementById('editForm').action = "/users/" + id;
        document.getElementById('edit_name').value = name;
        document.getElementById('edit_email').value = email;
        document.getElementById('edit_password').value = ""; 
        document.getElementById('edit_role').value = role;
        document.getElementById('edit_branch_id').value = branch_id ? branch_id : "";

        var myModal = new bootstrap.Modal(document.getElementById('editUserModal'));
        myModal.show();
    }
</script>

@endsection
