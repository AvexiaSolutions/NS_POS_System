@extends('layouts.admin')

@section('title', 'General Settings')
@section('header', 'Shop Settings')

@section('content')
<div class="row justify-content-center">
    <div class="col-md-8">
        <div class="card shadow-sm">
            <div class="card-header bg-primary text-white">
                <h5 class="mb-0 text-white"><i class="bi bi-shop me-2"></i> General Information</h5>
            </div>
            <div class="card-body mt-3">
                
                @if(session('success'))
                    <div class="alert alert-light-success color-success alert-dismissible fade show">
                        <i class="bi bi-check-circle me-2"></i> {{ session('success') }}
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                @endif

                <form action="{{ route('settings.update') }}" method="POST" enctype="multipart/form-data">
                    @csrf
                    
                    <div class="text-center mb-4">
                        <div class="mb-2">
                            @if(isset($setting->logo))
                                <img src="{{ asset('storage/' . $setting->logo) }}" 
                                     alt="Shop Logo" 
                                     class="rounded-circle shadow-sm border"
                                     style="width: 120px; height: 120px; object-fit: cover;" 
                                     id="logoPreview">
                            @else
                                <img src="https://via.placeholder.com/120?text=LOGO" 
                                     alt="Default Logo" 
                                     class="rounded-circle shadow-sm border"
                                     style="width: 120px; height: 120px; object-fit: cover;" 
                                     id="logoPreview">
                            @endif
                        </div>
                        <label for="logoInput" class="btn btn-outline-primary btn-sm">
                            <i class="bi bi-camera me-1"></i> Change Logo
                        </label>
                        <input type="file" name="logo" id="logoInput" class="d-none" accept="image/*" onchange="previewLogo(event)">
                        <div class="small text-muted mt-1">Recommended: Square Image (PNG/JPG)</div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-bold">Shop Name</label>
                        <input type="text" name="shop_name" class="form-control form-control-lg" 
                               value="{{ $setting->shop_name ?? 'NS Enterprises' }}" required>
                    </div>

                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Phone Number</label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="bi bi-telephone"></i></span>
                                <input type="text" name="shop_phone" class="form-control" 
                                       value="{{ $setting->shop_phone ?? '' }}" placeholder="07x xxxxxxx">
                            </div>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Address</label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="bi bi-geo-alt"></i></span>
                                <input type="text" name="shop_address" class="form-control" 
                                       value="{{ $setting->shop_address ?? '' }}" placeholder="City, Country">
                            </div>
                        </div>
                    </div>

                    <div class="d-grid mt-3">
                        <button type="submit" class="btn btn-primary btn-lg fw-bold shadow-sm">
                            <i class="bi bi-save me-2"></i> Save Changes
                        </button>
                    </div>
                </form>

            </div>
        </div>
    </div>
</div>

<script>
    function previewLogo(event) {
        var reader = new FileReader();
        reader.onload = function(){
            var output = document.getElementById('logoPreview');
            output.src = reader.result;
        };
        reader.readAsDataURL(event.target.files[0]);
    }
</script>
@endsection
