@extends('layouts.admin')
@section('title', 'Hand in Cash')
@section('header', 'Cash Drawer Management')

@section('content')
<div class="row mb-4">
    <div class="col-md-4">
        <div class="card bg-success text-white h-100 shadow-sm">
            <div class="card-body py-4 text-center">
                <h6 class="text-white opacity-75 text-uppercase fw-bold mb-2">Current Cash in Hand</h6>
                <h2 class="fw-bold mb-0">Rs. {{ number_format($currentCashInHand, 2) }}</h2>
                <small class="opacity-75">Auto-calculated from Sales & Manual Entries</small>
            </div>
        </div>
    </div>
    <div class="col-md-8">
        <div class="card h-100 shadow-sm">
            <div class="card-body d-flex align-items-center justify-content-around flex-wrap gap-2">
                <button class="btn btn-primary fw-bold" data-bs-toggle="modal" data-bs-target="#openingBalanceModal">
                    <i class="bi bi-wallet2"></i> Opening Balance
                </button>
                <button class="btn btn-info fw-bold text-dark" data-bs-toggle="modal" data-bs-target="#fromBankModal">
                    <i class="bi bi-bank"></i> Deposit FROM Bank
                </button>
                <button class="btn btn-success fw-bold" data-bs-toggle="modal" data-bs-target="#otherDepositModal">
                    <i class="bi bi-cash-stack"></i> Other Deposit
                </button>
                <button class="btn btn-warning fw-bold text-dark" data-bs-toggle="modal" data-bs-target="#expenseModal">
                    <i class="bi bi-receipt"></i> Cash Expense
                </button>
            </div>
        </div>
    </div>
</div>

@if(session('success'))
<div class="alert alert-success">{{ session('success') }}</div>
@endif

<div class="card shadow-sm">
    <div class="card-header bg-transparent border-bottom fw-bold">Manual Cash Ledger</div>
    <div class="card-body p-0">
        <table class="table table-hover mb-0">
            <thead class="table-light">
                <tr><th>Date</th><th>Type</th><th>Description</th><th class="text-end">Amount</th></tr>
            </thead>
            <tbody>
                @forelse($transactions as $txn)
                <tr>
                    <td>{{ \Carbon\Carbon::parse($txn->created_at)->format('Y-m-d H:i') }}</td>
                    <td>
                        <span class="badge {{ $txn->type == 'in' ? 'bg-success' : 'bg-danger' }}">
                            {{ strtoupper($txn->category) }}
                        </span>
                    </td>
                    <td>{{ $txn->description }}</td>
                    <td class="text-end fw-bold {{ $txn->type == 'in' ? 'text-success' : 'text-danger' }}">
                        {{ $txn->type == 'in' ? '+' : '-' }} Rs. {{ number_format($txn->amount, 2) }}
                    </td>
                </tr>
                @empty
                <tr><td colspan="4" class="text-center py-4 text-muted">No manual transactions found.</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>

@php
    $modalConfigs = [
        ['id' => 'openingBalanceModal', 'title' => 'Set Opening Balance', 'cat' => 'opening', 'desc' => 'Morning Opening Balance', 'color' => 'primary', 'showBank' => false],
        ['id' => 'fromBankModal', 'title' => 'Withdraw FROM Bank to Cash Drawer', 'cat' => 'from_bank', 'desc' => 'Withdrawn from Bank', 'color' => 'info', 'showBank' => true],
        ['id' => 'otherDepositModal', 'title' => 'Other Cash Deposit', 'cat' => 'other', 'desc' => '', 'color' => 'success', 'showBank' => false],
        ['id' => 'expenseModal', 'title' => 'Record Cash Expense', 'cat' => 'expense', 'desc' => '', 'color' => 'warning', 'showBank' => false],
    ];
@endphp

@foreach($modalConfigs as $modal)
<div class="modal fade" id="{{ $modal['id'] }}" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-{{ $modal['color'] }}">
                <h5 class="modal-title {{ $modal['color'] == 'warning' || $modal['color'] == 'info' ? 'text-dark' : 'text-white' }}">{{ $modal['title'] }}</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form action="{{ route('cashbook.store') }}" method="POST">
                @csrf
                <div class="modal-body">
                    <input type="hidden" name="category" value="{{ $modal['cat'] }}">
                    
                    @if($modal['showBank'])
                    <div class="mb-3">
                        <label>Select Bank Account (Money will be deducted here)</label>
                        <select name="bank_account_id" class="form-select" required>
                            <option value="">-- Choose Bank --</option>
                            @foreach($banks as $bank)
                                <option value="{{ $bank->id }}">{{ $bank->bank_name }} (Bal: {{ number_format($bank->current_balance, 2) }})</option>
                            @endforeach
                        </select>
                    </div>
                    @endif

                    <div class="mb-3">
                        <label>Amount (Rs)</label>
                        <input type="number" step="0.01" name="amount" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label>Description / Reason</label>
                        <input type="text" name="description" class="form-control" value="{{ $modal['desc'] }}" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-{{ $modal['color'] }}">Save Transaction</button>
                </div>
            </form>
        </div>
    </div>
</div>
@endforeach

@endsection
