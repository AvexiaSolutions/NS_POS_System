@extends('layouts.admin')

@section('title', 'Quotations & Custom Bills')
@section('header', 'Quotations & Fake Bills')

@section('content')
<style>
    /* --- Dark Mode Enhancements --- */
    [data-bs-theme="dark"] .card { background-color: #1e1e2d; border-color: #323248; }
    [data-bs-theme="dark"] .form-control, [data-bs-theme="dark"] .form-select { background-color: #2a2a3c !important; border-color: #323248 !important; color: #fff !important; }
    [data-bs-theme="dark"] .form-control:focus { border-color: #435ebe !important; box-shadow: 0 0 0 0.25rem rgba(67, 94, 190, 0.25) !important; }
    [data-bs-theme="dark"] .table { color: #e2e2e2; border-color: #323248; }
    
    /* Fix for the white columns in dark mode */
    [data-bs-theme="dark"] .bg-light { background-color: #2a2a3c !important; }
    [data-bs-theme="dark"] .table-light th { background-color: #2a2a3c !important; color: #fff !important; border-color: #323248 !important; }
    [data-bs-theme="dark"] .list-group-item { background-color: #1e1e2d !important; border-color: #323248 !important; color: #e2e2e2 !important; }
    
    /* Product Search Dropdown */
    .search-dropdown { position: absolute; z-index: 1050; width: 100%; max-height: 250px; overflow-y: auto; display: none; }
    [data-bs-theme="dark"] .search-dropdown .list-group-item:hover { background-color: #323248 !important; cursor: pointer; }
    [data-bs-theme="light"] .search-dropdown .list-group-item:hover { background-color: #f8f9fa !important; cursor: pointer; }

    .qty-input, .price-input { min-width: 80px; font-weight: bold; text-align: center; }

    /* Recent Records Layout Fix */
    .recent-records-card {
        display: flex;
        flex-direction: column;
        height: 100%;
        min-height: 400px; /* Force minimum height */
    }
    .recent-records-body {
        flex-grow: 1; /* Take remaining space */
        overflow-y: auto;
    }
</style>

<div class="row g-4 align-items-stretch">
    <div class="col-lg-7 d-flex flex-column">
        <div class="card shadow-sm flex-grow-1 mb-0">
            <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center py-3">
                <h5 class="mb-0 text-white"><i class="bi bi-cart-plus-fill"></i> Add Items</h5>
                <button class="btn btn-sm btn-light text-primary fw-bold" onclick="openCustomModal()">
                    <i class="bi bi-plus-circle-fill"></i> Custom Item
                </button>
            </div>
            <div class="card-body p-3 d-flex flex-column">
                <div class="position-relative mb-3">
                    <div class="input-group input-group-lg shadow-sm">
                        <span class="input-group-text border-end-0 bg-transparent"><i class="bi bi-search text-muted"></i></span>
                        <input type="text" id="productSearch" class="form-control border-start-0" placeholder="Search or scan product..." oninput="searchProducts(this.value)" onkeydown="if(event.key==='Enter') addFirstProduct()" autocomplete="off" autofocus>
                    </div>
                    <div id="searchDropdown" class="list-group search-dropdown shadow">
                        </div>
                </div>

                <div class="table-responsive flex-grow-1" style="max-height: 60vh;">
                    <table class="table table-bordered table-hover align-middle mb-0">
                        <thead class="table-light position-sticky top-0" style="z-index: 1;">
                            <tr>
                                <th>Item Name</th>
                                <th style="width: 100px;">Qty</th>
                                <th style="width: 130px;">Unit Price (Rs)</th>
                                <th class="text-end" style="width: 120px;">Total</th>
                                <th class="text-center" style="width: 50px;"><i class="bi bi-gear"></i></th>
                            </tr>
                        </thead>
                        <tbody id="quoteItems">
                            <tr><td colspan="5" class="text-center text-muted py-4"><i class="bi bi-basket fs-2 d-block mb-2"></i> No items added yet</td></tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-lg-5 d-flex flex-column">
        <div class="card shadow-sm mb-3 border-top border-4 border-dark flex-shrink-0">
            <div class="card-body p-4">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h5 class="fw-bold mb-0">Document Settings</h5>
                    <div class="form-check form-switch fs-5">
                        <input class="form-check-input" type="checkbox" id="is_fake_bill">
                        <label class="form-check-label small fw-bold mt-1 text-danger">Fake Bill Mode</label>
                    </div>
                </div>

                <div class="mb-4">
                    <label class="form-label small fw-bold text-muted">Customer Name (Optional)</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="bi bi-person"></i></span>
                        <input type="text" id="customer_name" class="form-control form-control-lg" placeholder="Enter Customer Name">
                    </div>
                </div>

                <div class="bg-light p-3 rounded mb-4 border">
                    <div class="d-flex justify-content-between align-items-center">
                        <span class="fs-5 fw-bold text-muted">Total Amount</span>
                        <h2 class="text-primary fw-bold mb-0" id="grandTotal">Rs. 0.00</h2>
                    </div>
                </div>
                
                <input type="hidden" id="editingQuoteId" value="">
                
                <button class="btn btn-dark btn-lg w-100 py-3 fw-bold shadow-sm" id="saveBtn" onclick="saveQuotation()">
                    <i class="bi bi-printer-fill"></i> SAVE & PRINT
                </button>
                <button class="btn btn-outline-danger w-100 py-2 mt-2 fw-bold d-none" id="cancelEditBtn" onclick="cancelEdit()">
                    Cancel Edit
                </button>
            </div>
        </div>
        
        <div class="card shadow-sm recent-records-card">
            <div class="card-header bg-secondary text-white fw-bold"><i class="bi bi-clock-history"></i> Recent Records</div>
            <div class="card-body p-0 recent-records-body">
                <ul class="list-group list-group-flush" id="recentQuotesList">
                    @forelse($quotations as $q)
                        <li class="list-group-item">
                            <div class="d-flex justify-content-between align-items-center mb-2">
                                <div>
                                    <span class="badge {{ $q->is_fake_bill ? 'bg-danger' : 'bg-primary' }}">
                                        {{ $q->is_fake_bill ? 'Fake Bill' : 'Quotation' }}
                                    </span>
                                    <strong class="ms-2">{{ $q->customer_name ?? 'Guest' }}</strong>
                                </div>
                                <span class="fw-bold text-success">Rs. {{ number_format($q->total_amount, 2) }}</span>
                            </div>
                            <div class="d-flex justify-content-between align-items-center">
                                <small class="text-muted"><i class="bi bi-calendar-event"></i> {{ $q->created_at }}</small>
                                <div class="btn-group">
                                    <button class="btn btn-sm btn-outline-primary" onclick="editQuote('{{ $q->id }}')" title="Edit"><i class="bi bi-pencil-square"></i></button>
                                    <a href="{{ route('quotations.print', $q->id) }}" target="_blank" class="btn btn-sm btn-outline-secondary" title="Print"><i class="bi bi-printer"></i></a>
                                    <button class="btn btn-sm btn-outline-danger" onclick="deleteQuote('{{ $q->id }}', this)" title="Delete"><i class="bi bi-trash"></i></button>
                                </div>
                            </div>
                        </li>
                    @empty
                        <li class="list-group-item text-center text-muted py-4">
                            <i class="bi bi-journal-x fs-1 d-block mb-2 opacity-50"></i>
                            No records found.
                        </li>
                    @endforelse
                </ul>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="customItemModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered modal-sm">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white py-2">
                <h6 class="modal-title fw-bold text-white">Add Custom Item</h6>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-3">
                <div class="mb-2">
                    <label class="form-label small fw-bold">Item Name</label>
                    <input type="text" id="customName" class="form-control" placeholder="E.g. Labor Charge">
                </div>
                <div class="row g-2 mb-3">
                    <div class="col-6">
                        <label class="form-label small fw-bold">Qty</label>
                        <input type="number" id="customQty" class="form-control text-center" value="1" min="0.01" step="0.01">
                    </div>
                    <div class="col-6">
                        <label class="form-label small fw-bold">Price (Rs)</label>
                        <input type="number" id="customPrice" class="form-control text-center" value="0" min="0">
                    </div>
                </div>
                <button class="btn btn-primary w-100 fw-bold shadow-sm" onclick="addCustomToTable()">Add to List</button>
            </div>
        </div>
    </div>
</div>

@endsection

@section('scripts')
<script>
    let quoteList = [];
    // Parsing JSON from blade
    let systemProducts = @json($products ?? []); 
    let currentSearchResults = [];

    // Search Products Logic
    function searchProducts(query) {
        let dropdown = document.getElementById('searchDropdown');
        dropdown.innerHTML = '';
        currentSearchResults = [];
        
        if (!query.trim()) {
            dropdown.style.display = 'none';
            return;
        }

        let q = query.toLowerCase();
        let matches = systemProducts.filter(p => {
            let nameMatch = p.product_name && p.product_name.toLowerCase().includes(q);
            let barcodeMatch = p.barcode && p.barcode.toLowerCase().includes(q);
            return nameMatch || barcodeMatch;
        }).slice(0, 8); 

        currentSearchResults = matches;

        if (matches.length > 0) {
            matches.forEach(p => {
                // FIXED: Added Single Quotes ('${p.id}') to handle UUIDs properly and added style="cursor: pointer"
                dropdown.innerHTML += `
                    <div class="list-group-item list-group-item-action d-flex justify-content-between align-items-center" style="cursor: pointer;" onclick="addSystemProduct('${p.id}')">
                        <div>
                            <span class="fw-bold d-block">${p.product_name}</span>
                            <small class="text-muted">Stock: ${parseFloat(p.qty)} ${p.unit || ''}</small>
                        </div>
                        <span class="fw-bold text-success">Rs. ${parseFloat(p.selling_price).toFixed(2)}</span>
                    </div>
                `;
            });
            dropdown.style.display = 'block';
        } else {
            dropdown.innerHTML = '<div class="list-group-item text-muted text-center py-2">No product found</div>';
            dropdown.style.display = 'block';
        }
    }

    // Auto add when enter is pressed
    function addFirstProduct() {
        if(currentSearchResults.length > 0) {
            addSystemProduct(currentSearchResults[0].id);
        }
    }

    // Hide dropdown when clicking outside
    document.addEventListener('click', function(e) {
        if(!document.getElementById('searchDropdown').contains(e.target) && e.target.id !== 'productSearch') {
            document.getElementById('searchDropdown').style.display = 'none';
        }
    });

    function addSystemProduct(id) {
        let product = systemProducts.find(p => p.id == id);
        if(product) {
            let existing = quoteList.find(i => i.product_id == product.id);
            if(existing) {
                existing.qty += 1;
            } else {
                quoteList.push({ 
                    product_id: product.id, 
                    name: product.product_name, 
                    qty: 1, 
                    price: parseFloat(product.selling_price) 
                });
            }
            renderTable();
            let searchInput = document.getElementById('productSearch');
            searchInput.value = '';
            document.getElementById('searchDropdown').style.display = 'none';
            searchInput.focus();
        }
    }

    // Custom Item Logic
    function openCustomModal() {
        document.getElementById('customName').value = '';
        document.getElementById('customQty').value = '1';
        document.getElementById('customPrice').value = '0';
        new bootstrap.Modal(document.getElementById('customItemModal')).show();
        setTimeout(() => document.getElementById('customName').focus(), 500);
    }

    function addCustomToTable() {
        let name = document.getElementById('customName').value.trim();
        let qty = parseFloat(document.getElementById('customQty').value);
        let price = parseFloat(document.getElementById('customPrice').value);

        if(!name) return alert("Please enter item name.");
        if(qty <= 0) return alert("Invalid quantity.");

        quoteList.push({ product_id: null, name: name, qty: qty, price: price });
        renderTable();
        bootstrap.Modal.getInstance(document.getElementById('customItemModal')).hide();
        document.getElementById('productSearch').focus();
    }

    // Table Logic
    function renderTable() {
        let html = '';
        let total = 0;
        
        if (quoteList.length === 0) {
            html = '<tr><td colspan="5" class="text-center text-muted py-4"><i class="bi bi-basket fs-2 d-block mb-2"></i> No items added</td></tr>';
        } else {
            quoteList.forEach((item, index) => {
                let itemTotal = item.qty * item.price;
                total += itemTotal;
                html += `<tr>
                    <td class="fw-bold">${item.name}</td>
                    <td><input type="number" class="form-control form-control-sm qty-input" value="${item.qty}" min="0.01" step="0.01" onchange="updateRow(${index}, 'qty', this.value)"></td>
                    <td><input type="number" class="form-control form-control-sm price-input" value="${item.price}" min="0" onchange="updateRow(${index}, 'price', this.value)"></td>
                    <td class="fw-bold text-end">Rs. ${itemTotal.toFixed(2)}</td>
                    <td class="text-center">
                        <button class="btn btn-sm text-danger" onclick="removeRow(${index})"><i class="bi bi-trash-fill"></i></button>
                    </td>
                </tr>`;
            });
        }
        
        document.getElementById('quoteItems').innerHTML = html;
        document.getElementById('grandTotal').innerText = total.toFixed(2);
    }

    function updateRow(index, field, val) {
        let numericVal = parseFloat(val);
        if(!numericVal || numericVal < 0) numericVal = 0;
        quoteList[index][field] = numericVal;
        renderTable();
    }

    function removeRow(index) {
        quoteList.splice(index, 1);
        renderTable();
    }

    // API Actions (Save, Edit, Delete)
    function saveQuotation() {
        if(quoteList.length === 0) return alert("Please add at least one item!");
        
        let editingId = document.getElementById('editingQuoteId').value;
        let url = editingId ? `{{ url('quotations') }}/${editingId}` : "{{ route('quotations.store') }}";
        let method = "POST";
        
        let data = {
            customer_name: document.getElementById('customer_name').value,
            total_amount: document.getElementById('grandTotal').innerText,
            is_fake_bill: document.getElementById('is_fake_bill').checked ? 1 : 0,
            items: quoteList,
            _token: "{{ csrf_token() }}"
        };

        if(editingId) {
            data._method = "PUT"; // Use Laravel's method spoofing
        }

        let btn = document.getElementById('saveBtn');
        btn.disabled = true;
        btn.innerHTML = 'Saving...';

        fetch(url, {
            method: method,
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(data)
        })
        .then(res => res.json())
        .then(res => {
            if(res.status === 'success' || res.id) {
                let printId = res.id || editingId;
                window.open("{{ url('quotations/print') }}/" + printId, '_blank', 'width=400,height=600');
                location.reload();
            } else {
                alert("Error saving document.");
                btn.disabled = false;
                btn.innerHTML = '<i class="bi bi-printer-fill"></i> SAVE & PRINT';
            }
        }).catch(e => {
            console.error(e);
            alert("System Error! Check console.");
            btn.disabled = false;
            btn.innerHTML = '<i class="bi bi-printer-fill"></i> SAVE & PRINT';
        });
    }

    function editQuote(id) {
        fetch(`{{ url('quotations') }}/${id}/edit`)
        .then(res => res.json())
        .then(data => {
            if(data.status === 'error') {
                return alert(data.message);
            }
            
            document.getElementById('editingQuoteId').value = data.id;
            document.getElementById('customer_name').value = data.customer_name;
            document.getElementById('is_fake_bill').checked = data.is_fake_bill == 1;
            
            quoteList = typeof data.items === 'string' ? JSON.parse(data.items) : data.items;
            
            renderTable();

            document.getElementById('saveBtn').innerHTML = '<i class="bi bi-pencil-square"></i> UPDATE & PRINT';
            document.getElementById('saveBtn').classList.replace('btn-dark', 'btn-warning');
            document.getElementById('saveBtn').classList.replace('text-white', 'text-dark');
            document.getElementById('cancelEditBtn').classList.remove('d-none');
            window.scrollTo(0, 0); 
        }).catch(e => {
            console.error(e);
            alert("Error loading data.");
        });
    }

    function cancelEdit() {
        document.getElementById('editingQuoteId').value = '';
        document.getElementById('customer_name').value = '';
        document.getElementById('is_fake_bill').checked = false;
        quoteList = [];
        renderTable();
        
        let saveBtn = document.getElementById('saveBtn');
        saveBtn.innerHTML = '<i class="bi bi-printer-fill"></i> SAVE & PRINT';
        saveBtn.classList.replace('btn-warning', 'btn-dark');
        saveBtn.classList.add('text-white');
        
        document.getElementById('cancelEditBtn').classList.add('d-none');
    }

    // Delete instantly without confirm prompt
    function deleteQuote(id, btnElement) {
        // Change button icon to loading spinner instantly
        let originalHtml = btnElement.innerHTML;
        btnElement.innerHTML = '<span class="spinner-border spinner-border-sm"></span>';
        btnElement.disabled = true;

        fetch(`{{ url('quotations') }}/${id}`, {
            method: 'DELETE',
            headers: { 
                "Content-Type": "application/json",
                "X-CSRF-TOKEN": "{{ csrf_token() }}" 
            }
        })
        .then(res => res.json())
        .then(res => {
            if(res.status === 'success') {
                location.reload(); // Instantly reload page
            } else {
                alert("Failed to delete.");
                btnElement.innerHTML = originalHtml;
                btnElement.disabled = false;
            }
        }).catch(e => {
            console.error(e);
            alert("Delete failed.");
            btnElement.innerHTML = originalHtml;
            btnElement.disabled = false;
        });
    }
</script>
@endsection
