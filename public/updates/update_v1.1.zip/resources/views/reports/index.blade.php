@extends('layouts.admin')

@section('title', 'Business Reports')
@section('header', 'Comprehensive Business Analysis')

@section('content')
<style>
    /* --- Dark Mode & UI Enhancements --- */
    [data-bs-theme="dark"] .card { background-color: #1e1e2d; border-color: #323248; }
    [data-bs-theme="dark"] .form-control { background-color: #2a2a3c !important; border: 1px solid #323248 !important; color: #fff !important; }
    [data-bs-theme="dark"] .table { color: #e2e2e2; border-color: #323248; }
    [data-bs-theme="dark"] .table-light th { background-color: #2a2a3c !important; color: #fff !important; border-color: #323248 !important; }
    [data-bs-theme="dark"] .table-hover tbody tr:hover { color: #fff; background-color: #2a2a3c; }
    [data-bs-theme="dark"] .nav-pills .nav-link { color: #a0a0a0; }
    [data-bs-theme="dark"] .nav-pills .nav-link.active { background-color: #435ebe; color: #fff; }

    /* --- Hover Effects --- */
    .stat-card { transition: transform 0.2s, box-shadow 0.2s; }
    .stat-card:hover { transform: translateY(-5px); box-shadow: 0 10px 20px rgba(0,0,0,0.1) !important; }
    [data-bs-theme="dark"] .stat-card:hover { box-shadow: 0 10px 20px rgba(0,0,0,0.4) !important; }

    /* --- Print Styles --- */
    @media print {
        body * { visibility: hidden; }
        #printableArea, #printableArea * { visibility: visible; }
        #printableArea { position: absolute; left: 0; top: 0; width: 100%; }
        .no-print { display: none !important; }
        .card { border: none !important; box-shadow: none !important; }
        .tab-pane { display: block !important; opacity: 1 !important; visibility: visible !important; margin-bottom: 30px;}
        .print-break { page-break-after: always; }
    }
</style>

<div class="row mb-4 no-print">
    <div class="col-12">
        <div class="card shadow-sm border-0">
            <div class="card-body">
                <form action="{{ route('reports.index') }}" method="GET" class="row g-3 align-items-end">
                    <div class="col-md-3">
                        <label class="form-label fw-bold text-muted small">Start Date</label>
                        <input type="date" name="start_date" class="form-control fw-bold" value="{{ $startDate ?? '' }}" required>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label fw-bold text-muted small">End Date</label>
                        <input type="date" name="end_date" class="form-control fw-bold" value="{{ $endDate ?? '' }}" required>
                    </div>
                    <div class="col-md-6 d-flex gap-2 flex-wrap">
                        <button type="submit" class="btn btn-primary fw-bold px-3"><i class="bi bi-funnel"></i> Filter</button>
                        <a href="{{ route('reports.index') }}" class="btn btn-light-secondary fw-bold px-3"><i class="bi bi-arrow-clockwise"></i> Reset</a>
                        
                        <div class="ms-auto d-flex gap-2">
                            <button type="button" onclick="exportToCSV()" class="btn btn-outline-success fw-bold"><i class="bi bi-file-earmark-excel"></i> CSV</button>
                            <button type="button" onclick="exportToPDF()" class="btn btn-outline-danger fw-bold"><i class="bi bi-file-earmark-pdf"></i> PDF</button>
                            <button type="button" onclick="window.print()" class="btn btn-dark fw-bold px-4"><i class="bi bi-printer"></i> Print</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<ul class="nav nav-pills mb-4 no-print gap-2" id="reportTabs" role="tablist">
    <li class="nav-item"><button class="nav-link active fw-bold px-4 rounded-pill" data-bs-toggle="pill" data-bs-target="#tab-finance" type="button"><i class="bi bi-cash-stack me-2"></i> Financial & Sales</button></li>
    <li class="nav-item"><button class="nav-link fw-bold px-4 rounded-pill" data-bs-toggle="pill" data-bs-target="#tab-inventory" type="button"><i class="bi bi-boxes me-2"></i> Inventory & Stock</button></li>
    <li class="nav-item"><button class="nav-link fw-bold px-4 rounded-pill" data-bs-toggle="pill" data-bs-target="#tab-staff" type="button"><i class="bi bi-people-fill me-2"></i> Staff Performance</button></li>
    <li class="nav-item"><button class="nav-link fw-bold px-4 rounded-pill" data-bs-toggle="pill" data-bs-target="#tab-returns" type="button"><i class="bi bi-arrow-counterclockwise me-2"></i> Returns</button></li>
    <li class="nav-item"><button class="nav-link fw-bold px-4 rounded-pill" data-bs-toggle="pill" data-bs-target="#tab-bank" type="button"><i class="bi bi-bank me-2"></i> Cash & Bank</button></li>
</ul>

<div id="printableArea">
    
    <div class="row mb-4 print-header d-none d-print-block text-center">
        <h2>Business Performance Report</h2>
        <p class="fw-bold">Period: {{ \Carbon\Carbon::parse($startDate ?? now())->format('d M Y') }} to {{ \Carbon\Carbon::parse($endDate ?? now())->format('d M Y') }}</p>
        <hr>
    </div>

    <div class="tab-content" id="reportTabsContent">
        
        <div class="tab-pane fade show active" id="tab-finance" role="tabpanel">
            <h4 class="mb-3 d-none d-print-block fw-bold text-decoration-underline">1. Financial & Sales Overview</h4>
            
            <div class="row g-3 mb-4">
                <div class="col-md-3 col-6">
                    <div class="card shadow-sm stat-card border-primary border-bottom border-4 h-100 mb-0">
                        <div class="card-body text-center py-4">
                            <h6 class="text-muted fw-bold text-uppercase small">Gross Sales</h6>
                            <h3 class="fw-bold mb-0 text-primary">Rs. {{ number_format($totalSales ?? 0, 2) }}</h3>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-6">
                    <div class="card shadow-sm stat-card border-danger border-bottom border-4 h-100 mb-0">
                        <div class="card-body text-center py-4">
                            <h6 class="text-muted fw-bold text-uppercase small">Cost of Goods (COGS)</h6>
                            <h3 class="fw-bold mb-0 text-danger">Rs. {{ number_format($totalCost ?? 0, 2) }}</h3>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-6">
                    <div class="card shadow-sm stat-card border-warning border-bottom border-4 h-100 mb-0">
                        <div class="card-body text-center py-4">
                            <h6 class="text-muted fw-bold text-uppercase small">Shop Expenses</h6>
                            <h4 class="fw-bold mb-0 text-warning">Rs. {{ number_format($totalExpenses ?? 0, 2) }}</h4>
                            <small class="text-muted" style="font-size: 11px;">(Rent, Bills, Salaries)</small>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-6">
                    <div class="card shadow-sm stat-card border-success border-bottom border-4 h-100 mb-0 bg-light-success">
                        <div class="card-body text-center py-4">
                            <h6 class="text-success fw-bold text-uppercase small">Net Profit</h6>
                            <h3 class="fw-bold mb-0 text-success">Rs. {{ number_format($netProfit ?? 0, 2) }}</h3>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row g-3 mb-4">
                <div class="col-md-4">
                    <div class="card shadow-sm h-100">
                        <div class="card-header bg-transparent"><h6 class="mb-0 fw-bold">Deductions Summary</h6></div>
                        <div class="card-body">
                            <ul class="list-group list-group-flush">
                                <li class="list-group-item d-flex justify-content-between align-items-center bg-transparent">
                                    <span><i class="bi bi-tags text-warning me-2"></i> Customer Discounts</span>
                                    <span class="fw-bold">Rs. {{ number_format($totalDiscount ?? 0, 2) }}</span>
                                </li>
                                <li class="list-group-item d-flex justify-content-between align-items-center bg-transparent">
                                    <span><i class="bi bi-credit-card text-danger me-2"></i> Bank Charges (3%)</span>
                                    <span class="fw-bold">Rs. {{ number_format($totalBankCharges ?? 0, 2) }}</span>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-md-8">
                     <div class="card shadow-sm h-100">
                        <div class="card-header bg-transparent"><h6 class="mb-0 fw-bold">Recent Invoices</h6></div>
                        <div class="card-body p-0" style="max-height: 200px; overflow-y: auto;">
                            <table class="table table-sm table-hover mb-0">
                                <thead class="table-light sticky-top">
                                    <tr><th>Inv No</th><th>Date</th><th>Method</th><th class="text-end">Amount</th></tr>
                                </thead>
                                <tbody>
                                    @forelse($salesList ?? [] as $sale)
                                    <tr>
                                        <td class="fw-bold">{{ $sale->invoice_no ?? 'N/A' }}</td>
                                        <td>{{ isset($sale->created_at) ? \Carbon\Carbon::parse($sale->created_at)->format('Y-m-d') : 'N/A' }}</td>
                                        <td><span class="badge {{ ($sale->payment_method ?? '') == 'card' ? 'bg-primary' : 'bg-success' }}">{{ strtoupper($sale->payment_method ?? 'N/A') }}</span></td>
                                        <td class="text-end fw-bold">Rs. {{ number_format($sale->total_amount ?? 0, 2) }}</td>
                                    </tr>
                                    @empty
                                    <tr><td colspan="4" class="text-center text-muted py-3">No sales found.</td></tr>
                                    @endforelse
                                </tbody>
                            </table>
                        </div>
                     </div>
                </div>
            </div>
            <div class="print-break"></div>
        </div>

        <div class="tab-pane fade" id="tab-inventory" role="tabpanel">
            <h4 class="mb-3 d-none d-print-block fw-bold text-decoration-underline">2. Inventory & Stock Valuation</h4>
            <div class="row g-3 mb-4">
                <div class="col-md-4">
                    <div class="card shadow-sm stat-card border-info border-start border-4 h-100 mb-0">
                        <div class="card-body py-4">
                            <h6 class="text-muted fw-bold text-uppercase small mb-1">Total Stock Value (Cost)</h6>
                            <h4 class="fw-bold mb-0 text-info">Rs. {{ number_format($stockValueCost ?? 0, 2) }}</h4>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card shadow-sm stat-card border-success border-start border-4 h-100 mb-0">
                        <div class="card-body py-4">
                            <h6 class="text-muted fw-bold text-uppercase small mb-1">Expected Revenue</h6>
                            <h4 class="fw-bold mb-0 text-success">Rs. {{ number_format($stockValueSelling ?? 0, 2) }}</h4>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card shadow-sm stat-card border-danger border-start border-4 h-100 mb-0">
                        <div class="card-body py-4">
                            <h6 class="text-muted fw-bold text-uppercase small mb-1">Low Stock Items</h6>
                            <h4 class="fw-bold mb-0 text-danger">{{ $lowStockItemsCount ?? 0 }} Items</h4>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row g-3">
                <div class="col-md-6">
                    <div class="card shadow-sm h-100">
                        <div class="card-header bg-transparent border-bottom"><h6 class="mb-0 fw-bold"><i class="bi bi-graph-up-arrow text-success me-2"></i> Fast Moving Items</h6></div>
                        <div class="card-body p-0 table-responsive">
                            <table class="table table-hover align-middle mb-0">
                                <thead class="table-light"><tr><th>Product Name</th><th class="text-center">Qty Sold</th></tr></thead>
                                <tbody>
                                    @forelse($topSellingProducts ?? [] as $item)
                                    <tr><td>{{ $item->product_name ?? 'N/A' }}</td><td class="text-center fw-bold text-success">{{ $item->total_sold ?? 0 }}</td></tr>
                                    @empty
                                    <tr><td colspan="2" class="text-center text-muted py-3">No data available</td></tr>
                                    @endforelse
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card shadow-sm h-100">
                        <div class="card-header bg-transparent border-bottom"><h6 class="mb-0 fw-bold"><i class="bi bi-exclamation-triangle text-danger me-2"></i> Dead / Slow Moving Stock</h6></div>
                        <div class="card-body p-0 table-responsive">
                            <table class="table table-hover align-middle mb-0">
                                <thead class="table-light"><tr><th>Product Name</th><th class="text-center">Current Qty</th></tr></thead>
                                <tbody>
                                    @forelse($deadStock ?? [] as $item)
                                    <tr><td>{{ $item->product_name ?? 'N/A' }}</td><td class="text-center fw-bold text-danger">{{ $item->qty ?? 0 }}</td></tr>
                                    @empty
                                    <tr><td colspan="2" class="text-center text-muted py-3">No dead stock found.</td></tr>
                                    @endforelse
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <div class="print-break"></div>
        </div>

        <div class="tab-pane fade" id="tab-staff" role="tabpanel">
            <h4 class="mb-3 d-none d-print-block fw-bold text-decoration-underline">3. Staff Performance</h4>
            <div class="row g-3 mb-4">
                <div class="col-md-6">
                    <div class="card shadow-sm h-100">
                        <div class="card-header bg-transparent border-bottom"><h6 class="mb-0 fw-bold"><i class="bi bi-person-badge me-2"></i> Cashier Performance</h6></div>
                        <div class="card-body p-0 table-responsive">
                            <table class="table table-hover align-middle mb-0">
                                <thead class="table-light"><tr><th>Name</th><th class="text-center">Bills</th><th class="text-end">Revenue</th></tr></thead>
                                <tbody>
                                    @forelse($cashierPerformance ?? [] as $cashier)
                                    <tr>
                                        <td class="fw-bold">{{ $cashier->name ?? 'N/A' }}</td>
                                        <td class="text-center"><span class="badge bg-secondary">{{ $cashier->total_bills ?? 0 }}</span></td>
                                        <td class="text-end fw-bold text-success">Rs. {{ number_format($cashier->total_collected ?? 0, 2) }}</td>
                                    </tr>
                                    @empty
                                    <tr><td colspan="3" class="text-center text-muted py-3">No data available</td></tr>
                                    @endforelse
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                     <div class="card shadow-sm h-100">
                        <div class="card-header bg-transparent border-bottom"><h6 class="mb-0 fw-bold"><i class="bi bi-pie-chart me-2"></i> Payment Methods</h6></div>
                        <div class="card-body py-4">
                            <div class="mb-3 px-3">
                                <div class="d-flex justify-content-between mb-1"><span>Cash ({{ $cashPercentage ?? 0 }}%)</span><b>Rs. {{ number_format($cashTotal ?? 0, 2) }}</b></div>
                                <div class="progress" style="height: 10px;"><div class="progress-bar bg-success" style="width: {{ $cashPercentage ?? 0 }}%;"></div></div>
                            </div>
                            <div class="px-3">
                                <div class="d-flex justify-content-between mb-1"><span>Card ({{ $cardPercentage ?? 0 }}%)</span><b>Rs. {{ number_format($cardTotal ?? 0, 2) }}</b></div>
                                <div class="progress" style="height: 10px;"><div class="progress-bar bg-primary" style="width: {{ $cardPercentage ?? 0 }}%;"></div></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="print-break"></div>
        </div>

        <div class="tab-pane fade" id="tab-returns" role="tabpanel">
            <h4 class="mb-3 d-none d-print-block fw-bold text-decoration-underline">4. Returns Analysis</h4>
            <div class="card shadow-sm">
                <div class="card-header bg-transparent border-bottom d-flex justify-content-between py-3">
                    <h5 class="mb-0 fw-bold">Returned Items</h5>
                    <span class="badge bg-danger">Total: Rs. {{ number_format($totalReturnValue ?? 0, 2) }}</span>
                </div>
                <div class="card-body p-0 table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-light"><tr><th>Date</th><th>Inv No</th><th>Product</th><th>Type</th><th class="text-end">Value</th></tr></thead>
                        <tbody>
                            @forelse($returnsList ?? [] as $return)
                            <tr>
                                <td>{{ isset($return->created_at) ? \Carbon\Carbon::parse($return->created_at)->format('Y-m-d') : 'N/A' }}</td>
                                <td class="fw-bold">{{ $return->invoice_no ?? 'N/A' }}</td>
                                <td>{{ $return->product_name ?? 'N/A' }}</td>
                                <td><span class="badge bg-info">{{ strtoupper($return->type ?? 'N/A') }}</span></td>
                                <td class="text-end fw-bold text-danger">Rs. {{ number_format($return->refund_amount ?? 0, 2) }}</td>
                            </tr>
                            @empty
                            <tr><td colspan="5" class="text-center py-5 text-muted">No returns recorded.</td></tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="print-break"></div>
        </div>

        <div class="tab-pane fade" id="tab-bank" role="tabpanel">
            <h4 class="mb-3 d-none d-print-block fw-bold text-decoration-underline">5. Cash & Bank Balances</h4>
            <div class="row g-3 mb-4">
                <div class="col-md-4">
                    <div class="card shadow-sm stat-card border-success border-bottom border-4 h-100 mb-0 bg-light-success">
                        <div class="card-body text-center py-4">
                            <h6 class="text-success fw-bold text-uppercase small">Current Cash in Hand</h6>
                            <h3 class="fw-bold mb-0 text-success">Rs. {{ number_format($cashInHand ?? 0, 2) }}</h3>
                        </div>
                    </div>
                </div>
                <div class="col-md-8">
                     <div class="card shadow-sm h-100">
                        <div class="card-header bg-transparent border-bottom"><h6 class="mb-0 fw-bold"><i class="bi bi-safe"></i> Active Bank Accounts</h6></div>
                        <div class="card-body p-0" style="max-height: 250px; overflow-y: auto;">
                            <table class="table table-hover align-middle mb-0">
                                <thead class="table-light sticky-top">
                                    <tr>
                                        <th>Bank Name</th>
                                        <th>Account Number</th>
                                        <th class="text-end">Current Balance</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @forelse($banks ?? [] as $bank)
                                    <tr>
                                        <td class="fw-bold">{{ $bank->bank_name }} {!! $bank->is_primary ? '<i class="bi bi-star-fill text-warning fs-6"></i>' : '' !!}</td>
                                        <td class="font-monospace text-muted">{{ $bank->account_number }}</td>
                                        <td class="text-end fw-bold text-primary fs-5">Rs. {{ number_format($bank->current_balance, 2) }}</td>
                                    </tr>
                                    @empty
                                    <tr><td colspan="3" class="text-center text-muted py-4">No bank accounts found.</td></tr>
                                    @endforelse
                                </tbody>
                            </table>
                        </div>
                     </div>
                </div>
            </div>
        </div>

    </div>
</div>
@endsection

@section('scripts')
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>

<script>
    document.addEventListener("DOMContentLoaded", function() {
        let hash = window.location.hash;
        if (hash) {
            let tabTrigger = document.querySelector(`.nav-link[data-bs-target="${hash}"]`);
            if (tabTrigger) { (new bootstrap.Tab(tabTrigger)).show(); }
        }
        let form = document.querySelector('form');
        document.querySelectorAll('.nav-link').forEach(link => {
            link.addEventListener('shown.bs.tab', e => {
                let target = e.target.getAttribute('data-bs-target');
                window.location.hash = target;
                form.action = "{{ route('reports.index') }}" + target;
            });
        });
    });

    // ==========================================
    // 1. CSV EXPORT FUNCTION
    // ==========================================
    function exportToCSV() {
        let activeTab = document.querySelector('.tab-pane.active');
        if(!activeTab) return;
        
        let tables = activeTab.querySelectorAll('table');
        if(tables.length === 0) {
            alert('No data tables found in the current tab to export.');
            return;
        }

        let csv = [];
        tables.forEach(table => {
            let rows = table.querySelectorAll('tr');
            for (let i = 0; i < rows.length; i++) {
                let row = [], cols = rows[i].querySelectorAll('td, th');
                for (let j = 0; j < cols.length; j++) {
                    let data = cols[j].innerText.replace(/(\r\n|\n|\r)/gm, "").replace(/"/g, '""');
                    row.push('"' + data + '"');
                }
                csv.push(row.join(','));
            }
            csv.push(""); 
        });
        
        let csvFile = new Blob([csv.join('\n')], {type: 'text/csv'});
        let downloadLink = document.createElement('a');
        downloadLink.download = 'Business_Report_' + new Date().toISOString().slice(0,10) + '.csv';
        downloadLink.href = window.URL.createObjectURL(csvFile);
        downloadLink.style.display = 'none';
        document.body.appendChild(downloadLink);
        downloadLink.click();
        document.body.removeChild(downloadLink);
    }

    // ==========================================
    // 2. PDF EXPORT FUNCTION
    // ==========================================
    function exportToPDF() {
        let allTabs = document.querySelectorAll('.tab-pane');
        allTabs.forEach(tab => {
            tab.classList.add('show', 'active');
            tab.style.display = 'block';
        });

        let element = document.getElementById('printableArea');
        let opt = {
            margin:       0.3,
            filename:     'Business_Report_' + new Date().toISOString().slice(0,10) + '.pdf',
            image:        { type: 'jpeg', quality: 0.98 },
            html2canvas:  { scale: 2 },
            jsPDF:        { unit: 'in', format: 'a4', orientation: 'portrait' }
        };

        html2pdf().set(opt).from(element).save().then(() => {
            allTabs.forEach(tab => {
                tab.classList.remove('show', 'active');
                tab.style.display = '';
            });
            let activeTabHash = window.location.hash || '#tab-finance';
            let activeTab = document.querySelector(activeTabHash);
            if(activeTab) activeTab.classList.add('show', 'active');
        });
    }
</script>
@endsection
