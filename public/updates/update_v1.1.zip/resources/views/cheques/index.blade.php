@extends('layouts.admin')

@section('title', 'Cheque Management')
@section('header', 'Manage Cheques')

@section('content')
<style>
    /* --- Dark Mode Enhancements for Inputs & Modals --- */
    [data-bs-theme="dark"] .card { background-color: #1e1e2d; border-color: #323248; }
    
    /* Input & Select Box styling for Dark Mode */
    [data-bs-theme="dark"] .form-control, 
    [data-bs-theme="dark"] .form-select { 
        background-color: #2a2a3c !important; 
        border: 1px solid #323248 !important; 
        color: #fff !important; 
    }
    
    [data-bs-theme="dark"] .form-control:focus, 
    [data-bs-theme="dark"] .form-select:focus { 
        border-color: #435ebe !important; 
        box-shadow: 0 0 0 0.25rem rgba(67, 94, 190, 0.25) !important; 
    }

    /* Modal Styling for Dark Mode */
    [data-bs-theme="dark"] .modal-content { 
        background-color: #1e1e2d !important; 
        border: 1px solid #323248 !important; 
    }
    [data-bs-theme="dark"] .modal-header, 
    [data-bs-theme="dark"] .modal-footer { 
        border-color: #323248 !important; 
    }
    [data-bs-theme="dark"] .btn-close { filter: invert(1) grayscale(100%) brightness(200%); }

    /* Table & Header Dark Mode Fix */
    [data-bs-theme="dark"] .table { color: #e2e2e2; border-color: #323248; }
    [data-bs-theme="dark"] .table-light th {
        background-color: #2a2a3c !important;
        color: #fff !important;
        border-color: #323248 !important;
    }
    [data-bs-theme="dark"] .table-hover tbody tr:hover { color: #fff; background-color: #2a2a3c; }

    /* Conditional Row Colors for Dark Mode */
    [data-bs-theme="dark"] .table-light-success td { background-color: rgba(25, 135, 84, 0.1) !important; }
    [data-bs-theme="dark"] .table-light-danger td { background-color: rgba(220, 53, 69, 0.1) !important; }

    /* Clickable Elements */
    .badge-clickable { cursor: pointer; transition: 0.2s; }
    .badge-clickable:hover { opacity: 0.8; transform: scale(1.05); }
</style>

<div class="row mb-4">
    <div class="col-md-12 d-flex gap-2">
        <button class="btn btn-success fw-bold shadow-sm" data-bs-toggle="modal" data-bs-target="#chequeModal" onclick="setType('received')">
            <i class="bi bi-arrow-down-left-circle"></i> Cheque Received
        </button>
        <button class="btn btn-danger fw-bold shadow-sm" data-bs-toggle="modal" data-bs-target="#chequeModal" onclick="setType('issued')">
            <i class="bi bi-arrow-up-right-circle"></i> Cheque Issued
        </button>
    </div>
</div>

<div class="card shadow-sm">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover align-middle">
                <thead class="table-light">
                    <tr>
                        <th>Due Date</th>
                        <th>Type</th>
                        <th>Bank / Acc No</th>
                        <th>Cheque No</th>
                        <th>Payee / Payer</th>
                        <th class="text-end">Amount</th>
                        <th class="text-center">Status</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($cheques as $cheque)
                    <tr class="{{ $cheque->type == 'issued' ? 'table-light-danger' : 'table-light-success' }}">
                        <td class="fw-bold">{{ \Carbon\Carbon::parse($cheque->cheque_date)->format('Y-m-d') }}</td>
                        <td>
                            <span class="badge {{ $cheque->type == 'issued' ? 'bg-danger' : 'bg-success' }}">
                                {{ strtoupper($cheque->type) }}
                            </span>
                        </td>
                        <td>
                            <div class="fw-bold">{{ $cheque->bank_name }}</div>
                            <small class="text-muted">{{ $cheque->account_no ?? 'N/A' }}</small>
                        </td>
                        <td class="fw-bold">{{ $cheque->cheque_number }}</td>
                        <td>{{ $cheque->customer_name }}</td>
                        <td class="fw-bold text-end">Rs. {{ number_format($cheque->amount, 2) }}</td>
                        <td class="text-center">
                            @if($cheque->status == 'pending')
                                <span class="badge bg-warning text-dark badge-clickable" 
                                      onclick="openRealizeModal('{{ $cheque->id }}', '{{ $cheque->type }}', '{{ $cheque->amount }}')"
                                      title="Click to Realize">
                                    PENDING
                                </span>
                            @else
                                <span class="badge bg-primary">REALIZED</span>
                            @endif
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="7" class="text-center py-4 text-muted">No cheque records found.</td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="modal fade" id="chequeModal" tabindex="-1" data-bs-backdrop="static">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <form action="{{ route('cheques.store') }}" method="POST" class="modal-content">
            @csrf
            <input type="hidden" name="type" id="cheque_type">
            
            <div class="modal-header bg-dark text-white py-3">
                <h5 class="modal-title fw-bold text-white" id="modalTitle">Record Cheque</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            
            <div class="modal-body p-4">
                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label small fw-bold text-muted">Bank Name <span class="text-danger">*</span></label>
                        <input type="text" name="bank_name" class="form-control" placeholder="e.g. BOC, Commercial" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label small fw-bold text-muted">Account Number</label>
                        <input type="text" name="account_no" class="form-control">
                    </div>
                    
                    <div class="col-md-4">
                        <label class="form-label small fw-bold text-muted">Cheque Number <span class="text-danger">*</span></label>
                        <input type="text" name="cheque_number" class="form-control" required>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label small fw-bold text-muted">Amount (Rs) <span class="text-danger">*</span></label>
                        <input type="number" step="0.01" name="amount" class="form-control text-end fw-bold" required>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label small fw-bold text-muted">Due Date <span class="text-danger">*</span></label>
                        <input type="date" name="cheque_date" class="form-control" required>
                    </div>
                    
                    <div class="col-md-12 mt-4 border-top pt-3">
                        <div class="form-check form-switch mb-3">
                            <input class="form-check-input fs-5" type="checkbox" name="is_supplier" id="is_supplier" value="1" onchange="toggleSupplier()">
                            <label class="form-check-label fw-bold mt-1 ms-2">Is this a Supplier?</label>
                        </div>
                        
                        <div id="supplier_div" style="display: none;">
                            <select name="supplier_id" class="form-select">
                                <option value="">Select Supplier</option>
                                @foreach($suppliers as $s) <option value="{{ $s->id }}">{{ $s->company_name }}</option> @endforeach
                            </select>
                        </div>
                        
                        <div id="other_div">
                            <label class="form-label small fw-bold text-muted">Name (Payer / Payee) <span class="text-danger">*</span></label>
                            <input type="text" name="customer_name" class="form-control" placeholder="Enter full name">
                        </div>
                    </div>
                    
                    <div class="col-md-12">
                        <label class="form-label small fw-bold text-muted">Additional Notes</label>
                        <textarea name="note" class="form-control" rows="2" placeholder="Note..."></textarea>
                    </div>
                </div>
            </div>
            
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="submit" class="btn btn-primary fw-bold px-4">Save Record</button>
            </div>
        </form>
    </div>
</div>

<div class="modal fade" id="realizeModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <form action="{{ route('cheques.realize') }}" method="POST" class="modal-content border-primary shadow-lg">
            @csrf
            <input type="hidden" name="cheque_id" id="realize_cheque_id">
            
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title fw-bold text-white"><i class="bi bi-check2-circle"></i> Realize Cheque</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            
            <div class="modal-body p-4 text-center">
                <div class="mb-3">
                    <p id="realizeMsg" class="fs-6"></p>
                    <h3 class="fw-bold text-primary" id="realizeAmountDisplay"></h3>
                </div>
                
                <div class="text-start">
                    <label class="form-label fw-bold small" id="bankLabel">Select Bank Account</label>
                    <select name="bank_account_id" class="form-select form-select-lg" required>
                        <option value="">-- Choose Bank --</option>
                        @foreach($banks as $bank)
                            <option value="{{ $bank->id }}">{{ $bank->bank_name }} ({{ $bank->account_number }}) - Bal: {{ number_format($bank->current_balance, 2) }}</option>
                        @endforeach
                    </select>
                    <small class="text-muted d-block mt-2" id="bankHelp"></small>
                </div>
            </div>
            
            <div class="modal-footer border-0">
                <button type="submit" class="btn btn-primary w-100 py-2 fw-bold shadow-sm">Confirm & Update Balance</button>
            </div>
        </form>
    </div>
</div>

<script>
// Toggle logic for adding new cheque
function setType(type) {
    document.getElementById('cheque_type').value = type;
    let title = document.getElementById('modalTitle');
    let header = document.querySelector('#chequeModal .modal-header');
    
    if(type === 'received') {
        title.innerHTML = '<i class="bi bi-arrow-down-left-circle"></i> Record Received Cheque';
        header.className = 'modal-header bg-success text-white py-3';
    } else {
        title.innerHTML = '<i class="bi bi-arrow-up-right-circle"></i> Record Issued Cheque';
        header.className = 'modal-header bg-danger text-white py-3';
    }
}

function toggleSupplier() {
    let isSup = document.getElementById('is_supplier').checked;
    document.getElementById('supplier_div').style.display = isSup ? 'block' : 'none';
    document.getElementById('other_div').style.display = isSup ? 'none' : 'block';
}

// Function to trigger the realization modal
function openRealizeModal(id, type, amount) {
    document.getElementById('realize_cheque_id').value = id;
    // Formatting the amount for display
    let formattedAmount = parseFloat(amount).toLocaleString('en-US', { minimumFractionDigits: 2 });
    document.getElementById('realizeAmountDisplay').innerText = 'Rs. ' + formattedAmount;
    
    let msg = document.getElementById('realizeMsg');
    let label = document.getElementById('bankLabel');
    let help = document.getElementById('bankHelp');

    if(type === 'received') {
        msg.innerText = "To which bank account should this amount be deposited?";
        label.innerText = "Deposit To Account";
        help.innerText = "The amount will be ADDED to this bank's balance.";
    } else {
        msg.innerText = "From which bank account will this amount be deducted?";
        label.innerText = "Deduct From Account";
        help.innerText = "The amount will be DEDUCTED from this bank's balance.";
    }
    
    new bootstrap.Modal(document.getElementById('realizeModal')).show();
}

document.addEventListener("DOMContentLoaded", function() {
    toggleSupplier();
});
</script>
@endsection
 