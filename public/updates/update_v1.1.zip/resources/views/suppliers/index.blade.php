@extends('layouts.admin')

@section('title', 'Manage Suppliers')
@section('header', 'Suppliers List')

@section('content')
<div class="card shadow-sm">
    <div class="card-header d-flex justify-content-between align-items-center bg-primary">
        <h5 class="mb-0 text-white"><i class="bi bi-truck me-2"></i> All Suppliers</h5>
        <button class="btn btn-light text-primary btn-sm fw-bold" data-bs-toggle="modal" data-bs-target="#addSupplierModal">
            <i class="bi bi-plus-lg"></i> Add Supplier
        </button>
    </div>
    <div class="card-body mt-3">
        
        @if(session('success'))
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                {{ session('success') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        @endif
        @if(session('error'))
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                {{ session('error') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        @endif

        <div class="table-responsive">
            <table class="table table-hover align-middle">
                <thead>
                    <tr>
                        <th>Company Name</th>
                        <th>Contact Person</th>
                        <th>Contact Info</th>
                        <th>Branch</th>
                        <th>Credit Balance</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($suppliers as $supplier)
                    <tr>
                        <td class="fw-bold text-primary">{{ $supplier->company_name }}</td>
                        <td>{{ $supplier->contact_person ?? '-' }}</td>
                        <td>
                            <small><i class="bi bi-telephone"></i> {{ $supplier->phone ?? '-' }}</small><br>
                            <small class="text-muted"><i class="bi bi-envelope"></i> {{ $supplier->email ?? '-' }}</small>
                        </td>
                        <td>
                            @if($supplier->branch)
                                <span class="badge bg-light-secondary text-dark">{{ $supplier->branch->name }}</span>
                            @else
                                <span class="badge bg-light-info text-dark">All Branches</span>
                            @endif
                        </td>
                        <td>
                            @if($supplier->credit_balance > 0)
                                <span class="badge bg-danger">Rs. {{ number_format($supplier->credit_balance, 2) }}</span>
                            @else
                                <span class="badge bg-success">Rs. 0.00</span>
                            @endif
                        </td>
                        <td>
                            <button class="btn btn-sm btn-outline-primary" data-bs-toggle="modal" data-bs-target="#editModal{{ $supplier->id }}">
                                <i class="bi bi-pencil"></i>
                            </button>
                            <form action="{{ route('suppliers.destroy', $supplier->id) }}" method="POST" class="d-inline" onsubmit="return confirm('Are you sure?')">
                                @csrf @method('DELETE')
                                <button class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i></button>
                            </form>
                        </td>
                    </tr>

                    <div class="modal fade" id="editModal{{ $supplier->id }}" tabindex="-1">
                        <div class="modal-dialog">
                            <form action="{{ route('suppliers.update', $supplier->id) }}" method="POST" class="modal-content">
                                @csrf @method('PUT')
                                <div class="modal-header bg-primary text-white">
                                    <h5 class="modal-title text-white">Edit Supplier</h5>
                                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                                </div>
                                <div class="modal-body">
                                    <div class="mb-3">
                                        <label class="form-label">Company Name *</label>
                                        <input type="text" name="company_name" class="form-control" value="{{ $supplier->company_name }}" required>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Contact Person</label>
                                        <input type="text" name="contact_person" class="form-control" value="{{ $supplier->contact_person }}">
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6 mb-3">
                                            <label class="form-label">Phone</label>
                                            <input type="text" name="phone" class="form-control" value="{{ $supplier->phone }}">
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <label class="form-label">Email</label>
                                            <input type="email" name="email" class="form-control" value="{{ $supplier->email }}">
                                        </div>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Address</label>
                                        <textarea name="address" class="form-control" rows="2">{{ $supplier->address }}</textarea>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                    <button type="submit" class="btn btn-primary">Save Changes</button>
                                </div>
                            </form>
                        </div>
                    </div>
                    @empty
                    <tr>
                        <td colspan="6" class="text-center py-4 text-muted">No suppliers found.</td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="modal fade" id="addSupplierModal" tabindex="-1">
    <div class="modal-dialog">
        <form action="{{ route('suppliers.store') }}" method="POST" class="modal-content">
            @csrf
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title text-white">Add New Supplier</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="mb-3">
                    <label class="form-label">Assign to Branch (Optional)</label>
                    <select name="branch_id" class="form-select">
                        <option value="">-- All Branches --</option>
                        @foreach($branches as $branch)
                            <option value="{{ $branch->id }}">{{ $branch->name }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label">Company Name *</label>
                    <input type="text" name="company_name" class="form-control" required placeholder="e.g. ACL Cables PLC">
                </div>
                <div class="mb-3">
                    <label class="form-label">Contact Person</label>
                    <input type="text" name="contact_person" class="form-control" placeholder="Name of your agent">
                </div>
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Phone</label>
                        <input type="text" name="phone" class="form-control" placeholder="07x xxxxxxx">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Email</label>
                        <input type="email" name="email" class="form-control" placeholder="agent@company.com">
                    </div>
                </div>
                <div class="mb-3">
                    <label class="form-label">Address</label>
                    <textarea name="address" class="form-control" rows="2"></textarea>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Save Supplier</button>
            </div>
        </form>
    </div>
</div>
@endsection
