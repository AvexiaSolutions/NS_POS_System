@extends('layouts.admin')

@section('title', 'Inventory Management')
@section('header', 'Inventory Setup')

@section('content')
<div class="page-heading">
    <div class="row">
        <div class="col-12">
            <p class="text-subtitle text-muted">Manage product categories and company brands.</p>
        </div>
    </div>
</div>

@if(session('success'))
<div class="alert alert-success alert-dismissible fade show" role="alert">
    {{ session('success') }}
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
@endif

<div class="card">
    <div class="card-body">
        <ul class="nav nav-tabs" id="myTab" role="tablist">
            <li class="nav-item" role="presentation">
                <a class="nav-link active" id="category-tab" data-bs-toggle="tab" href="#category" role="tab">Product Categories</a>
            </li>
            <li class="nav-item" role="presentation">
                <a class="nav-link" id="brand-tab" data-bs-toggle="tab" href="#brand" role="tab">Company / Brands</a>
            </li>
        </ul>
        
        <div class="tab-content pt-4" id="myTabContent">
            
            <div class="tab-pane fade show active" id="category" role="tabpanel">
                <div class="d-flex justify-content-end mb-3">
                    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addCategoryModal">
                        <i class="bi bi-plus-lg"></i> Add New Category
                    </button>
                </div>
                
                <div class="table-responsive">
                    <table class="table table-hover" id="table1">
                        <thead>
                            <tr>
                                <th>Shop</th>
                                <th>Category Name</th>
                                <th>Code</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse($categories as $category)
                            <tr>
                                <td><span class="badge bg-light-primary text-dark">{{ $category->branch->name ?? 'N/A' }}</span></td>
                                <td class="fw-bold">{{ $category->name }}</td>
                                <td>{{ $category->code ?? '-' }}</td>
                                <td>
                                    <button class="btn btn-sm btn-info me-2" data-bs-toggle="modal" data-bs-target="#editCategoryModal{{ $category->id }}">
                                        <i class="bi bi-pencil-square"></i>
                                    </button>
                                    
                                    <form action="{{ route('categories.destroy', $category->id) }}" method="POST" class="d-inline" onsubmit="return confirm('Are you sure?')">
                                        @csrf @method('DELETE')
                                        <button type="submit" class="btn btn-sm btn-danger"><i class="bi bi-trash"></i></button>
                                    </form>
                                </td>
                            </tr>

                            <div class="modal fade" id="editCategoryModal{{ $category->id }}" tabindex="-1" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header bg-info">
                                            <h5 class="modal-title text-white">Edit Category</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                        </div>
                                        <form action="{{ route('categories.update', $category->id) }}" method="POST">
                                            @csrf @method('PUT')
                                            <div class="modal-body">
                                                @if(auth()->user()->role == 'admin')
                                                <div class="mb-3">
                                                    <label class="form-label">Select Shop</label>
                                                    <select name="branch_id" class="form-select" required>
                                                        @foreach($branches as $branch)
                                                            <option value="{{ $branch->id }}" {{ $category->branch_id == $branch->id ? 'selected' : '' }}>
                                                                {{ $branch->name }}
                                                            </option>
                                                        @endforeach
                                                    </select>
                                                </div>
                                                @endif
                                                <div class="mb-3">
                                                    <label class="form-label">Category Name</label>
                                                    <input type="text" name="name" class="form-control" value="{{ $category->name }}" required>
                                                </div>
                                                <div class="mb-3">
                                                    <label class="form-label">Code</label>
                                                    <input type="text" name="code" class="form-control" value="{{ $category->code }}">
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-light-secondary" data-bs-dismiss="modal">Close</button>
                                                <button type="submit" class="btn btn-info ms-1">Update</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            @empty
                            <tr><td colspan="4" class="text-center text-muted py-5">No categories found.</td></tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="tab-pane fade" id="brand" role="tabpanel">
                <div class="d-flex justify-content-end mb-3">
                    <button class="btn btn-info text-white" data-bs-toggle="modal" data-bs-target="#addBrandModal">
                        <i class="bi bi-plus-lg"></i> Add New Brand
                    </button>
                </div>

                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Shop</th>
                                <th>Company / Brand Name</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse($brands as $brand)
                            <tr>
                                <td><span class="badge bg-light-info text-dark">{{ $brand->branch->name ?? '-' }}</span></td>
                                <td class="fw-bold">{{ $brand->name }}</td>
                                <td>
                                    <form action="{{ route('brands.destroy', $brand->id) }}" method="POST" onsubmit="return confirm('Are you sure?')">
                                        @csrf @method('DELETE')
                                        <button class="btn btn-sm btn-danger"><i class="bi bi-trash"></i></button>
                                    </form>
                                </td>
                            </tr>
                            @empty
                            <tr><td colspan="3" class="text-center text-muted py-5">No brands found.</td></tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
            </div>

        </div>
    </div>
</div>

<div class="modal fade" id="addCategoryModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-primary">
                <h5 class="modal-title text-white">Add Category</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form action="{{ route('categories.store') }}" method="POST">
                @csrf
                <div class="modal-body">
                    @if(auth()->user()->role == 'admin')
                    <div class="mb-3">
                        <label>Select Shop</label>
                        <select name="branch_id" class="form-select" required>
                            <option value="" disabled selected>Choose a Shop...</option>
                            @foreach($branches as $b) <option value="{{ $b->id }}">{{ $b->name }}</option> @endforeach
                        </select>
                    </div>
                    @endif
                    <div class="mb-3">
                        <label>Category Name</label>
                        <input type="text" name="name" class="form-control" placeholder="e.g. Electronic" required>
                    </div>
                    <div class="mb-3">
                        <label>Code</label>
                        <input type="text" name="code" class="form-control" placeholder="e.g. ELEC">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary">Save</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="addBrandModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-info">
                <h5 class="modal-title text-white">Add Company / Brand</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form action="{{ route('brands.store') }}" method="POST">
                @csrf
                <div class="modal-body">
                    @if(auth()->user()->role == 'admin')
                    <div class="mb-3">
                        <label>Select Shop</label>
                        <select name="branch_id" class="form-select" required>
                            <option value="" disabled selected>Choose a Shop...</option>
                            @foreach($branches as $b) <option value="{{ $b->id }}">{{ $b->name }}</option> @endforeach
                        </select>
                    </div>
                    @endif
                    <div class="mb-3">
                        <label>Company / Brand Name</label>
                        <input type="text" name="name" class="form-control" placeholder="e.g. Sony, Hayleys" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-info text-white">Save Brand</button>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection
