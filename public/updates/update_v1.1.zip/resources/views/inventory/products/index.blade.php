@extends('layouts.admin')

@section('title', 'Products')
@section('header', 'Product Inventory')

@section('content')

<style>
    [data-bs-theme="dark"] .modal-content { background-color: #1e1e2d; color: #ffffff; }
    
    [data-bs-theme="dark"] .form-control, 
    [data-bs-theme="dark"] .form-select { background-color: #2b2b40 !important; color: #ffffff !important; border: 1px solid #3b3b5c; }

    [data-bs-theme="dark"] .form-control:focus, 
    [data-bs-theme="dark"] .form-select:focus { border-color: #5c77ff; box-shadow: none; }

    [data-bs-theme="dark"] .form-control[readonly] { background-color: #151521 !important; color: #888 !important; cursor: not-allowed; }
    [data-bs-theme="dark"] ::placeholder { color: #6c757d !important; }

    #sidebar {
        z-index: 1050 !important; 
    }
    @media (max-width: 991px) {
        .sidebar-wrapper { z-index: 1060 !important; }
    }

    .table-scrollable {
        max-height: 65vh; 
        overflow-y: auto;
    }
    
    .table-scrollable thead th {
        position: sticky;
        top: 0;
        z-index: 5; 
        background-color: #f8f9fa; 
        box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.1);
    }
    
    [data-bs-theme="dark"] .table-scrollable thead th {
        background-color: #1e1e2d; 
        border-bottom: 1px solid #3b3b5c;
        box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);
    }

    .search-results {
        position: absolute;
        background: var(--bs-body-bg);
        border: 1px solid #5c77ff;
        max-height: 200px;
        overflow-y: auto;
        width: 95%; 
        z-index: 9999; 
        list-style: none;
        padding: 0;
        margin-top: 5px;
        box-shadow: 0 4px 15px rgba(0,0,0,0.2);
        display: none;
    }
    [data-bs-theme="dark"] .search-results { background: #2b2b40; }

    .search-results li { padding: 10px; cursor: pointer; border-bottom: 1px solid #ddd; }
    [data-bs-theme="dark"] .search-results li { border-bottom: 1px solid #3b3b5c; color: #fff; }

    .search-results li:hover { background-color: #5c77ff; color: white; }
    
    .variant-card { background-color: transparent; border: 1px dashed #5c77ff; }

    .search-container {
        position: relative;
        max-width: 400px;
    }
    .search-icon {
        position: absolute;
        left: 10px;
        top: 50%;
        transform: translateY(-50%);
        color: #6c757d;
        z-index: 5;
    }
    .search-input {
        padding-left: 35px;
        border-radius: 20px;
    }
</style>

<div class="page-heading">
    <div class="row align-items-center mb-3">
        <div class="col-12 col-md-4 order-md-1 order-last mt-3 mt-md-0">
            <p class="text-subtitle text-muted mb-0">Manage products, variants, warranty & barcodes.</p>
        </div>
        <div class="col-12 col-md-4 order-md-2 order-2 mt-3 mt-md-0">
            <div class="position-relative mx-auto" style="max-width: 400px;">
                <form action="{{ route('products.index') }}" method="GET" id="searchForm" onsubmit="return false;">
                    <i class="bi bi-search position-absolute" style="left: 16px; top: 50%; transform: translateY(-50%); color: #8a8d93; z-index: 5;"></i>
                    
                    <input type="text" 
                           name="search" 
                           class="form-control" 
                           placeholder="Search Name, Barcode, Brand..." 
                           value="{{ request('search') }}"
                           id="mainSearchInput"
                           autocomplete="off"
                           style="padding-left: 45px; border-radius: 50px; height: 42px; padding-right: {{ request('search') ? '70px' : '15px' }};">
                    
                    @if(request('search'))
                        <a href="{{ route('products.index') }}" class="btn btn-sm btn-secondary position-absolute" style="right: 5px; top: 50%; transform: translateY(-50%); border-radius: 50px; font-size: 0.75rem; padding: 4px 10px;">
                            Clear
                        </a>
                    @endif
                </form>
            </div>
        </div>
        <div class="col-12 col-md-4 order-md-3 order-first">
            <div class="float-start float-md-end">
                <button type="button" class="btn btn-primary" onclick="openAddModal()">
                    <i class="bi bi-plus-lg"></i> Add New Product
                </button>
            </div>
        </div>
    </div>
</div>

@if(session('success'))
<div class="alert alert-success alert-dismissible fade show" role="alert">
    {{ session('success') }}
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
@endif

@if($errors->any())
<div class="alert alert-danger alert-dismissible fade show" role="alert">
    <ul class="mb-0">
        @foreach($errors->all() as $error)
            <li>{{ $error }}</li>
        @endforeach
    </ul>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
@endif

<div class="card shadow-sm">
    <div class="card-body p-0">
        <div class="table-responsive table-scrollable px-3 pb-3">
            <table class="table table-hover align-middle mb-0" id="table1">
                <thead>
                    <tr>
                        <th>Product</th>
                        <th>Details</th>
                        <th>Price Info</th>
                        <th>Stock</th>
                        @if(auth()->user()->role == 'admin')
                        <th class="text-end">Actions</th>
                        @endif
                    </tr>
                </thead>
                <tbody id="productTableBody">
                    @forelse($products as $product)
                    <tr>
                        <td>
                            <div class="fw-bold text-primary">{{ $product->product_name }}</div>
                            <small class="text-muted"><i class="bi bi-upc-scan"></i> {{ $product->barcode }}</small>
                            <br>
                            <span class="badge bg-light-secondary text-dark border">{{ strtoupper($product->unit) }}</span>
                        </td>
                        <td>
                            <small><i class="bi bi-shop"></i> {{ $product->branch->name ?? 'All' }}</small><br>
                            <small><i class="bi bi-tags"></i> {{ $product->category->name ?? '-' }}</small><br>
                            @if($product->has_warranty)
                                <span class="badge bg-info text-dark" style="font-size: 0.7rem"><i class="bi bi-shield-check"></i> {{ $product->warranty_months }}M</span>
                            @endif
                        </td>
                        <td>
                            <div class="text-muted" style="font-size: 0.85rem">Cost: {{ number_format($product->cost_price, 2) }}</div>
                            <div class="fw-bold text-success text-body">Sell: {{ number_format($product->selling_price, 2) }}</div>
                        </td>
                        <td>
                            @if($product->qty <= $product->alert_qty)
                                <span class="badge bg-danger" id="product-stock-{{ $product->id }}">{{ $product->qty }}</span>
                            @else
                                <span class="badge bg-success" id="product-stock-{{ $product->id }}">{{ $product->qty }}</span>
                            @endif
                        </td>
                        @if(auth()->user()->role == 'admin')
                        <td class="text-end">
                            <button class="btn btn-sm btn-outline-info" onclick='openEditModal(@json($product->load("rolls")))'>
                                <i class="bi bi-pencil-square"></i>
                            </button>
                            
                            <button class="btn btn-sm btn-outline-secondary" onclick="openBarcodeModal({{ json_encode($product) }})">
                                <i class="bi bi-printer"></i>
                            </button>

                            <form action="{{ route('products.destroy', $product->id) }}" method="POST" class="d-inline" onsubmit="return confirm('Delete this product?')">
                                @csrf @method('DELETE')
                                <button class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i></button>
                            </form>
                        </td>
                        @endif
                    </tr>
                    @empty
                    <tr><td colspan="{{ auth()->user()->role == 'admin' ? '5' : '4' }}" class="text-center py-5 text-muted">No products found.</td></tr>
                    @endforelse
                </tbody>
            </table>
            </div>
    </div>
</div>

<div class="modal fade" id="addProductModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header bg-primary">
                <h5 class="modal-title text-white"><i class="bi bi-box-seam"></i> Add New Product</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form action="{{ route('products.store') }}" method="POST" id="addForm" data-locked="false">
                @csrf
                <div class="modal-body p-4">
                    <div class="row">
                        @if(auth()->user()->role == 'admin')
                        <div class="col-md-4 mb-3">
                            <label class="form-label fw-bold">Shop / Branch <span class="text-danger">*</span></label>
                            <select name="branch_id" id="branch_id" class="form-select" onchange="filterCategoriesAndBrands(this.value); generateBarcode(this.value);" required>
                                <option value="" disabled selected>Select Shop</option>
                                @foreach($branches as $branch) 
                                    <option value="{{ $branch->id }}">{{ $branch->name }}</option> 
                                @endforeach
                            </select>
                        </div>
                        @endif

                        <div class="col-md-4 mb-3">
                            <label class="form-label fw-bold">Category</label>
                            <select name="category_id" class="form-select" id="add_category">
                                <option value="">No Category</option>
                                @foreach($categories as $cat) 
                                    <option value="{{ $cat->id }}" data-branch="{{ $cat->branch_id }}">{{ $cat->name }}</option> 
                                @endforeach
                            </select>
                        </div>

                        <div class="col-md-4 mb-3">
                            <label class="form-label fw-bold">Brand</label>
                            <select name="brand_id" class="form-select" id="add_brand">
                                <option value="">No Brand</option>
                                @foreach($brands as $brand) 
                                    <option value="{{ $brand->id }}" data-branch="{{ $brand->branch_id }}">{{ $brand->name }}</option> 
                                @endforeach
                            </select>
                        </div>

                        <div class="col-md-6 mb-3 position-relative">
                            <label class="form-label fw-bold">Product Name <span class="text-danger">*</span></label>
                            <input type="text" name="product_name" id="add_product_name" class="form-control" autocomplete="off" required>
                            <ul class="search-results" id="name_search_results"></ul>
                        </div>

                        <div class="col-md-6 mb-3 position-relative">
                            <label class="form-label fw-bold">Barcode</label>
                            <input type="text" name="barcode" id="add_barcode" class="form-control" autocomplete="off">
                            <small class="text-muted" id="barcode_help">Scan or type barcode. Auto-generated if left empty.</small>
                             <ul class="search-results" id="barcode_search_results"></ul>
                        </div>

                        <div class="col-md-3 mb-3">
                            <label class="form-label fw-bold">Cost Price <span class="text-danger">*</span></label>
                            <input type="number" step="0.01" name="cost_price" id="add_cost_price" class="form-control" required>
                        </div>

                        <div class="col-md-3 mb-3">
                            <label class="form-label fw-bold text-success">Selling Price <span class="text-danger">*</span></label>
                            <input type="number" step="0.01" name="selling_price" id="add_selling_price" class="form-control" required>
                        </div>
                        
                        <div class="col-md-3 mb-3">
                            <label class="form-label fw-bold">Discount Val</label>
                            <input type="number" step="0.01" name="discount_price" id="add_discount_price" class="form-control" value="0">
                        </div>
                        
                        <div class="col-md-3 mb-3">
                            <label class="form-label fw-bold">Discount Type</label>
                            <select name="discount_type" class="form-select">
                                <option value="amount">Fixed Amount (Rs)</option>
                                <option value="percentage">Percentage (%)</option>
                            </select>
                        </div>

                        <div class="col-md-4 mb-3">
                            <label class="form-label fw-bold">Quantity (Stock)</label>
                            <input type="number" step="0.01" name="qty" id="add_qty" class="form-control" value="0">
                        </div>

                        <div class="col-md-4 mb-3">
                            <label class="form-label fw-bold">Unit</label>
                            <select name="unit" id="unitSelect" class="form-select" onchange="updateVariantLabels('add')">
                                <option value="pcs">Pieces (Pcs)</option>
                                <option value="kg">Kilogram (Kg)</option>
                                <option value="gram">Gram (g)</option>
                                <option value="l">Liter (L)</option>
                                <option value="ml">Milliliter (ml)</option>
                                <option value="meter">Meter (Wire)</option>
                                <option value="feet">Feet</option>
                            </select>
                        </div>

                        <div class="col-md-4 mb-3">
                            <label class="form-label fw-bold">Alert Qty</label>
                            <input type="number" name="alert_qty" class="form-control" value="5">
                        </div>

                        <div class="col-12 mb-3">
                            <div class="form-check form-switch mt-2">
                                <input class="form-check-input" type="checkbox" name="has_warranty" id="warrantyCheck" value="1" onchange="toggleWarranty('add')">
                                <label class="form-check-label fw-bold" for="warrantyCheck">Product Has Warranty?</label>
                            </div>
                            <div class="mt-2" id="warrantyInput" style="display: none;">
                                <label class="fw-bold text-info">Warranty Months</label>
                                <input type="number" name="warranty_months" class="form-control border-info" placeholder="e.g. 12" style="max-width: 200px;">
                            </div>
                        </div>

                        <div class="col-12 mt-3">
                            <div class="card variant-card"> 
                                <div class="card-body">
                                    <h6 class="card-title text-primary fw-bold" id="variantTitle">Product Variants / Packs / Rolls</h6>
                                    <p class="text-secondary small mb-2" id="variantHelp">Add different sizes like 500ml bottle, 100g pack, 50m roll, etc.</p>
                                    
                                    <table class="table table-bordered mb-0" id="rollsTable">
                                        <thead>
                                            <tr>
                                                <th id="sizeLabel">Size / Length (e.g. 500ml)</th>
                                                <th>Price (Rs)</th>
                                                <th width="50px"><button type="button" class="btn btn-sm btn-success" onclick="addRollRow('rollsTable')"><i class="bi bi-plus"></i></button></th>
                                            </tr>
                                        </thead>
                                        <tbody></tbody>
                                    </table>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary fw-bold ms-1"><i class="bi bi-save"></i> Save Product</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="editProductModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header bg-info">
                <h5 class="modal-title text-dark fw-bold"><i class="bi bi-pencil-square"></i> Edit Product Details</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form id="editForm" method="POST">
                @csrf
                @method('PUT')
                <div class="modal-body p-4">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Product Name</label>
                            <input type="text" name="product_name" id="edit_product_name" class="form-control" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Barcode</label>
                            <input type="text" name="barcode" id="edit_barcode" class="form-control">
                        </div>

                        <div class="col-md-4 mb-3">
                            <label class="form-label fw-bold">Cost Price</label>
                            <input type="number" step="0.01" name="cost_price" id="edit_cost_price" class="form-control" required>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label fw-bold text-success">Selling Price</label>
                            <input type="number" step="0.01" name="selling_price" id="edit_selling_price" class="form-control" required>
                        </div>
                        
                        <div class="col-md-4 mb-3">
                            <label class="form-label fw-bold text-danger">Stock Quantity</label>
                            <input type="number" step="0.01" name="qty" id="edit_qty" class="form-control border-danger">
                        </div>

                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Discount Val</label>
                            <input type="number" step="0.01" name="discount_price" id="edit_discount_price" class="form-control" value="0">
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Discount Type</label>
                            <select name="discount_type" id="edit_discount_type" class="form-select">
                                <option value="amount">Fixed Amount (Rs)</option>
                                <option value="percentage">Percentage (%)</option>
                            </select>
                        </div>
                        <div class="col-12 mb-3">
                            <div class="form-check form-switch mt-2">
                                <input class="form-check-input" type="checkbox" name="has_warranty" id="edit_warrantyCheck" value="1" onchange="toggleWarranty('edit')">
                                <label class="form-check-label fw-bold">Has Warranty?</label>
                            </div>
                            <div class="mt-2" id="edit_warrantyInput" style="display: none;">
                                <label class="fw-bold text-info">Warranty Months</label>
                                <input type="number" name="warranty_months" id="edit_warranty_months" class="form-control border-info" style="max-width: 200px;">
                            </div>
                        </div>

                        <div class="col-md-4 mb-3">
                            <label class="form-label fw-bold">Unit</label>
                            <select name="unit" id="edit_unitSelect" class="form-select" onchange="updateVariantLabels('edit')">
                                <option value="pcs">Pieces (Pcs)</option>
                                <option value="kg">Kilogram (Kg)</option>
                                <option value="gram">Gram (g)</option>
                                <option value="l">Liter (L)</option>
                                <option value="ml">Milliliter (ml)</option>
                                <option value="meter">Meter (Wire)</option>
                                <option value="feet">Feet</option>
                            </select>
                        </div>

                        <div class="col-12 mt-3" id="editRollSection" style="display: none;">
                            <div class="card variant-card"> 
                                <div class="card-body">
                                    <h6 class="card-title text-primary fw-bold" id="editVariantTitle">Product Variants / Packs / Rolls</h6>
                                    
                                    <table class="table table-bordered mb-0" id="editRollsTable">
                                        <thead>
                                            <tr>
                                                <th id="editSizeLabel">Size / Length (e.g. 500ml)</th>
                                                <th>Price (Rs)</th>
                                                <th width="50px"><button type="button" class="btn btn-sm btn-success" onclick="addRollRow('editRollsTable')"><i class="bi bi-plus"></i></button></th>
                                            </tr>
                                        </thead>
                                        <tbody></tbody>
                                    </table>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-info fw-bold text-dark ms-1">Update Product</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="barcodeModal" tabindex="-1">
    <div class="modal-dialog modal-sm">
        <div class="modal-content">
            <div class="modal-header bg-secondary text-white">
                <h5 class="modal-title"><i class="bi bi-printer"></i> Print Barcodes</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form action="{{ route('products.print_barcode') }}" method="POST" target="_blank">
                @csrf
                <div class="modal-body p-4 text-center">
                    <input type="hidden" name="product_id" id="barcode_product_id">
                    <p id="barcode_product_name" class="fw-bold text-primary mb-3"></p>
                    
                    <label class="fw-bold mb-2">How many labels?</label>
                    <input type="number" name="print_qty" id="barcode_qty" class="form-control text-center fs-5" min="1" required>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-dark w-100 fw-bold">Print Now</button>
                </div>
            </form>
        </div>
    </div>
</div>

@endsection

@section('scripts')
<script>
    const branchBarcodes = @json($branchNextBarcodes ?? []);
    const userRole = "{{ auth()->user()->role }}";
    const userBranchId = "{{ auth()->user()->branch_id }}";
    const isAdmin = "{{ auth()->user()->role }}" === 'admin';
    const rollUnits = ['meter', 'feet', 'l', 'ml', 'kg', 'gram', 'bottle'];

    function updateProductsLive() {
        let query = document.getElementById('mainSearchInput').value;
        if(query.trim() !== '') return; 

        fetch("{{ route('products.index') }}", {
            headers: {
                'X-Requested-With': 'XMLHttpRequest',
                'Accept': 'application/json'
            }
        })
        .then(response => response.json())
        .then(data => {
            if(!data.products) return;

            data.products.forEach(p => {
                let badge = document.getElementById('product-stock-' + p.id);
                if(badge) {
                    if(badge.innerText != p.qty) {
                        badge.innerText = p.qty;
                        if(p.qty <= p.alert_qty) {
                            badge.className = 'badge bg-danger';
                        } else {
                            badge.className = 'badge bg-success';
                        }
                    }
                }
            });
        })
        .catch(error => console.error('Product Live Update Error:', error));
    }

    setInterval(updateProductsLive, 10000);

    document.addEventListener("DOMContentLoaded", function() {
        
        const mainSearchInput = document.getElementById('mainSearchInput');
        const productTableBody = document.getElementById('productTableBody');

        if (mainSearchInput) {
            mainSearchInput.addEventListener('input', function() {
                let query = this.value;
                
                fetch(`{{ route('products.index') }}?search=${encodeURIComponent(query)}`, {
                    headers: {
                        'X-Requested-With': 'XMLHttpRequest',
                        'Accept': 'application/json'
                    }
                })
                .then(response => response.json())
                .then(data => {
                    productTableBody.innerHTML = ''; 

                    if (data.products.length === 0) {
                        productTableBody.innerHTML = '<tr><td colspan="' + (isAdmin ? '5' : '4') + '" class="text-center py-5 text-muted">No products found.</td></tr>';
                        return;
                    }

                    data.products.forEach(product => {
                        let costPrice = parseFloat(product.cost_price).toLocaleString('en-US', {minimumFractionDigits: 2});
                        let sellingPrice = parseFloat(product.selling_price).toLocaleString('en-US', {minimumFractionDigits: 2});
                        let unit = product.unit ? product.unit.toUpperCase() : '';
                        let branchName = product.branch ? product.branch.name : 'All';
                        let categoryName = product.category ? product.category.name : '-';
                        
                        let warrantyBadge = product.has_warranty 
                            ? `<span class="badge bg-info text-dark" style="font-size: 0.7rem"><i class="bi bi-shield-check"></i> ${product.warranty_months}M</span>` 
                            : '';
                        
                        let qtyClass = product.qty <= product.alert_qty ? 'bg-danger' : 'bg-success';
                        let qtyBadge = `<span class="badge ${qtyClass}" id="product-stock-${product.id}">${product.qty}</span>`;

                        let productJson = JSON.stringify(product).replace(/'/g, "&apos;").replace(/"/g, '&quot;');

                        let actionButtons = isAdmin ? `
                            <td class="text-end">
                                <button class="btn btn-sm btn-outline-info" onclick="openEditModal(${productJson})">
                                    <i class="bi bi-pencil-square"></i>
                                </button>
                                
                                <button class="btn btn-sm btn-outline-secondary" onclick="openBarcodeModal(${productJson})">
                                    <i class="bi bi-printer"></i>
                                </button>

                                <form action="/products/${product.id}" method="POST" class="d-inline" onsubmit="return confirm('Delete this product?')">
                                    <input type="hidden" name="_token" value="{{ csrf_token() }}">
                                    <input type="hidden" name="_method" value="DELETE">
                                    <button class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i></button>
                                </form>
                            </td>` : '';

                        let tr = document.createElement('tr');
                        tr.innerHTML = `
                            <td>
                                <div class="fw-bold text-primary">${product.product_name}</div>
                                <small class="text-muted"><i class="bi bi-upc-scan"></i> ${product.barcode || ''}</small>
                                <br>
                                <span class="badge bg-light-secondary text-dark border">${unit}</span>
                            </td>
                            <td>
                                <small><i class="bi bi-shop"></i> ${branchName}</small><br>
                                <small><i class="bi bi-tags"></i> ${categoryName}</small><br>
                                ${warrantyBadge}
                            </td>
                            <td>
                                <div class="text-muted" style="font-size: 0.85rem">Cost: ${costPrice}</div>
                                <div class="fw-bold text-success text-body">Sell: ${sellingPrice}</div>
                            </td>
                            <td>
                                ${qtyBadge}
                            </td>
                            ${actionButtons}
                        `;
                        productTableBody.appendChild(tr);
                    });
                })
                .catch(error => console.error('Error fetching data:', error));
            });
        }

        const nameInput = document.getElementById('add_product_name');
        const barcodeInput = document.getElementById('add_barcode');
        const nameResults = document.getElementById('name_search_results');
        const barcodeResults = document.getElementById('barcode_search_results');

        function setupSearch(input, resultBox) {
            if (!input) return;

            input.addEventListener('input', function() {
                let query = this.value;
                
                if(query.length < 2) {
                    resultBox.style.display = 'none';
                    return;
                }

                fetch("{{ route('products.search_ajax') }}?query=" + encodeURIComponent(query))
                    .then(response => response.json())
                    .then(data => {
                        resultBox.innerHTML = '';
                        if(data.length > 0) {
                            resultBox.style.display = 'block';
                            data.forEach(item => {
                                let li = document.createElement('li');
                                li.innerHTML = `<strong>${item.product_name}</strong> <small>(${item.barcode || ''})</small>`;
                                li.onclick = function() {
                                    fillAndLock(item);
                                    resultBox.style.display = 'none';
                                };
                                resultBox.appendChild(li);
                            });
                        } else {
                            resultBox.style.display = 'none';
                        }
                    })
                    .catch(error => console.error('Error fetching data:', error));
            });
        }

        setupSearch(nameInput, nameResults);
        setupSearch(barcodeInput, barcodeResults);

        document.addEventListener('click', function(e) {
            if (e.target !== nameInput && nameResults) nameResults.style.display = 'none';
            if (e.target !== barcodeInput && barcodeResults) barcodeResults.style.display = 'none';
        });

        [nameInput, barcodeInput].forEach(input => {
            input.addEventListener('input', function() {
                if (document.getElementById('addForm').getAttribute('data-locked') === 'true') {
                    unlockForm(); 
                }
            });
        });

        if (userRole !== 'admin') {
            filterCategoriesAndBrands(userBranchId);
            generateBarcode(userBranchId); 
        } else {
            filterCategoriesAndBrands('');
        }
    });

    function generateBarcode(branchId) {
        let barcodeInput = document.getElementById('add_barcode');
        let helpText = document.getElementById('barcode_help');
        
        if (document.getElementById('addForm').getAttribute('data-locked') !== 'true') {
            if (branchId && branchBarcodes[branchId]) {
                barcodeInput.value = branchBarcodes[branchId];
                helpText.innerHTML = '<span class="text-success"><i class="bi bi-check-circle"></i> Auto-Generated for Branch</span>';
            } else {
                barcodeInput.value = '';
                helpText.innerText = 'Scan or type barcode. Auto-generated if left empty.';
            }
        }
    }

    function filterCategoriesAndBrands(branchId) {
        let cats = document.querySelectorAll('#add_category option[data-branch]');
        cats.forEach(opt => {
            if(opt.dataset.branch == branchId || !branchId && branchId !== '') {
                opt.hidden = false; opt.disabled = false;
            } else {
                opt.hidden = true; opt.disabled = true;
            }
        });
        document.getElementById('add_category').value = '';

        let brands = document.querySelectorAll('#add_brand option[data-branch]');
        brands.forEach(opt => {
            if(opt.dataset.branch == branchId || !branchId && branchId !== '') {
                opt.hidden = false; opt.disabled = false;
            } else {
                opt.hidden = true; opt.disabled = true;
            }
        });
        document.getElementById('add_brand').value = '';
    }

    function fillAndLock(product) {
        document.getElementById('add_product_name').value = product.product_name;
        document.getElementById('add_barcode').value = product.barcode || '';
        document.getElementById('add_cost_price').value = product.cost_price;
        document.getElementById('add_selling_price').value = product.selling_price;
        document.getElementById('add_discount_price').value = product.discount_price || 0;
        
        if(product.category_id) document.getElementById('add_category').value = product.category_id;
        if(product.brand_id) document.getElementById('add_brand').value = product.brand_id;
        if(product.unit) {
            document.getElementById('unitSelect').value = product.unit;
            updateVariantLabels('add');
        }

        document.getElementById('add_cost_price').readOnly = true;
        document.getElementById('add_selling_price').readOnly = true;
        document.getElementById('add_discount_price').readOnly = true;
        
        ['add_category', 'add_brand', 'unitSelect'].forEach(id => {
            let el = document.getElementById(id);
            if(el) { el.style.pointerEvents = 'none'; el.style.opacity = '0.6'; }
        });

        document.getElementById('addForm').setAttribute('data-locked', 'true');
        
        document.getElementById('barcode_help').innerHTML = '<span class="text-warning"><i class="bi bi-info-circle"></i> Existing Product Selected. Add stock qty. (Edit name/barcode to add as new)</span>';
        
        document.getElementById('add_qty').value = '';
        document.getElementById('add_qty').focus();
    }

    function unlockForm() {
        document.getElementById('add_cost_price').readOnly = false;
        document.getElementById('add_selling_price').readOnly = false;
        document.getElementById('add_discount_price').readOnly = false;
        
        ['add_category', 'add_brand', 'unitSelect'].forEach(id => {
            let el = document.getElementById(id);
            if(el) { el.style.pointerEvents = 'auto'; el.style.opacity = '1'; }
        });

        if (document.getElementById('addForm').getAttribute('data-locked') === 'true') {
            document.getElementById('add_cost_price').value = '';
            document.getElementById('add_selling_price').value = '';
            document.getElementById('add_discount_price').value = '0';
            document.getElementById('add_qty').value = '0';
            
            document.getElementById('barcode_help').innerText = 'Scan or type barcode. Auto-generated if left empty.';
            document.getElementById('addForm').setAttribute('data-locked', 'false');
        }
    }

    function openAddModal() {
        document.getElementById('addForm').reset();
        document.getElementById('rollsTable').getElementsByTagName('tbody')[0].innerHTML = '';
        document.getElementById('addForm').setAttribute('data-locked', 'true'); 
        unlockForm(); 
        
        let currentBranch = document.getElementById('branch_id') ? document.getElementById('branch_id').value : userBranchId;
        generateBarcode(currentBranch);

        if(document.getElementById('name_search_results')) 
            document.getElementById('name_search_results').style.display = 'none';

        var myModal = new bootstrap.Modal(document.getElementById('addProductModal'));
        myModal.show();
    }

    function openEditModal(product) {
        document.getElementById('editForm').action = "/products/" + product.id;
        document.getElementById('edit_product_name').value = product.product_name;
        document.getElementById('edit_barcode').value = product.barcode;
        document.getElementById('edit_cost_price').value = product.cost_price;
        document.getElementById('edit_selling_price').value = product.selling_price;
        document.getElementById('edit_qty').value = product.qty;

        document.getElementById('edit_discount_price').value = product.discount_price || 0;
        document.getElementById('edit_discount_type').value = product.discount_type || 'amount';

        if(product.unit) {
            document.getElementById('edit_unitSelect').value = product.unit;
        }

        var wCheck = document.getElementById('edit_warrantyCheck');
        var wInput = document.getElementById('edit_warrantyInput');
        var wMonths = document.getElementById('edit_warranty_months');

        if(product.has_warranty == 1) {
            wCheck.checked = true; wInput.style.display = 'block'; wMonths.value = product.warranty_months;
        } else {
            wCheck.checked = false; wInput.style.display = 'none'; wMonths.value = '';
        }

        let editRollSection = document.getElementById('editRollSection');
        let editRollsTbody = document.getElementById('editRollsTable').getElementsByTagName('tbody')[0];
        editRollsTbody.innerHTML = '';

        if (rollUnits.includes(product.unit)) {
            editRollSection.style.display = 'block';
            if (product.rolls && product.rolls.length > 0) {
                product.rolls.forEach(roll => {
                    let row = editRollsTbody.insertRow();
                    row.innerHTML = `
                        <td><input type="text" name="roll_length[]" class="form-control" value="${roll.roll_length}" required></td>
                        <td><input type="number" step="0.01" name="roll_price[]" class="form-control" value="${roll.roll_price}" required></td>
                        <td class="text-center"><button type="button" class="btn btn-sm btn-danger" onclick="removeRollRow(this)"><i class="bi bi-x-lg"></i></button></td>
                    `;
                });
            }
            updateVariantLabels('edit', product.unit);
        } else {
            editRollSection.style.display = 'none';
        }

        var myModal = new bootstrap.Modal(document.getElementById('editProductModal'));
        myModal.show();
    }

    function openBarcodeModal(product) {
        document.getElementById('barcode_product_id').value = product.id;
        document.getElementById('barcode_product_name').innerText = product.product_name;
        document.getElementById('barcode_qty').value = product.qty;
        
        var myModal = new bootstrap.Modal(document.getElementById('barcodeModal'));
        myModal.show();
    }

    function toggleWarranty(mode) {
        var checkBox = document.getElementById(mode === 'add' ? "warrantyCheck" : "edit_warrantyCheck");
        var inputDiv = document.getElementById(mode === 'add' ? "warrantyInput" : "edit_warrantyInput");
        inputDiv.style.display = checkBox.checked ? "block" : "none";
    }

    function updateVariantLabels(mode, customUnit = null) {
        var unitId = mode === 'add' ? "unitSelect" : "edit_unitSelect";
        var unit = customUnit || document.getElementById(unitId).value;
        var titleId = mode === 'add' ? "variantTitle" : "editVariantTitle";
        var labelId = mode === 'add' ? "sizeLabel" : "editSizeLabel";
        var helpId = "variantHelp";
        
        var title = document.getElementById(titleId);
        var help = document.getElementById(helpId);
        var label = document.getElementById(labelId);
        
        if (mode === 'edit') {
             let editRollSection = document.getElementById('editRollSection');
             if (rollUnits.includes(unit)) {
                 editRollSection.style.display = 'block';
             } else {
                 editRollSection.style.display = 'none';
             }
        }

        if(unit === 'meter' || unit === 'feet') {
            title.innerText = "Wire/Cable Rolls"; 
            if(help && mode === 'add') help.innerText = "Add prices for rolls."; 
            label.innerText = "Roll Length (e.g. 50m)";
        } else if (unit === 'l' || unit === 'ml' || unit === 'bottle') {
            title.innerText = "Bottle Sizes"; 
            if(help && mode === 'add') help.innerText = "Add bottle sizes."; 
            label.innerText = "Bottle Size (e.g. 500ml)";
        } else if (unit === 'kg' || unit === 'gram') {
            title.innerText = "Pack Sizes"; 
            if(help && mode === 'add') help.innerText = "Add pack sizes."; 
            label.innerText = "Pack Weight (e.g. 250g)";
        } else {
            title.innerText = "Variants"; 
            if(help && mode === 'add') help.innerText = "Add variations."; 
            label.innerText = "Variant Name";
        }
    }

    function addRollRow(tableId) {
        var table = document.getElementById(tableId).getElementsByTagName('tbody')[0];
        var row = table.insertRow();
        row.innerHTML = `
            <td><input type="text" name="roll_length[]" class="form-control" placeholder="Size/Length" required></td>
            <td><input type="number" step="0.01" name="roll_price[]" class="form-control" placeholder="Price" required></td>
            <td class="text-center"><button type="button" class="btn btn-sm btn-danger" onclick="removeRollRow(this)"><i class="bi bi-x-lg"></i></button></td>
        `;
    }
    function removeRollRow(btn) { btn.parentNode.parentNode.remove(); }
</script>
@endsection
