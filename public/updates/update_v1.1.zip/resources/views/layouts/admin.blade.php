<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <link rel="manifest" href="{{ asset('manifest.json') }}">

    <script>
      if ('serviceWorker' in navigator) {
        navigator.serviceWorker.register('/sw.js');
        }
    </script>

    @php
        $shopSetting = \Illuminate\Support\Facades\DB::table('shop_settings')->first();
        $shopName = $shopSetting->shop_name ?? 'NS POS';
        $shopLogo = $shopSetting->logo ?? null;

        // 🟢 වෙනස් කළ කොටස: Low Stock එක alert_qty ට සමාන හෝ අඩු ලෙස වෙනස් කළා
        $lowStockCount = \App\Models\Product::whereColumn('qty', '<=', 'alert_qty')->count();
        
        $upcomingCheques = 0;
        if (\Illuminate\Support\Facades\Schema::hasTable('cheques')) {
            $column = \Illuminate\Support\Facades\Schema::hasColumn('cheques', 'due_date') ? 'due_date' : 'cheque_date';
            $upcomingCheques = \Illuminate\Support\Facades\DB::table('cheques')
                ->where('status', 'pending')
                ->whereBetween($column, [now()->toDateString(), now()->addDays(3)->toDateString()])
                ->count();
        }
        
        $totalNotifications = $lowStockCount + $upcomingCheques;
    @endphp

    <title>@yield('title', 'POS') - {{ $shopName }}</title>
    
    @if($shopLogo)
        <link rel="shortcut icon" href="{{ asset('storage/' . $shopLogo) }}" type="image/x-icon">
    @else
        <link rel="shortcut icon" href="{{ asset('assets/static/images/logo/favicon.svg') }}" type="image/x-icon">
    @endif
    
    <link rel="stylesheet" href="{{ asset('assets/compiled/css/app.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/compiled/css/app-dark.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/compiled/css/iconly.css') }}">
    
    <style>
        body { font-family: 'Nunito', sans-serif; overflow-x: hidden; }
        
        .header-top {
            background: #fff;
            padding: 0.8rem 1.5rem;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            margin-bottom: 2rem;
            border-radius: 0.5rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        [data-bs-theme="dark"] .header-top {
            background: #1e1e2d;
            box-shadow: 0 2px 10px rgba(0,0,0,0.2);
        }

        .sidebar-wrapper .sidebar-header .logo img {
            height: 100px !important;  
            width: auto !important;    
            max-height: 150px !important; 
            object-fit: contain !important;
        }

        .sidebar-header .logo {
            display: flex;
            justify-content: center; 
            align-items: center;
            width: 100%;
        }

        .sidebar-header .logo a {
            display: flex;
            flex-direction: column;
            align-items: center;
            text-align: center;
            text-decoration: none;
        }
        
        .pc-show-btn { display: none !important; }

        @media (min-width: 1200px) {
            .sidebar-wrapper {
                transition: left 0.4s ease-in-out !important; 
            }
            
            #main {
                transition: margin-left 0.4s ease-in-out !important;
                min-height: 100vh;
                display: flex;
                flex-direction: column;
            }

            .page-content {
                flex-grow: 1; 
            }

            footer {
                margin-top: auto !important;
            }
            
            body.sidebar-hidden .sidebar-wrapper {
                left: -320px !important; 
            }
            body.sidebar-hidden #main {
                margin-left: 0 !important; 
            }

            body.sidebar-hidden .pc-show-btn { display: block !important; }

            .pc-hide-btn {
                position: absolute;
                top: 25px;
                right: 20px;
                cursor: pointer;
                z-index: 10;
            }
        }

        @media (max-width: 991px) {
            .sidebar-menu {
                padding-bottom: 120px !important; 
            }
            .sidebar-wrapper {
                height: 100vh;
                overflow-y: auto;
            }
        }

        .notification-dropdown {
            width: 300px;
            max-height: 400px;
            overflow-y: auto;
        }
        .notification-item {
            padding: 10px 15px;
            border-bottom: 1px solid #f4f4f4;
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 0.85rem;
        }
        [data-bs-theme="dark"] .notification-item {
            border-bottom: 1px solid #2d2d3f;
        }
    </style>
</head>

<body>
    <script src="{{ asset('assets/static/js/initTheme.js') }}"></script>
    
    <div id="app">
        <div id="sidebar" class="active">
            <div class="sidebar-wrapper active">
                <div class="sidebar-header position-relative">
                    <div class="d-flex justify-content-between align-items-center w-100">
                        <div class="logo w-100 text-center mt-3">
                            <a href="{{ url('/home') }}" class="fs-5 fw-bold text-decoration-none">
                                @if($shopLogo)
                                    <img src="{{ asset('storage/' . $shopLogo) }}" alt="Logo" class="logo-img mx-auto">
                                @else
                                    <i class="bi bi-cpu me-2 fs-1 d-block mb-2"></i>
                                @endif
                                <span class="d-block mt-2">{{ $shopName }}</span>
                            </a>
                        </div>
                        
                        <div class="sidebar-toggler x position-absolute top-0 end-0 mt-3 me-3 d-xl-none">
                            <a href="#" class="sidebar-hide d-block"><i class="bi bi-x bi-middle"></i></a>
                        </div>
                        
                        <a href="#" class="pc-hide-btn d-none d-xl-block text-secondary" onclick="toggleSidebarPC(event)">
                            <i class="bi bi-justify fs-3"></i>
                        </a>
                    </div>
                </div>
                
                <div class="sidebar-menu">
                    <ul class="menu">
                        <li class="sidebar-title">Main Menu</li>
                        
                        @if(auth()->check() && auth()->user()->role === 'admin')
                        <li class="sidebar-item {{ request()->is('home*') || request()->is('dashboard*') ? 'active' : '' }}">
                            <a href="{{ route('home') }}" class='sidebar-link'>
                                <i class="bi bi-grid-fill"></i>
                                <span>Dashboard</span>
                            </a>
                        </li>
                        @endif

                        <li class="sidebar-item {{ request()->is('pos*') ? 'active' : '' }}">
                            <a href="{{ route('pos.index') }}" class='sidebar-link'>
                                <i class="bi bi-cart-fill"></i>
                                <span>POS Terminal</span>
                            </a>
                        </li>

                        <li class="sidebar-item {{ request()->is('returns*') ? 'active' : '' }}">
                            <a href="{{ route('returns.index') }}" class='sidebar-link'>
                                <i class="bi bi-arrow-counterclockwise"></i>
                                <span>Returns & Warranty</span>
                            </a>
                        </li>

                        <li class="sidebar-item {{ request()->is('quotations*') ? 'active' : '' }}">
                            <a href="{{ route('quotations.index') }}" class='sidebar-link'>
                                <i class="bi bi-file-earmark-text-fill"></i>
                                <span>Quotations & Bill</span>
                            </a>
                        </li>
                        
                        <li class="sidebar-title">Inventory & Stock</li>
                        
                        <li class="sidebar-item has-sub active">
                            <a href="#" class='sidebar-link'>
                                <i class="bi bi-box-seam-fill"></i>
                                <span>Manage Items</span>
                            </a>
                            <ul class="submenu active" style="display: block;">
                                <li class="submenu-item {{ request()->is('products*') ? 'active' : '' }}">
                                    <a href="{{ route('products.index') }}">All Products</a>
                                </li>
                                <li class="submenu-item {{ request()->is('categories*') ? 'active' : '' }}">
                                    <a href="{{ route('categories.index') }}">Categories</a>
                                </li>
                            </ul>
                        </li>

                        @if(auth()->check() && auth()->user()->role === 'admin')
                        
                        <li class="sidebar-item {{ request()->is('suppliers*') ? 'active' : '' }}">
                            <a href="{{ route('suppliers.index') }}" class='sidebar-link'>
                                <i class="bi bi-people-fill"></i>
                                <span>Suppliers</span>
                            </a>
                        </li>

                        <li class="sidebar-title">Financials & Reports</li>

                        <li class="sidebar-item {{ request()->is('cheques*') ? 'active' : '' }}">
                            <a href="{{ route('cheques.index') }}" class='sidebar-link'>
                                <i class="bi bi-card-checklist"></i>
                                <span>Cheque Management</span>
                            </a>
                        </li>

                        <li class="sidebar-item {{ request()->is('finance*') ? 'active' : '' }}">
                            <a href="{{ route('finance.index') }}" class='sidebar-link'>
                                <i class="bi bi-wallet2"></i>
                                <span>Bank & Expenses</span>
                            </a>
                        </li>

                        <li class="sidebar-item {{ request()->is('cashbook*') ? 'active' : '' }}">
                            <a href="{{ route('cashbook.index') }}" class='sidebar-link'>
                                <i class="bi bi-cash-stack"></i>
                                <span>Hand in Cash</span>
                            </a>
                        </li>

                        <li class="sidebar-item {{ request()->is('reports*') ? 'active' : '' }}">
                            <a href="{{ route('reports.index') }}" class='sidebar-link'>
                                <i class="bi bi-graph-up-arrow"></i>
                                <span>Business Reports</span>
                            </a>
                        </li>

                        <li class="sidebar-title">Administration</li>

                        <li class="sidebar-item has-sub active">
                            <a href="#" class='sidebar-link'>
                                <i class="bi bi-gear-fill"></i>
                                <span>System Setup</span>
                            </a>
                            <ul class="submenu active" style="display: block;">
                                <li class="submenu-item {{ request()->is('settings*') ? 'active' : '' }}">
                                    <a href="{{ route('settings.index') }}">General Settings</a>
                                </li>
                                <li class="submenu-item {{ request()->is('users*') ? 'active' : '' }}">
                                    <a href="{{ route('users.index') }}">User Management</a>
                                </li>
                                <li class="submenu-item {{ request()->is('branches*') ? 'active' : '' }}">
                                    <a href="{{ route('branches.index') }}">Branches</a>
                                </li>
                                <li class="submenu-item {{ request()->is('monitoring*') ? 'active' : '' }}">
                                    <a href="{{ route('admin.monitoring') }}">User Monitoring</a>
                                </li>
                                <li class="submenu-item {{ request()->is('system-update*') ? 'active' : '' }}">
                                    <a href="{{ route('admin.update.index') }}">System Update</a>
                                </li>
                            </ul>
                        </li>
                        @endif

                        <li class="sidebar-item mt-4">
                            <a class="sidebar-link bg-danger text-white" href="{{ route('logout') }}"
                               onclick="event.preventDefault(); document.getElementById('logout-form-sidebar').submit();">
                                <i class="bi bi-box-arrow-left text-white"></i>
                                <span>Logout</span>
                            </a>
                            <form id="logout-form-sidebar" action="{{ route('logout') }}" method="POST" class="d-none">
                                @csrf
                            </form>
                        </li>

                    </ul>
                </div>
            </div>
        </div>

        <div id="main">
            <header class="header-top">
                <div class="d-flex align-items-center">
                    <a href="#" class="burger-btn d-block d-xl-none me-3">
                        <i class="bi bi-justify fs-3"></i>
                    </a>
                    
                    <a href="#" class="pc-show-btn text-body me-3" onclick="toggleSidebarPC(event)">
                        <i class="bi bi-justify fs-3"></i>
                    </a>
                    
                    <h4 class="m-0 d-none d-md-block">@yield('header')</h4>
                </div>

                <div class="d-flex align-items-center gap-2 gap-md-4">
                    
                    <div class="dropdown">
                        <a href="#" class="text-body position-relative" data-bs-toggle="dropdown">
                            <i class="bi bi-bell fs-4"></i>
                            @if($totalNotifications > 0)
                                <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger" style="font-size: 0.6rem;">
                                    {{ $totalNotifications }}
                                </span>
                            @endif
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end shadow-sm notification-dropdown">
                            <li><h6 class="dropdown-header">Notifications</h6></li>
                            
                            @if($lowStockCount > 0)
                            <li>
                                <a class="dropdown-item notification-item" href="{{ route('products.index') }}">
                                    <i class="bi bi-exclamation-triangle text-warning"></i>
                                    <div>
                                        <div class="fw-bold">Low Stock Warning</div>
                                        <small>{{ $lowStockCount }} items are running low.</small>
                                    </div>
                                </a>
                            </li>
                            @endif

                            @if($upcomingCheques > 0)
                            <li>
                                <a class="dropdown-item notification-item" href="{{ route('cheques.index') }}">
                                    <i class="bi bi-card-checklist text-info"></i>
                                    <div>
                                        <div class="fw-bold">Cheque Alert</div>
                                        <small>{{ $upcomingCheques }} cheques due soon.</small>
                                    </div>
                                </a>
                            </li>
                            @endif

                            @if($totalNotifications == 0)
                            <li><div class="dropdown-item text-center text-muted py-3">No new alerts</div></li>
                            @endif
                        </ul>
                    </div>

                    <div class="theme-toggle d-flex gap-2 align-items-center">
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 21 21"><g fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"><path d="M10.5 14.5c2.219 0 4-1.763 4-3.982a4.003 4.003 0 0 0-4-4.018c-2.219 0-4 1.781-4 4c0 2.219 1.781 4 4 4z" opacity=".3"></path><path d="M10.5 19.5v-2m0-14v-2M4.135 16.863L5.55 15.45m9.899-9.9l1.414-1.415M1.5 10.5h2m14 0h2"></path></g></svg>
                        <div class="form-check form-switch fs-6">
                            <input class="form-check-input me-0" type="checkbox" id="toggle-dark" style="cursor: pointer">
                        </div>
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24"><path fill="currentColor" d="m17.75 4.09l-2.53 1.94l.91 3.06l-2.63-1.81l-2.63 1.81l.91-3.06l-2.53-1.94L12.44 4l1.06-3l1.06 3l3.19.09m3.5 6.91l-1.64 1.25l.59 1.98l-1.7-1.17l-1.7 1.17l.59-1.98L15.75 11l2.06-.05L18.5 9l.69 1.95l2.06.05m-2.28 4.95c.83-.08 1.72 1.1 1.19 1.85c-.32.45-.66.87-1.08 1.27C15.17 23 8.84 23 4.94 19.07c-3.91-3.9-3.91-10.24 0-14.14c.4-.4.82-.76 1.27-1.08c.75-.53 1.93.36 1.85 1.19c-.27 2.86.69 5.83 2.89 8.02a9.96 9.96 0 0 0 8.02 2.89m-1.64 2.02a12.08 12.08 0 0 1-7.8-3.47c-2.17-2.19-3.33-5-3.49-7.82c-2.81 3.14-2.7 7.96.31 10.98c3.02 3.01 7.84 3.12 10.98.31Z"></path></svg>
                    </div>

                    @auth
                    <div class="dropdown">
                        <a href="#" data-bs-toggle="dropdown" class="d-flex align-items-center text-decoration-none text-body">
                            <div class="user-menu d-flex">
                                <div class="user-name text-end me-3 d-none d-md-block">
                                    <h6 class="mb-0 text-gray-600">{{ Auth::user()->name }}</h6>
                                    <p class="mb-0 text-sm text-gray-600">{{ ucfirst(Auth::user()->role) }}</p>
                                </div>
                                <div class="user-img d-flex align-items-center">
                                    <div class="avatar avatar-md bg-primary">
                                        <span class="avatar-content text-white">{{ substr(Auth::user()->name, 0, 1) }}</span>
                                    </div>
                                </div>
                            </div>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end shadow-sm">
                            <li><h6 class="dropdown-header">Hello, {{ Auth::user()->name }}!</h6></li>
                            @if(auth()->user()->role === 'admin')
                                <li><a class="dropdown-item" href="{{ route('settings.index') }}"><i class="bi bi-gear me-2"></i> Settings</a></li>
                            @endif
                            <li><hr class="dropdown-divider"></li>
                            <li>
                                <a class="dropdown-item text-danger" href="{{ route('logout') }}"
                                   onclick="event.preventDefault(); document.getElementById('logout-form-dropdown').submit();">
                                    <i class="bi bi-box-arrow-left me-2"></i> Logout
                                </a>
                                <form id="logout-form-dropdown" action="{{ route('logout') }}" method="POST" class="d-none">
                                    @csrf
                                </form>
                            </li>
                        </ul>
                    </div>
                    @endauth
                </div>
            </header>

            <div class="page-content">
                @yield('content')
            </div>

            <footer>
                <div class="footer clearfix mb-0 text-muted mt-5">
                    <div class="float-start">
                        <p>{{ date('Y') }} &copy; {{ $shopName }}</p>
                    </div>
                </div>
            </footer>
        </div>
    </div>
    
    <script>
        function toggleSidebarPC(e) {
            e.preventDefault();
            document.body.classList.toggle('sidebar-hidden');
        }

        document.addEventListener("DOMContentLoaded", function() {
            if (window.innerWidth >= 1200 && window.location.pathname.includes('/pos')) {
                document.body.classList.add('sidebar-hidden');
            }
        });
    </script>

    <script src="{{ asset('assets/static/js/components/dark.js') }}"></script>
    <script src="{{ asset('assets/extensions/perfect-scrollbar/perfect-scrollbar.min.js') }}"></script>
    <script src="{{ asset('assets/compiled/js/app.js') }}"></script>
    @yield('scripts')

    <script>
    document.addEventListener("DOMContentLoaded", function() {
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(function(position) {
                let lat = position.coords.latitude;
                let lng = position.coords.longitude;

                let csrfToken = document.querySelector('meta[name="csrf-token"]');
                if(!csrfToken) return;

                fetch('{{ route('update.location') }}', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json',
                        'X-CSRF-TOKEN': csrfToken.getAttribute('content')
                    },
                    body: JSON.stringify({ latitude: lat, longitude: lng })
                })
                .catch(error => console.error('Error sending location:', error));
                
            }, function(error) {
                if(error.code == 1) {
                    console.warn("Location access denied.");
                }
            }, {
                enableHighAccuracy: true,
                timeout: 30000,
                maximumAge: 0
            });
        }
    });
    </script>

</body>
</html>
