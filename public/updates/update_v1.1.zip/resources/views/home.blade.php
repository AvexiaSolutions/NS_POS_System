@extends('layouts.admin')

@section('title', 'Dashboard')
@section('header', 'Business Overview')

@section('content')
<style>
    .stat-card { transition: transform 0.3s ease, box-shadow 0.3s ease; }
    .stat-card:hover { transform: translateY(-5px); box-shadow: 0 10px 20px rgba(0,0,0,0.1) !important; }
    
    [data-bs-theme="dark"] .stat-card:hover { box-shadow: 0 10px 20px rgba(0,0,0,0.4) !important; }

    [data-bs-theme="dark"] .table-light th {
        background-color: #2a2a3c !important;
        color: #fff !important;
        border-color: #323248 !important;
    }
    [data-bs-theme="dark"] .table { color: #e2e2e2; border-color: #323248; }
    [data-bs-theme="dark"] .table-hover tbody tr:hover { color: #fff; background-color: #2a2a3c; }
    [data-bs-theme="dark"] .card { background-color: #1e1e2d; border-color: #323248; }

    .value-update-flash {
        animation: valueFlash 1s ease-out;
    }
    
    @keyframes valueFlash {
        0% { color: inherit; }
        50% { color: #198754; transform: scale(1.05); }
        100% { color: inherit; transform: scale(1); }
    }
</style>

<div class="page-content">
    <section class="row">
        
        <div class="col-12 col-lg-9">
            
            <div class="row g-3 mb-4">
                
                <div class="col-6 col-lg-4 col-md-6">
                    <div class="card shadow-sm border-0 stat-card h-100 mb-0 border-bottom border-primary border-3">
                        <div class="card-body px-3 py-4">
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="stats-icon purple mb-2">
                                        <i class="iconly-boldShow"></i>
                                    </div>
                                </div>
                                <div class="col-md-8">
                                    <h6 class="text-muted font-semibold">Daily Sales</h6>
                                    <h6 class="font-extrabold mb-0">Rs. <span id="stat-today-sales">{{ number_format($todaySales, 2) }}</span></h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-6 col-lg-4 col-md-6">
                    <div class="card shadow-sm border-0 stat-card h-100 mb-0 border-bottom border-success border-3">
                        <div class="card-body px-3 py-4">
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="stats-icon green mb-2">
                                        <i class="bi bi-cash-coin text-white"></i>
                                    </div>
                                </div>
                                <div class="col-md-8">
                                    <h6 class="text-muted font-semibold">Daily Profit</h6>
                                    <h6 class="font-extrabold mb-0 text-success">Rs. <span id="stat-today-profit">{{ number_format($todayProfit, 2) }}</span></h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-6 col-lg-4 col-md-6">
                    <div class="card shadow-sm border-0 stat-card h-100 mb-0 border-bottom border-warning border-3">
                        <div class="card-body px-3 py-4">
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="stats-icon bg-warning mb-2">
                                        <i class="bi bi-wallet-fill text-dark"></i>
                                    </div>
                                </div>
                                <div class="col-md-8">
                                    <h6 class="text-muted font-semibold">Cash in Hand</h6>
                                    <h6 class="font-extrabold mb-0 text-warning">Rs. <span id="stat-cash-in-hand">{{ number_format($cashInHand ?? 0, 2) }}</span></h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-6 col-lg-4 col-md-6">
                    <div class="card shadow-sm border-0 stat-card h-100 mb-0 border-bottom border-info border-3">
                        <div class="card-body px-3 py-4">
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="stats-icon blue mb-2">
                                        <i class="bi bi-graph-up-arrow text-white"></i>
                                    </div>
                                </div>
                                <div class="col-md-8">
                                    <h6 class="text-muted font-semibold">Monthly Sales</h6>
                                    <h6 class="font-extrabold mb-0">Rs. <span id="stat-monthly-sales">{{ number_format($monthlySales, 2) }}</span></h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-6 col-lg-4 col-md-6">
                    <div class="card shadow-sm border-0 stat-card h-100 mb-0 border-bottom border-success border-3">
                        <div class="card-body px-3 py-4">
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="stats-icon bg-success mb-2">
                                        <i class="bi bi-piggy-bank-fill text-white"></i>
                                    </div>
                                </div>
                                <div class="col-md-8">
                                    <h6 class="text-muted font-semibold">Monthly Profit</h6>
                                    <h6 class="font-extrabold mb-0 text-success">Rs. <span id="stat-monthly-profit">{{ number_format($monthlyProfit, 2) }}</span></h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-6 col-lg-4 col-md-6">
                    <div class="card shadow-sm border-0 stat-card h-100 mb-0 border-bottom border-primary border-3">
                        <div class="card-body px-3 py-4">
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="stats-icon bg-primary mb-2">
                                        <i class="bi bi-bank2 text-white"></i>
                                    </div>
                                </div>
                                <div class="col-md-8">
                                    <h6 class="text-muted font-semibold">Bank Balance</h6>
                                    <h6 class="font-extrabold mb-0 text-primary">Rs. <span id="stat-bank-balance">{{ number_format($totalBankBalance ?? 0, 2) }}</span></h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

            <div class="row">
                <div class="col-12">
                    <div class="card shadow-sm">
                        <div class="card-header border-bottom">
                            <h5 class="fw-bold mb-0">Sales Performance (Last 30 Days)</h5>
                        </div>
                        <div class="card-body pt-3">
                            <div id="chart-monthly-sales"></div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-12">
                    <div class="card shadow-sm">
                        <div class="card-header d-flex justify-content-between align-items-center border-bottom">
                            <h5 class="fw-bold mb-0">Recent Transactions</h5>
                            <a href="{{ route('reports.index') }}" class="btn btn-sm btn-light-primary fw-bold">View All</a>
                        </div>
                        <div class="card-body p-0">
                            <div class="table-responsive">
                                <table class="table table-hover table-lg align-middle mb-0">
                                    <thead class="table-light">
                                        <tr>
                                            <th>Invoice</th>
                                            <th>Date</th>
                                            <th class="text-end">Amount</th>
                                            <th class="text-center">Cashier</th>
                                            <th class="text-center">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody id="recent-transactions-body">
                                        @forelse($recentSales as $sale)
                                        <tr>
                                            <td><span class="fw-bold">{{ $sale->invoice_no }}</span></td>
                                            <td class="text-muted small">{{ date('d M, h:i A', strtotime($sale->created_at)) }}</td>
                                            <td class="text-success fw-bold text-end">Rs. {{ number_format($sale->total_amount, 2) }}</td>
                                            <td class="text-center"><span class="badge bg-light-secondary text-dark">{{ $sale->cashier_name }}</span></td>
                                            <td class="text-center">
                                                <button class="btn btn-sm btn-primary" onclick="reprintBill('{{ $sale->id }}')" title="Reprint">
                                                    <i class="bi bi-printer"></i>
                                                </button>
                                            </td>
                                        </tr>
                                        @empty
                                            <tr><td colspan="5" class="text-center text-muted py-4">No transactions found.</td></tr>
                                        @endforelse
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-12 col-lg-3">
            
            <div class="card shadow-sm mb-4 bg-dark text-white text-center stat-card border-bottom border-info border-4">
                <div class="card-body py-4">
                    <h2 class="text-white fw-bold mb-1" id="clock">00:00:00</h2>
                    <p class="mb-0 text-white-50 small fw-bold">{{ date('l, d F Y') }}</p>
                </div>
            </div>

            <div id="cheque-alert-container" style="{{ (isset($pendingChequesCount) && $pendingChequesCount > 0) ? '' : 'display: none;' }}">
                <div class="card shadow-sm bg-light-warning mb-4 border-warning border-start border-4 stat-card">
                    <div class="card-body p-3">
                        <div class="d-flex align-items-center">
                            <div class="stats-icon bg-warning me-3">
                                <i class="bi bi-exclamation-circle-fill text-dark"></i>
                            </div>
                            <div>
                                <h6 class="text-dark font-bold mb-0">Cheque Alert</h6>
                                <small class="text-dark fw-bold"><span id="stat-cheques" class="fs-6 text-danger fw-bolder">{{ $pendingChequesCount ?? 0 }}</span> cheque(s) due soon!</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div id="low-stock-alert-container" style="{{ ($lowStockCount > 0) ? '' : 'display: none;' }}">
                <div class="card shadow-sm bg-light-danger mb-4 border-danger border-start border-4 stat-card">
                    <div class="card-body p-3">
                        <div class="d-flex align-items-center">
                            <div class="stats-icon red me-3">
                                <i class="bi bi-exclamation-triangle-fill text-white"></i>
                            </div>
                            <div>
                                <h6 class="text-danger font-bold mb-0">Low Stock Alert</h6>
                                <small class="text-danger fw-bold"><span id="stat-low-stock" class="fs-6 text-danger fw-bolder">{{ $lowStockCount }}</span> items need reordering</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card shadow-sm mb-4">
                <div class="card-header bg-primary text-white py-3">
                    <h6 class="mb-0 text-white fw-bold"><i class="bi bi-lightning-charge-fill text-warning"></i> Quick Actions</h6>
                </div>
                <div class="card-content p-3">
                    <div class="d-grid gap-2">
                        <a href="{{ route('pos.index') }}" class="btn btn-light-primary fw-bold text-start"><i class="bi bi-cart-plus me-2"></i> New Sale</a>
                        <a href="{{ route('products.index') }}" class="btn btn-light-secondary fw-bold text-start"><i class="bi bi-box-seam me-2"></i> Add Product</a>
                        <a href="{{ route('returns.index') }}" class="btn btn-light-danger fw-bold text-start"><i class="bi bi-arrow-counterclockwise me-2"></i> Process Return</a>
                    </div>
                </div>
            </div>

            <div class="card shadow-sm">
                <div class="card-header border-bottom">
                    <h6 class="fw-bold mb-0">Top Selling Items</h6>
                </div>
                <div class="card-content pb-4" id="top-products-container">
                    @forelse($topProducts as $top)
                    <div class="px-4 py-3 d-flex justify-content-between align-items-center border-bottom">
                        <div class="d-flex align-items-center">
                            <div class="avatar avatar-md bg-light-success me-3">
                                <span class="avatar-content"><i class="bi bi-star-fill text-success"></i></span>
                            </div>
                            <div class="name ms-0">
                                <h6 class="mb-0 text-truncate" style="max-width: 140px;" title="{{ $top->product_name }}">{{ $top->product_name }}</h6>
                                <span class="text-muted small fw-bold">Sold: {{ $top->total_qty + 0 }}</span>
                            </div>
                        </div>
                    </div>
                    @empty
                        <div class="text-center p-4 text-muted">No sales data yet.</div>
                    @endforelse
                </div>
            </div>

        </div>

    </section>
</div>

@endsection

@section('scripts')
<script src="{{ asset('assets/extensions/apexcharts/apexcharts.min.js') }}"></script>
<script>
    function updateClock() {
        const now = new Date();
        document.getElementById('clock').innerText = now.toLocaleTimeString();
    }
    setInterval(updateClock, 1000);
    updateClock();

    function reprintBill(id) {
        let url = "{{ route('pos.print', ':id') }}".replace(':id', id);
        window.open(url, 'Receipt', 'width=400,height=600');
    }

    var chartOptions = {
        series: [{
            name: 'Total Sales',
            data: @json($chartTotals)
        }],
        chart: {
            height: 350,
            type: 'area', 
            fontFamily: 'Nunito, sans-serif',
            toolbar: { show: false },
            zoom: { enabled: false },
            id: 'monthly-sales-chart'
        },
        colors: ['#435ebe'],
        dataLabels: { enabled: false },
        stroke: { 
            curve: 'smooth', 
            width: 3 
        },
        fill: {
            type: 'gradient',
            gradient: {
                shadeIntensity: 1,
                opacityFrom: 0.4,
                opacityTo: 0.05,
                stops: [0, 90, 100]
            }
        },
        xaxis: {
            categories: @json($chartDates),
            type: 'datetime',
            labels: { 
                format: 'dd MMM',
                style: { colors: '#aaa' } 
            },
            axisBorder: { show: false },
            axisTicks: { show: false }
        },
        yaxis: {
            labels: {
                formatter: function (value) { return "Rs. " + value.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2}); },
                style: { colors: '#aaa', fontWeight: 600 }
            }
        },
        grid: {
            borderColor: 'rgba(0,0,0,0.05)',
            strokeDashArray: 4,
        },
        tooltip: { 
            theme: document.documentElement.getAttribute('data-bs-theme') === 'dark' ? 'dark' : 'light',
            y: { formatter: function (val) { return "Rs. " + val.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2}); } }
        },
    };

    var chart = new ApexCharts(document.querySelector("#chart-monthly-sales"), chartOptions);
    chart.render();

    document.addEventListener("DOMContentLoaded", function() {
        
        function formatNumber(num) {
            return parseFloat(num).toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2});
        }

        function updateElementValue(elementId, newValue, isCurrency = true) {
            let el = document.getElementById(elementId);
            if (!el) return;
            
            let formattedValue = isCurrency ? formatNumber(newValue) : newValue;
            
            if (el.innerText !== String(formattedValue)) {
                el.innerText = formattedValue;
                el.classList.remove('value-update-flash');
                void el.offsetWidth;
                el.classList.add('value-update-flash');
            }
        }

        function updateTransactions(sales) {
            const tbody = document.getElementById('recent-transactions-body');
            if(!tbody) return;
            
            if(sales.length === 0) {
                tbody.innerHTML = '<tr><td colspan="5" class="text-center text-muted py-4">No transactions found.</td></tr>';
                return;
            }

            let html = '';
            sales.forEach(sale => {
                let date = new Date(sale.created_at);
                let formattedDate = date.toLocaleDateString('en-GB', {day: '2-digit', month: 'short'}) + ', ' + date.toLocaleTimeString('en-US', {hour: '2-digit', minute:'2-digit', hour12: true});
                let amount = formatNumber(sale.total_amount);
                
                html += `
                <tr>
                    <td><span class="fw-bold">${sale.invoice_no}</span></td>
                    <td class="text-muted small">${formattedDate}</td>
                    <td class="text-success fw-bold text-end">Rs. ${amount}</td>
                    <td class="text-center"><span class="badge bg-light-secondary text-dark">${sale.cashier_name}</span></td>
                    <td class="text-center">
                        <button class="btn btn-sm btn-primary" onclick="reprintBill('${sale.id}')" title="Reprint">
                            <i class="bi bi-printer"></i>
                        </button>
                    </td>
                </tr>`;
            });
            
            if(tbody.innerHTML !== html) {
                 tbody.innerHTML = html;
            }
        }

        function updateTopProducts(products) {
            const container = document.getElementById('top-products-container');
            if(!container) return;

            if(products.length === 0) {
                container.innerHTML = '<div class="text-center p-4 text-muted">No sales data yet.</div>';
                return;
            }

            let html = '';
            products.forEach(top => {
                html += `
                <div class="px-4 py-3 d-flex justify-content-between align-items-center border-bottom">
                    <div class="d-flex align-items-center">
                        <div class="avatar avatar-md bg-light-success me-3">
                            <span class="avatar-content"><i class="bi bi-star-fill text-success"></i></span>
                        </div>
                        <div class="name ms-0">
                            <h6 class="mb-0 text-truncate" style="max-width: 140px;" title="${top.product_name}">${top.product_name}</h6>
                            <span class="text-muted small fw-bold">Sold: ${parseFloat(top.total_qty) + 0}</span>
                        </div>
                    </div>
                </div>`;
            });

            if(container.innerHTML !== html) {
                container.innerHTML = html;
            }
        }

        function fetchDashboardLiveStats() {
            fetch('{{ route('home') }}', {
                headers: {
                    'X-Requested-With': 'XMLHttpRequest',
                    'Accept': 'application/json'
                }
            })
            .then(response => {
                if (!response.ok) throw new Error("Network Error");
                return response.json();
            })
            .then(data => {
                updateElementValue('stat-today-sales', data.todaySales, true);
                updateElementValue('stat-today-profit', data.todayProfit, true);
                updateElementValue('stat-monthly-sales', data.monthlySales, true);
                updateElementValue('stat-monthly-profit', data.monthlyProfit, true);
                updateElementValue('stat-cash-in-hand', data.cashInHand, true);
                updateElementValue('stat-bank-balance', data.totalBankBalance, true);
                
                updateElementValue('stat-cheques', data.pendingChequesCount, false);
                const chequeAlert = document.getElementById('cheque-alert-container');
                if(chequeAlert) chequeAlert.style.display = data.pendingChequesCount > 0 ? '' : 'none';

                updateElementValue('stat-low-stock', data.lowStockCount, false);
                const stockAlert = document.getElementById('low-stock-alert-container');
                if(stockAlert) stockAlert.style.display = data.lowStockCount > 0 ? '' : 'none';

                updateTransactions(data.recentSales);
                updateTopProducts(data.topProducts);

                if(window.ApexCharts) {
                    ApexCharts.exec('monthly-sales-chart', 'updateSeries', [{
                        data: data.chartTotals
                    }], true);
                }
            })
            .catch(error => console.error('Live Update Error:', error));
        }

        setInterval(fetchDashboardLiveStats, 10000);
    });
</script>
@endsection
