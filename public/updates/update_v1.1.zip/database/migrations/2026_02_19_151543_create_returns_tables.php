<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        // Returns Main Table
        Schema::create('returns', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->string('sale_id'); // Link to original sale
            $table->string('invoice_no');
            $table->unsignedBigInteger('user_id'); // Cashier
            $table->decimal('total_refund', 10, 2)->default(0);
            $table->text('reason')->nullable();
            $table->timestamps();
            
            // Foreign Keys
            $table->foreign('sale_id')->references('id')->on('sales')->onDelete('cascade');
        });

        // Return Items Table
        Schema::create('return_items', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->string('return_id');
            $table->unsignedBigInteger('product_id');
            $table->decimal('qty', 10, 2);
            $table->decimal('refund_amount', 10, 2);
            $table->string('type')->default('return'); // 'return' or 'warranty_claim'
            $table->timestamps();

            $table->foreign('return_id')->references('id')->on('returns')->onDelete('cascade');
        });
    }

    public function down()
    {
        Schema::dropIfExists('return_items');
        Schema::dropIfExists('returns');
    }
};
