<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('sales', function (Blueprint $table) {
            // බැංකුවෙන් අය කරන ගාස්තුව (Card නම් 3%)
            $table->decimal('bank_charge', 10, 2)->default(0)->after('total_amount');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('sales', function (Blueprint $table) {
            // අලුතින් එක් කළ Columns ඉවත් කිරීම (Rollback කිරීම සඳහා)
            $table->dropColumn(['bank_charge']);
        });
    }
};
