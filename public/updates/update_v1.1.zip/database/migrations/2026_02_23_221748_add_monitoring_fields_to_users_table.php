<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
{
    Schema::table('users', function (Blueprint $table) {
        $table->timestamp('last_seen_at')->nullable(); // අන්තිමට Active හිටිය වෙලාව
        $table->string('last_ip')->nullable();         // අන්තිමට ආපු IP එක
        $table->boolean('is_banned')->default(false);  // Block කරලාද නැද්ද යන්න
    });
}

public function down(): void
{
    Schema::table('users', function (Blueprint $table) {
        $table->dropColumn(['last_seen_at', 'last_ip', 'is_banned']);
    });
}

};
