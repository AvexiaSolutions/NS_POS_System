<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
{
    // 1. Rolls Save කරන්න අලුත් Table එක
    Schema::create('product_rolls', function (Blueprint $table) {
        $table->id(); 
        
        // --- වෙනස් කළ කොටස ---
        // කලින් තිබුනේ foreignId. අපේ ID එක UUID නිසා මේක foreignUuid වෙන්න ඕනේ.
        $table->foreignUuid('product_id')->constrained()->onDelete('cascade'); 
        // ----------------------

        $table->string('roll_length');
        $table->decimal('roll_price', 10, 2);
        $table->timestamps();
    });

    // 2. Product Table එකට Discount
    Schema::table('products', function (Blueprint $table) {
        // කලින් Error එක නිසා මේ කොටස තාම run වෙලා නැතුව ඇති. ඒ නිසා මේක තියන්න.
        // හැබැයි සමහර විට Error එක එන්න කලින් මේක හැදුනා නම්, ආයේ Run කරද්දී Error එයි.
        // එහෙම වුණොත් විතරක් මේ කොටස මකන්න වෙනවා. දැනට එහෙමම තියන්න.
        $table->decimal('discount_price', 10, 2)->nullable()->default(0);
        $table->string('discount_type')->default('amount');
    });

    // 3. User Table එකට Active Status
    Schema::table('users', function (Blueprint $table) {
        $table->boolean('is_active')->default(true);
    });
}



    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        //
    }
};
