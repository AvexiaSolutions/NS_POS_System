<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('products', function (Blueprint $table) {
            // expire_date එක අලුතින් එකතු කරනවා
            // Electronic බඩු වලට මේක ඕන නැති නිසා 'nullable' දානවා
            // 'qty' තීරුවට පසුව මෙය එකතු වේ
            $table->date('expire_date')->nullable()->after('qty');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('products', function (Blueprint $table) {
            $table->dropColumn('expire_date');
        });
    }
};
