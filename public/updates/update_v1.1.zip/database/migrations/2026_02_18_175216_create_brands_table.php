<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
{
    Schema::create('brands', function (Blueprint $table) {
        $table->uuid('id')->primary();
        $table->uuid('branch_id'); // මොන කඩේටද අදාළ කියල
        $table->string('name'); // Company Name (Ex: Sony, CIC)
        $table->timestamps();
    });
}


    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('brands');
    }
};
