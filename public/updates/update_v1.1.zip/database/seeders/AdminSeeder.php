<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class AdminSeeder extends Seeder
{
    public function run(): void
    {
        // 1. Main Branch එක හදමු
        $branchId = Str::uuid(); // Branch එකට අලුත් ID එකක්
        
        DB::table('branches')->insert([
            'id' => $branchId,
            'name' => 'NS Enterprises - Main Branch',
            'address' => 'No 123, Main Street, Colombo',
            'phone' => '0771234567',
            'is_active' => true,
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        // 2. Admin User ව හදමු (Branch එකට ලින්ක් කරලා)
        DB::table('users')->insert([
            'id' => Str::uuid(),
            'branch_id' => $branchId, // අර උඩ හැදුව Branch ID එක
            'name' => 'System Admin',
            'email' => 'admin@ns.lk',
            'password' => Hash::make('password'), // මුරපදය: password
            'role' => 'admin',
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        
        // 3. Shop Settings (Default)
        DB::table('shop_settings')->insert([
            'id' => Str::uuid(),
            'branch_id' => $branchId,
            'shop_name' => 'NS Enterprises',
            'created_at' => now(),
            'updated_at' => now(),
        ]);
    }
}
