<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;

class Supplier extends Model
{
    // ඔයාගේ Database Table එකේ තියෙන Columns
    protected $fillable = [
        'branch_id', 
        'company_name', 
        'contact_person', 
        'phone', 
        'email', 
        'address', 
        'credit_balance'
    ];
    
    protected $keyType = 'string';
    public $incrementing = false;

    protected static function boot()
    {
        parent::boot();
        static::creating(function ($model) {
            if (empty($model->id)) {
                $model->id = (string) Str::uuid();
            }
            // අලුතින් සපයන්නෙක් එකතු කරද්දී ණය මුදල බින්දුවක් ලෙස සකසයි
            if (empty($model->credit_balance)) {
                $model->credit_balance = 0.00;
            }
        });
    }

    // සපයන්නා අයිති ශාඛාව
    public function branch()
    {
        return $this->belongsTo(Branch::class);
    }
}
