<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;

// වැදගත්: මෙතන නම 'Branch' ලෙස තිබිය යුතුයි
class Branch extends Model
{
    protected $fillable = ['name', 'address', 'phone', 'is_active'];
    protected $keyType = 'string';
    public $incrementing = false;

    protected static function boot()
    {
        parent::boot();
        static::creating(function ($model) {
            if (empty($model->id)) {
                $model->id = (string) Str::uuid();
            }
        });
    }
}
