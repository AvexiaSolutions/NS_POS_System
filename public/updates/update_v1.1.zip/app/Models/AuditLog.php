<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Concerns\HasUuids; // 🟢 UUID පාවිච්චි කරන නිසා මේක අනිවාර්යයි
use Illuminate\Support\Facades\DB;

class AuditLog extends Model
{
    use HasUuids;

    protected $fillable = [
        'user_id',
        'action',
        'description',
        'ip_address',
        'device_info',
        'location'
    ];

    // User relationship
    public function user()
    {
        return $this->belongsTo(User::class);
    }

    // ==============================================================
    // 🟢 මැජික් Function එක: මුළු සිස්ටම් එකේම ලේසියෙන් Log කරන්න
    // ==============================================================
    public static function record($action, $description = null)
    {
        $request = request();
        
        // අර අපි කලින් සේව් කරපු ලොකේෂන් එක Session ටේබල් එකෙන් ගන්නවා
        $session = DB::table('sessions')->where('id', session()->getId())->first();
                    
        $location = null;
        if ($session && $session->latitude && $session->longitude) {
            $location = $session->latitude . ',' . $session->longitude;
        }

        self::create([
            'user_id' => auth()->id(),
            'action' => $action,
            'description' => $description,
            'ip_address' => $request->ip(),
            'device_info' => $request->header('User-Agent'),
            'location' => $location
        ]);
    }
}
