<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;

class Expense extends Model
{
    // Database එකේ ඇති columns වලට ගැලපෙන ලෙස
    protected $fillable = [
        'branch_id', 
        'category', 
        'amount', 
        'bank_account_id', 
        'description', 
        'expense_date'
    ];

    protected $keyType = 'string';
    public $incrementing = false;

    // UUID එකක් auto generate කිරීමට
    protected static function boot()
    {
        parent::boot();
        static::creating(function ($model) {
            if (empty($model->id)) {
                $model->id = (string) Str::uuid();
            }
        });
    }

    // බැංකු ගිණුම සමඟ ඇති සම්බන්ධය
    public function bankAccount()
    {
        return $this->belongsTo(BankAccount::class, 'bank_account_id');
    }
}
