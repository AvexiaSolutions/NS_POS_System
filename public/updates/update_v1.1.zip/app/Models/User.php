<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Illuminate\Support\Str;
use Laravel\Sanctum\HasApiTokens;

class User extends Authenticatable
{
    // 🟢 HasApiTokens ඇතුළත් කිරීම නිසා දැන් Mobile App එකේ Login වැඩ කරනවා
    use HasApiTokens, HasFactory, Notifiable;

    // UUID භාවිතා කරන බැවින් incrementing අක්‍රිය කිරීම
    public $incrementing = false;
    protected $keyType = 'string';

    protected $fillable = [
        'id',
        'branch_id',
        'name',
        'email',
        'password',
        'role',
        'is_active',
    ];

    protected $hidden = [
        'password',
        'remember_token',
    ];

    protected function casts(): array
    {
        return [
            'email_verified_at' => 'datetime',
            'password' => 'hashed',
            'is_active' => 'boolean',
            'last_seen_at' => 'datetime', // 🟢 Error එක විසඳීම සඳහා අලුතින් එකතු කළ කොටස
        ];
    }

    // අලුතින් User කෙනෙක් හදද්දී ස්වයංක්‍රීයව UUID එකක් සෑදීම
    protected static function boot()
    {
        parent::boot();
        static::creating(function ($model) {
            if (empty($model->id)) {
                $model->id = (string) Str::uuid();
            }
        });
    }

    // User Settings (Theme/Dark Mode) සමඟ සම්බන්ධය
    public function settings()
    {
        return $this->hasOne(UserSetting::class, 'user_id', 'id');
    }

    // Branch එක සමඟ සම්බන්ධය (අවශ්‍ය නම්)
    public function branch()
    {
        return $this->belongsTo(Branch::class);
    }
}
