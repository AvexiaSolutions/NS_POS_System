<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use App\Traits\HasUuid;

class Brand extends Model
{
    use HasFactory, HasUuid;

    protected $fillable = ['branch_id', 'name'];

    // --- මේ කොටස තමයි ඔයාට අඩු වෙලා තිබුණේ ---
    public function branch()
    {
        return $this->belongsTo(Branch::class);
    }
    // ----------------------------------------
}
