<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use App\Traits\HasUuid; // අපි කලින් හදපු UUID Trait එක

class Category extends Model
{
    use HasFactory, HasUuid;

    protected $fillable = [
        'branch_id', // කඩේ තෝරන්න මේක ඕනේ
        'name',
        'code'
    ];

    // Category එක අයිති Branch එක ලබාගන්න
    public function branch()
    {
        return $this->belongsTo(Branch::class);
    }
}
