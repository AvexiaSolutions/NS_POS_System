<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Symfony\Component\HttpFoundation\Response;

class UserMonitoringMiddleware
{
    public function handle(Request $request, Closure $next): Response
    {
        if (Auth::check()) {
            $user = Auth::user();

            // 1. User ව Block කරලා නම් වහාම පද්ධතියෙන් ඉවත් කිරීම
            if ($user->is_banned) {
                Auth::logout();
                $request->session()->invalidate();
                $request->session()->regenerateToken();
                return redirect()->route('login')->withErrors(['email' => 'ඔබගේ ගිණුම තාවකාලිකව අත්හිටුවා ඇත. කරුණාකර Admin අමතන්න.']);
            }

            // 2. User ගේ Online Status සහ IP එක Update කිරීම (සෑම මිනිත්තු 1කට වරක් පමණක් Database එක Update කරමු, වේගය වැඩිවීමට)
            if (!$user->last_seen_at || now()->diffInMinutes($user->last_seen_at) >= 1) {
                $user->last_seen_at = now();
                $user->last_ip = $request->ip();
                // Model events fire නොවී කෙලින්ම save කරන්න
                $user->saveQuietly(); 
            }
        }

        return $next($request);
    }
}
