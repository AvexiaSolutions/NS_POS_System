<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use Illuminate\Support\Facades\Auth;

class IsAdmin
{
    public function handle(Request $request, Closure $next): Response
    {
        // ලොග් වෙලා ඉන්නේ Admin නම් විතරක් ඉස්සරහට යන්න දෙනවා
        if (Auth::check() && Auth::user()->role === 'admin') {
            return $next($request);
        }

        // Admin නෙවෙයි නම් (Cashier කෙනෙක් නම්), එයාව ආපහු POS එකට හරවලා යවනවා
        return redirect()->route('pos.index')->with('error', 'ඔබට මෙම පිටුවට පිවිසීමට අවසර නොමැත! (Access Denied)');
    }
}
