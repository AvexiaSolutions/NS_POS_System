<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class ReturnController extends Controller
{
    // History Table එක සහ Date Filter එක සඳහා
    public function index(Request $request)
    {
        // Date Filter අගයන් ලබාගැනීම (මූලිකව මේ මාසයේ මුල සිට අද දක්වා)
        $startDate = $request->input('start_date', date('Y-m-01'));
        $endDate = $request->input('end_date', date('Y-m-d'));

        // Query එක සෑදීම
        $query = DB::table('returns')
            ->join('sales', 'returns.sale_id', '=', 'sales.id')
            ->join('products', 'returns.product_id', '=', 'products.id')
            ->select(
                'returns.created_at',
                'sales.invoice_no',
                'products.product_name',
                'returns.type',
                'returns.qty',
                'returns.refund_amount',
                'returns.reason'
            )
            ->whereDate('returns.created_at', '>=', $startDate)
            ->whereDate('returns.created_at', '<=', $endDate);

        // Cashier කෙනෙක් නම් තමන්ගේ Branch එකේ දත්ත පමණක් පෙන්වීම
        if (auth()->user()->role !== 'admin') {
            $query->where('returns.branch_id', auth()->user()->branch_id);
        }

        // අලුත්ම දත්ත මුලින් පෙන්වන ලෙස සකස් කිරීම
        $history = $query->orderBy('returns.created_at', 'desc')->get();

        return view('returns.index', compact('history'));
    }

    // Bill Number / Barcode එකෙන් විස්තර සොයන කොටස
    public function search(Request $request)
    {
        try {
            // Scanner එකෙන් එන දත්තවල හිස්තැන් තිබුණොත් ඒවා ඉවත් කිරීම
            $invoice = trim($request->invoice_no);

            // Sale එක සොයා ගැනීම (Case-insensitive search)
            $sale = DB::table('sales')->whereRaw('UPPER(invoice_no) = ?', [strtoupper($invoice)])->first();

            if (!$sale) {
                return response()->json(['status' => 'error', 'message' => 'Invoice not found! Please check the code.']);
            }

            // Cashier (User) ගේ විස්තර Sale object එකට එකතු කිරීම (Warranty Modal එකේ පෙන්වීමට)
            $user = DB::table('users')->select('name')->where('id', $sale->user_id)->first();
            $sale->user = $user;

            $items = DB::table('sale_items')
                ->join('products', 'sale_items.product_id', '=', 'products.id')
                ->select(
                    'sale_items.*', 
                    'products.product_name', 
                    'products.unit',
                    'products.warranty_months',
                    'products.has_warranty',
                    'products.barcode'
                )
                ->where('sale_items.sale_id', $sale->id)
                ->get();

            // කලින් Return කරපු ප්‍රමාණයන් තිබේදැයි බැලීම
            foreach($items as $item) {
                $returnedQty = DB::table('returns')
                    ->where('sale_id', $sale->id)
                    ->where('product_id', $item->product_id)
                    ->sum('qty');
                
                // Null අගයන් 0 ලෙස ගැනීම (PHP 8 Error වළක්වා ගැනීමට)
                $item->returned_qty = $returnedQty ? (float) $returnedQty : 0;
                $item->available_qty = $item->qty - $item->returned_qty;
            }

            return response()->json([
                'status' => 'success', 
                'sale' => $sale, 
                'items' => $items,
                'sale_date' => date('Y-m-d h:i A', strtotime($sale->created_at)) // දිනය සහ වෙලාව
            ]);

        } catch (\Exception $e) {
            // මොකක් හරි Error එකක් ආවොත් ඒක හරියටම UI එකට යැවීම
            return response()->json([
                'status' => 'error', 
                'message' => 'System Error: ' . $e->getMessage() . ' (Line: ' . $e->getLine() . ')'
            ]);
        }
    }

    // Return එක Save කිරීම සහ Stock Update කිරීම
    public function process(Request $request)
    {
        DB::beginTransaction();
        try {
            $saleId = $request->sale_id;
            $items = $request->items; // Array of {product_id, qty, type}
            $reason = $request->reason;
            $branchId = auth()->user()->branch_id; // Cashier ගේ Branch ID එක

            // Invoice Number එක හොයාගන්නවා (Log එකට දාන්න)
            $sale = DB::table('sales')->where('id', $saleId)->first();
            $invoiceNo = $sale ? $sale->invoice_no : 'Unknown Invoice';

            // 1. Return items loop
            foreach ($items as $item) {
                if ($item['qty'] > 0) {
                    // අදාළ භාණ්ඩය විකුණු මිල ලබා ගැනීම
                    $saleItem = DB::table('sale_items')
                        ->where('sale_id', $saleId)
                        ->where('product_id', $item['product_id'])
                        ->first();

                    $refundAmount = 0;

                    // Return හෝ Damage නම් පමණක් මුදල් ආපසු ලබාදීම ගණනය කරයි (Warranty සදහා මුදල් ආපසු නොදේ)
                    if ($item['type'] == 'return' || $item['type'] == 'damage') {
                        $refundAmount = $saleItem->price * $item['qty'];
                    }

                    // Database එකේ 'returns' Table එකට දත්ත ඇතුළත් කිරීම
                    DB::table('returns')->insert([
                        'id' => (string) Str::uuid(),
                        'branch_id' => $branchId,
                        'sale_id' => $saleId,
                        'product_id' => $item['product_id'],
                        'qty' => $item['qty'],
                        'refund_amount' => $refundAmount,
                        'reason' => $reason,
                        'type' => $item['type'], // 'return', 'warranty', or 'damage'
                        'created_at' => now(),
                        'updated_at' => now(),
                    ]);

                    // Type එක 'return' නම් පමණක් Stock එකට එකතු කරයි (නැවත විකිණිය හැකි නිසා)
                    if ($item['type'] == 'return') {
                        DB::table('products')->where('id', $item['product_id'])->increment('qty', $item['qty']);
                    }
                }
            }

            // 🟢 Return / Warranty Process එක History එකේ සේව් වෙන තැන
            \App\Models\AuditLog::record('Process Return/Warranty', "{$invoiceNo} බිල්පත සඳහා භාණ්ඩ ආපසු භාරගැනීම / වගකීම් සටහන් කරන ලදී. (හේතුව: {$reason})");

            DB::commit();
            return response()->json(['status' => 'success', 'message' => 'Action Processed Successfully!']);

        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json(['status' => 'error', 'message' => 'Error: ' . $e->getMessage()]);
        }
    }
}
