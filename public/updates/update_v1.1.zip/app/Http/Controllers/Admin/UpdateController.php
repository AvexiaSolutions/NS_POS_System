<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Artisan;
use ZipArchive;

class UpdateController extends Controller
{
    private $updateUrl = 'https://update.nsenterprices.com/api/check-update';
    private $currentVersion = '1.0'; 

    public function index()
    {
        // PHP කාල සීමාවන් උපරිම කිරීම
        ini_set('max_execution_time', 300);

        try {
            // වඩාත් ශක්තිමත් cURL Options එකතු කරන ලදී
            $response = Http::withOptions([
                'verify' => false,
                'connect_timeout' => 45, // සර්වර් එකට සම්බන්ධ වීමට තත්පර 45ක්
                'curl' => [
                    CURLOPT_IPRESOLVE => CURL_IPRESOLVE_V4, // IPv4 පමණක් භාවිතා කරන්න (ප්‍රමාදය අඩු කරයි)
                    CURLOPT_FOLLOWLOCATION => true,
                ],
            ])->timeout(120)->get($this->updateUrl);
            
            if ($response->successful()) {
                $updateData = $response->json();
                $hasUpdate = isset($updateData['version']) && version_compare($updateData['version'], $this->currentVersion, '>');

                return view('admin.update.index', [
                    'updateData' => $updateData,
                    'hasUpdate' => $hasUpdate,
                    'currentVersion' => $this->currentVersion
                ]);
            }

            throw new \Exception('Update server response failed.');

        } catch (\Exception $e) {
            return view('admin.update.index', [
                'hasUpdate' => false, 
                'error' => 'සර්වර් එකෙන් ප්‍රතිචාරයක් ලබා ගැනීමට අපොහොසත් විය: ' . $e->getMessage(),
                'currentVersion' => $this->currentVersion
            ]);
        }
    }

    public function installUpdate()
    {
        ini_set('max_execution_time', 900);
        set_time_limit(900); 

        try {
            $response = Http::withOptions([
                'verify' => false,
                'connect_timeout' => 45,
                'curl' => [CURLOPT_IPRESOLVE => CURL_IPRESOLVE_V4]
            ])->timeout(120)->get($this->updateUrl);
            
            if (!$response->successful()) {
                return back()->with('error', 'Update විස්තර ලබා ගැනීමට නොහැකි විය.');
            }

            $updateData = $response->json();
            $zipPath = storage_path('app/temp_update.zip');

            // බාගත කිරීමේ කාලය විනාඩි 15ක් දක්වා වැඩි කරන ලදී
            Http::withOptions([
                'verify' => false,
                'connect_timeout' => 60,
                'curl' => [CURLOPT_IPRESOLVE => CURL_IPRESOLVE_V4]
            ])->timeout(900)->sink($zipPath)->get($updateData['download_url']);

            if (!File::exists($zipPath)) {
                return back()->with('error', 'Update ගොනුව බාගත කිරීම අසාර්ථකයි.');
            }

            $zip = new ZipArchive;
            if ($zip->open($zipPath) === TRUE) {
                // පවතින ගොනු මත (Overwrite) දිගහැරීම
                $zip->extractTo(base_path());
                $zip->close();
                File::delete($zipPath);

                Artisan::call('optimize:clear');
                return back()->with('success', 'පද්ධතිය සාර්ථකව යාවත්කාලීන විය!');
            } else {
                return back()->with('error', 'බාගත කළ Update ගොනුව දෝෂ සහිතයි.');
            }

        } catch (\Exception $e) {
            return back()->with('error', 'Update කිරීමේදී දෝෂයක් ඇතිවිය: ' . $e->getMessage());
        }
    }
}
