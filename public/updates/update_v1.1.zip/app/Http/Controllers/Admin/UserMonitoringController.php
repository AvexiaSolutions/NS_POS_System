<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\AuditLog; // 🟢 අලුතින් එකතු කළා (History ගන්න ඕන නිසා)
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class UserMonitoringController extends Controller
{
    public function index()
    {
        // Sessions table එක හරහා දැනට Active තියෙන සියලුම උපාංග (Devices) ලබා ගැනීම
        $activeSessions = DB::table('sessions')
            ->whereNotNull('user_id')
            ->join('users', 'sessions.user_id', '=', 'users.id')
            ->leftJoin('branches', 'users.branch_id', '=', 'branches.id')
            ->select(
                'sessions.id as session_id',
                'sessions.ip_address',
                'sessions.user_agent',
                'sessions.last_activity',
                'sessions.latitude',     // 🟢 Map එක සඳහා අලුතින් එකතු කළා
                'sessions.longitude',    // 🟢 Map එක සඳහා අලුතින් එකතු කළා
                'users.id as user_id',
                'users.name',
                'users.email',
                'users.role',
                'users.is_banned',
                'branches.name as branch_name'
            )
            ->orderBy('sessions.last_activity', 'desc')
            ->get();

        return view('admin.monitoring.index', compact('activeSessions'));
    }

    public function toggleBan(Request $request, User $user)
    {
        // තමන්ගේම ගිණුම Block කරගැනීම වැළැක්වීම
        if (auth()->id() === $user->id) {
            return back()->with('error', 'ඔබට ඔබගේම ගිණුම Block කළ නොහැක!');
        }

        $user->is_banned = !$user->is_banned;
        $user->save();

        // 🟢 අලුත් කොටස: Block කළා නම්, ඔහුගේ සියලුම Devices වල සක්‍රීය සැසි (Sessions) මකා දැමීම 
        // (එවිට ඔහු සියලු උපාංග වලින් ඉබේම Log out වේ)
        if ($user->is_banned) {
            DB::table('sessions')->where('user_id', $user->id)->delete();
        }

        $status = $user->is_banned ? 'Block කරන ලදී.' : 'Block කිරීම ඉවත් කරන ලදී.';
        return back()->with('success', "පරිශීලක ගිණුම $status");
    }

    // ==============================================================
    // 🟢 අලුතින් එකතු කළ AJAX History Function එක
    // ==============================================================
    public function getUserHistory($userId)
    {
        // අදාළ User ගේ අවසන් ක්‍රියාකාරකම් 50 (Audit Logs) ලබාගැනීම
        $logs = AuditLog::where('user_id', $userId)
            ->orderBy('created_at', 'desc')
            ->limit(50)
            ->get(['action', 'description', 'created_at']);

        // JSON විදිහට Modal එකට Data යැවීම
        return response()->json($logs);
    }
}
