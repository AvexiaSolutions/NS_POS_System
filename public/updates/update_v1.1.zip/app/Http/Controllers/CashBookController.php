<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class CashBookController extends Controller
{
    public function index()
    {
        // 1. ස්වයංක්‍රීය POS මුදල් (Sales & Returns)
        $cashSales = DB::table('sales')->where('payment_method', 'cash')->sum('total_amount');
        $cashReturns = DB::table('returns')->sum('refund_amount');

        // 2. අතින් ඇතුළත් කළ මුදල් (Manual Cash Entries)
        $manualCashIn = DB::table('cash_books')->where('type', 'in')->sum('amount');
        $manualCashOut = DB::table('cash_books')->where('type', 'out')->sum('amount');

        // 3. දැනට ලාච්චුවේ ඇති සම්පූර්ණ මුදල (Cash in Hand)
        $currentCashInHand = ($cashSales + $manualCashIn) - ($cashReturns + $manualCashOut);

        $transactions = DB::table('cash_books')->orderBy('created_at', 'desc')->get();
        $banks = DB::table('bank_accounts')->get();

        return view('cashbook.index', compact('currentCashInHand', 'transactions', 'banks'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'amount' => 'required|numeric|min:1',
            'category' => 'required',
            'description' => 'required'
        ]);

        $type = in_array($request->category, ['opening', 'from_bank', 'other']) ? 'in' : 'out';

        // බැංකුවෙන් සල්ලි කඩේට ගේනවා නම් (Deposit FROM Bank)
        if ($request->category === 'from_bank') {
            DB::table('bank_accounts')->where('id', $request->bank_account_id)->decrement('current_balance', $request->amount);
        }

        DB::table('cash_books')->insert([
            'description' => $request->description,
            'type' => $type,
            'category' => $request->category,
            'amount' => $request->amount,
            'bank_account_id' => $request->bank_account_id ?? null,
            'created_at' => Carbon::now(),
            'updated_at' => Carbon::now()
        ]);

        return back()->with('success', 'Cash transaction recorded successfully!');
    }

    // බැංකු පිටුවේ ඇති බොත්තමෙන් "Hand in Cash" එකෙන් බැංකුවට මුදල් දැමීම (Deposit TO Bank)
    public function transferToBank(Request $request)
    {
        $request->validate(['amount' => 'required|numeric|min:1', 'bank_account_id' => 'required']);

        // බැංකුවේ ගිණුම් ශේෂය වැඩි කිරීම
        DB::table('bank_accounts')->where('id', $request->bank_account_id)->increment('current_balance', $request->amount);

        // Cash Book එකෙන් මුදල් අඩු වීම සටහන් කිරීම
        DB::table('cash_books')->insert([
            'description' => 'Deposited to Bank (Cash Transferred)',
            'type' => 'out',
            'category' => 'to_bank',
            'amount' => $request->amount,
            'bank_account_id' => $request->bank_account_id,
            'created_at' => Carbon::now(),
            'updated_at' => Carbon::now()
        ]);

        return back()->with('success', 'Cash successfully deposited to the bank!');
    }
}
