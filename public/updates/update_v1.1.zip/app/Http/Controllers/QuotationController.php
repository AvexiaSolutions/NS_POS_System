<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Product;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Exception;

class QuotationController extends Controller
{
    public function index()
    {
        $user = auth()->user();

        // 1. UI එකේ Search කරන්න System එකේ තියෙන Products යැවීම (Branch එක අනුව)
        $productsQuery = DB::table('products');
        // Admin නෙවෙයි නම්, තමන්ගේ Branch එකේ බඩු විතරක් පෙන්වන්න
        if ($user->role !== 'admin') {
            $productsQuery->where('branch_id', $user->branch_id);
        }
        $products = $productsQuery->get();
        
        // 2. Quotation History එක (Branch එක අනුව)
        $query = DB::table('quotations')->orderBy('created_at', 'desc');
        if ($user->role !== 'admin') {
            $query->where('branch_id', $user->branch_id);
        }
        $quotations = $query->get();

        return view('quotations.index', compact('products', 'quotations'));
    }

    public function store(Request $request)
    {
        try {
            $id = (string) Str::uuid();
            $isFake = $request->is_fake_bill ? true : false;
            
            DB::table('quotations')->insert([
                'id' => $id,
                'branch_id' => auth()->user()->branch_id,
                'customer_name' => $request->customer_name,
                'items' => json_encode($request->items),
                // JS එකෙන් එන 1,500.00 වගේ ගණන් වල කමා (,) ඉවත් කර දත්ත ගබඩා කිරීම
                'total_amount' => (float) str_replace(',', '', $request->total_amount),
                'is_fake_bill' => $isFake,
                'created_at' => now(),
                'updated_at' => now(),
            ]);

            // 🟢 Quotation / Fake Bill එකක් අලුතින් හැදුවාම සේව් වෙන තැන
            $docType = $isFake ? 'Fake Bill' : 'Quotation';
            \App\Models\AuditLog::record('Create Quotation', "{$request->customer_name} මහතා/මහත්මිය සඳහා නව {$docType} එකක් (රු. {$request->total_amount}) පද්ධතියට ඇතුළත් කරන ලදී.");

            return response()->json(['status' => 'success', 'id' => $id]);

        } catch (Exception $e) {
            return response()->json(['status' => 'error', 'message' => 'Failed to save: ' . $e->getMessage()]);
        }
    }

    // --- අලුතින් එක් කළ Edit Function එක ---
    public function edit($id)
    {
        $quotation = DB::table('quotations')->where('id', $id)->first();
        
        if ($quotation) {
            // JSON string එක ආපහු array එකක් බවට පත් කරලා UI එකට යවනවා
            $quotation->items = json_decode($quotation->items);
            return response()->json($quotation);
        }
        
        return response()->json(['status' => 'error', 'message' => 'Record not found'], 404);
    }

    // --- අලුතින් එක් කළ Update Function එක ---
    public function update(Request $request, $id)
    {
        try {
            $isFake = $request->is_fake_bill ? true : false;

            DB::table('quotations')->where('id', $id)->update([
                'customer_name' => $request->customer_name,
                'items' => json_encode($request->items),
                'total_amount' => (float) str_replace(',', '', $request->total_amount),
                'is_fake_bill' => $isFake,
                'updated_at' => now(),
            ]);

            // 🟢 Quotation එක Update කළාම සේව් වෙන තැන
            $docType = $isFake ? 'Fake Bill' : 'Quotation';
            \App\Models\AuditLog::record('Update Quotation', "{$request->customer_name} ගේ {$docType} වාර්තාව යාවත්කාලීන කරන ලදී.");

            return response()->json(['status' => 'success', 'id' => $id]);

        } catch (Exception $e) {
            return response()->json(['status' => 'error', 'message' => 'Failed to update: ' . $e->getMessage()]);
        }
    }

    // --- අලුතින් එක් කළ Delete Function එක ---
    public function destroy($id)
    {
        try {
            $quotation = DB::table('quotations')->where('id', $id)->first();
            
            if ($quotation) {
                $customerName = $quotation->customer_name;
                $docType = $quotation->is_fake_bill ? 'Fake Bill' : 'Quotation';
                
                DB::table('quotations')->where('id', $id)->delete();

                // 🔴 Quotation එක Delete කළාම සේව් වෙන තැන
                \App\Models\AuditLog::record('Delete Quotation', "{$customerName} ගේ {$docType} වාර්තාව පද්ධතියෙන් මකා දමන ලදී.");
            }

            return response()->json(['status' => 'success']);

        } catch (Exception $e) {
            return response()->json(['status' => 'error', 'message' => 'Failed to delete: ' . $e->getMessage()]);
        }
    }

    public function print($id)
    {
        $quote = DB::table('quotations')->where('id', $id)->first();
        
        if (!$quote) {
            return "Record Not Found!";
        }

        $items = json_decode($quote->items);
        $shop = DB::table('shop_settings')->first();
        
        // 🟢 Quotation එක Print කළාම සේව් වෙන තැන
        $docType = $quote->is_fake_bill ? 'Fake Bill' : 'Quotation';
        \App\Models\AuditLog::record('Print Quotation', "{$quote->customer_name} ගේ {$docType} වාර්තාව මුද්‍රණය කරන ලදී.");

        return view('quotations.print', compact('quote', 'items', 'shop'));
    }
}
