<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Branch;
use App\Models\Brand;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class CategoryController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {
        $user = Auth::user();

        // Admin ද Cashier ද කියලා බලලා Brands ටිකත් ගන්න
        if ($user->role == 'admin') {
            $categories = Category::with('branch')->orderBy('created_at', 'desc')->get();
            $brands = Brand::with('branch')->orderBy('created_at', 'desc')->get();
            $branches = Branch::all();
        } else {
            $categories = Category::where('branch_id', $user->branch_id)->orderBy('created_at', 'desc')->get();
            $brands = Brand::where('branch_id', $user->branch_id)->orderBy('created_at', 'desc')->get();
            $branches = Branch::where('id', $user->branch_id)->get();
        }
            
        return view('inventory.categories.index', compact('categories', 'branches', 'brands'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'code' => 'nullable|string|max:50'
        ]);

        Category::create([
            'branch_id' => Auth::user()->role == 'admin' ? $request->branch_id : Auth::user()->branch_id,
            'name' => $request->name,
            'code' => $request->code
        ]);

        // 🟢 Category එකක් අලුතින් හැදුවාම History එකේ සේව් වෙන තැන
        \App\Models\AuditLog::record('Create Category', "{$request->name} නැමැති අලුත් Category එක පද්ධතියට ඇතුළත් කරන ලදී.");

        return redirect()->back()->with('success', 'Category Created Successfully!');
    }

    public function update(Request $request, $id)
    {
        $category = Category::findOrFail($id);
        
        $category->update([
            'branch_id' => Auth::user()->role == 'admin' ? $request->branch_id : Auth::user()->branch_id,
            'name' => $request->name,
            'code' => $request->code
        ]);

        // 🟢 Category එක වෙනස් කළාම (Update) History එකේ සේව් වෙන තැන
        \App\Models\AuditLog::record('Update Category', "{$request->name} නැමැති Category එකෙහි විස්තර වෙනස් කරන ලදී.");

        return redirect()->back()->with('success', 'Category Updated!');
    }

    public function destroy($id)
    {
        $category = Category::findOrFail($id);
        $categoryName = $category->name; // මකා දාන්න කලින් නම අරන් තියාගන්නවා (Log එකට දාන්න ඕන නිසා)
        
        $category->delete();
        
        // 🔴 Category එකක් මකා දැමුවාම History එකේ සේව් වෙන තැන
        \App\Models\AuditLog::record('Delete Category', "{$categoryName} නැමැති Category එක පද්ධතියෙන් මකා දමන ලදී.");

        return redirect()->back()->with('success', 'Category Deleted!');
    }
}
