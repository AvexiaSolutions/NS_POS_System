<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

class SettingController extends Controller
{
    public function index()
    {
        // දැනට තියෙන Settings ගන්න (පළමු පේළිය)
        $setting = DB::table('shop_settings')->first();
        return view('settings.general', compact('setting'));
    }

    public function update(Request $request)
    {
        $request->validate([
            'shop_name' => 'required|string|max:255',
            'shop_address' => 'nullable|string|max:255',
            'shop_phone' => 'nullable|string|max:20',
            'logo' => 'nullable|image|mimes:jpeg,png,jpg|max:2048', // 2MB Max
        ]);

        // දැනට Settings තියෙනවාද බලන්න
        $setting = DB::table('shop_settings')->first();
        $logoPath = $setting->logo ?? null;

        // අලුත් Logo එකක් Upload කළොත්
        if ($request->hasFile('logo')) {
            // පරණ Logo එක මකන්න (තිබුණොත්)
            if ($logoPath && Storage::exists('public/' . $logoPath)) {
                Storage::delete('public/' . $logoPath);
            }
            // අලුත් එක Save කරන්න
            $logoPath = $request->file('logo')->store('logos', 'public');
        }

        // දත්ත යාවත්කාලීන කිරීම හෝ අලුතින් දැමීම
        if ($setting) {
            DB::table('shop_settings')->where('id', $setting->id)->update([
                'shop_name' => $request->shop_name,
                'shop_address' => $request->shop_address,
                'shop_phone' => $request->shop_phone,
                'logo' => $logoPath,
                'updated_at' => now(),
            ]);
        } else {
            DB::table('shop_settings')->insert([
                'id' => (string) Str::uuid(), // UUID
                'shop_name' => $request->shop_name,
                'shop_address' => $request->shop_address,
                'shop_phone' => $request->shop_phone,
                'logo' => $logoPath,
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        }

        return back()->with('success', 'Settings Updated Successfully!');
    }
}
