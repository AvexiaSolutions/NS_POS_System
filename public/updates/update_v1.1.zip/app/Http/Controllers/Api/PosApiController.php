<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Product;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class PosApiController extends Controller
{
    /**
     * App එකට අවශ්‍ය භාණ්ඩ ලැයිස්තුව (Product List) ලබා දීම
     */
    public function getProducts()
    {
        // Eloquent හරහා stock ඇති සියලුම භාණ්ඩ ලබා ගැනීම
        $products = Product::with(['category', 'brand'])
            ->where('qty', '>', 0)
            ->get();

        return response()->json([
            'status' => 'success',
            'data' => $products
        ]);
    }

    /**
     * App එකෙන් එවන විකුණුම් (Sales) සටහන් කර ගැනීම
     */
    public function storeSale(Request $request)
    {
        return DB::transaction(function () use ($request) {
            $saleId = (string) Str::uuid();
            $totalAmount = floatval($request->total);

            // 1. Sales record එක සෑදීම
            DB::table('sales')->insert([
                'id' => $saleId,
                'branch_id' => auth()->user()->branch_id,
                'user_id' => auth()->id(),
                'invoice_no' => 'APP-' . strtoupper(Str::random(8)),
                'sub_total' => $totalAmount + (floatval($request->discount) ?? 0),
                'discount' => floatval($request->discount) ?? 0,
                'total_amount' => $totalAmount,
                'cash_received' => $totalAmount,
                'payment_method' => $request->payment_method ?? 'cash',
                'created_at' => now(),
                'updated_at' => now(),
            ]);

            // 2. භාණ්ඩ Stock එකෙන් අඩු කිරීම සහ Sale Items සෑදීම
            foreach ($request->cart as $item) {
                // Stock decrement කිරීම
                DB::table('products')->where('id', $item['id'])->decrement('qty', $item['qty']);

                DB::table('sale_items')->insert([
                    'id' => (string) Str::uuid(),
                    'sale_id' => $saleId,
                    'product_id' => $item['id'],
                    'product_name' => $item['name'],
                    'qty' => $item['qty'],
                    'price' => $item['price'],
                    'total' => floatval($item['price']) * floatval($item['qty']),
                    'created_at' => now(),
                    'updated_at' => now(),
                ]);
            }

            return response()->json([
                'status' => 'success',
                'message' => 'Sale recorded successfully',
                'sale_id' => $saleId
            ]);
        });
    }
}
