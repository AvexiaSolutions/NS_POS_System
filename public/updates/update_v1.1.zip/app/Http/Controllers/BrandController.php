<?php

namespace App\Http\Controllers;

use App\Models\Brand;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class BrandController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255'
        ]);

        Brand::create([
            'branch_id' => Auth::user()->role == 'admin' ? $request->branch_id : Auth::user()->branch_id,
            'name' => $request->name
        ]);

        // 🟢 Brand එකක් අලුතින් හැදුවාම History එකේ සේව් වෙන තැන
        \App\Models\AuditLog::record('Create Brand', "{$request->name} නැමැති අලුත් Brand එක පද්ධතියට ඇතුළත් කරන ලදී.");

        return redirect()->back()->with('success', 'Brand / Company Added Successfully!');
    }

    public function destroy($id)
    {
        $brand = Brand::findOrFail($id);
        $brandName = $brand->name; // මකා දාන්න කලින් නම අරන් තියාගන්නවා (Log එකට දාන්න ඕන නිසා)
        
        $brand->delete();

        // 🔴 Brand එකක් මකා දැමුවාම History එකේ සේව් වෙන තැන
        \App\Models\AuditLog::record('Delete Brand', "{$brandName} නැමැති Brand එක පද්ධතියෙන් මකා දමන ලදී.");

        return redirect()->back()->with('success', 'Brand Deleted!');
    }
}
